import ast,copy,itertools,json,math,os,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime,timedelta
import pandas as pd
import openpyxl
import test_excel

BASE=Path(__file__).resolve().parents[1]
TREE=ast.parse((BASE/'automatizacion_magpy3_exe4.py').read_text())
SHARED={'pedir_cantidad_contacto','pedir_nombre_posicion_unico','fase_rms_region',
 'agrupar_regiones_rms','modo_por_distancia','regiones_en_orden','promedio_ventana_rms',
 'ejecutar_cortes','adquirir_rms_compartido','describir_plan_medida'}

def load(names,ns):
 names=set(names)|SHARED
 ns.setdefault('math',math)
 ns.setdefault('UMBRAL_TIP_MAX_CM',.75);ns.setdefault('UMBRAL_PROBE_CENTER_CM',1.85)
 ns.setdefault('timedelta',timedelta)
 exec(compile(ast.Module(body=[n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'core','exec'),ns)

def config(ns):
 ns.update(DURACION_6MIN=360,DURACION_30MIN=1800,DURACION_2MIN=120,
  NOM_6MIN=360,NOM_30MIN=1800,NOM_2MIN=120,MS_6MIN=360000,MS_30MIN=1800000,MS_2MIN=120000)
 for n in TREE.body:
  if isinstance(n,ast.Assign) and any(getattr(t,'id','') in ['CONFIG_REGION','EXCEL_COL_MAP'] for t in n.targets):
   exec(compile(ast.Module(body=[n],type_ignores=[]),'config','exec'),ns)

class MultirregionTests(unittest.TestCase):
 def ejecutar_real(self,regiones,ejecutar=None):
  fixture=test_excel.ExcelTests();fixture.setUp();self.addCleanup(fixture.doCleanups)
  wb=openpyxl.load_workbook(fixture.path)
  wb.create_sheet('FCC Results');wb.create_sheet('EN Results');wb.save(fixture.path);wb.close()
  ns=fixture.ns;config(ns)
  duraciones=[];referencias=[];secuencia=[];acciones=[];colectores=[]
  campos=itertools.count(1)
  def collector(api_location):
   h=float(next(campos))
   # La primera ventana termina a 6 min; las muestras posteriores son mucho mayores.
   filas=[dict(timestamp=ts,frequency=125000.,h_field_rms_x=valor,h_field_rms_y=0,h_field_rms_z=0,
               e_field_rms_x=valor*2,e_field_rms_y=0,e_field_rms_z=0)
          for ts,valor in [(0,h),(120000,h),(360000,h),(360001,h+9),(1800000,h+9),(1800001,999)]]
   referencias.append(api_location)
   obj=SimpleNamespace(filas_measurement=filas,ts_inicio_ms=0,detener=lambda:acciones.append('colector_stop'))
   colectores.append(obj)
   return obj
  def progreso(duracion,etiqueta,cortes=None):
   duraciones.append(duracion)
   for _,callback in sorted(list(cortes or []),key=lambda c:c[0]):callback()
  ns.update(pd=pd,math=math,os=os,json=json,datetime=datetime,timedelta=timedelta,ColectorDatos=collector,
   DIST_COMPROBACION_CM=3.,DIST_PICO_CONTACTO_CM=0.,AVISO_TECLADO='Cierra teclado',
   preparar_region_medida=lambda r,modo='RMS':secuencia.append((r,modo)) or True,
   sep=lambda *a:None,beep=lambda *a:None,cuadro=lambda *a:None,enter=lambda *a:None,
   click_clear_gui=lambda:None,time=SimpleNamespace(sleep=lambda *a:None),
   iniciar_medida_con_reintentos=lambda *a,**k:acciones.append('start') or True,
   barra_progreso=progreso,parar_medida=lambda:acciones.append('stop'),
   capturar_pantalla=lambda *a:acciones.append('captura'),guardar_datos_zip=lambda *a:acciones.append('zip'),
   _registrar_promedio_fcc=lambda *a:None)
  load({'procesar_posicion','_procesar_posicion_regiones','calcular_plan_medida','promediar_medidas',
    'calcular_peak_desde_rms','calcular_h_total','calcular_e_total','filas_resumen_regionales',
    '_fila_resumen','medir_peak_posicion'},ns)
  ns['acciones']=acciones;ns['colectores']=colectores
  if ejecutar is None:
   resultado=ns['procesar_posicion']('Left',fixture.tmp.name,regiones,0,125,str(fixture.path),'RFID','N/A','N/A',peak_fisico=True)
  else:resultado=ejecutar(ns,fixture,regiones)
  return fixture,ns,resultado,duraciones,referencias,secuencia

 def test_plan_ised_fcc_un_rms_30_y_peak_separado(self):
  ns={};config(ns);load({'calcular_plan_medida'},ns)
  plan=ns['calcular_plan_medida'](['FCC','ISED'])
  self.assertEqual([(p['region'],p['modo'],p['nominal_s']) for p in plan['secuencia']],
   [('ISED+FCC','RMS',1800),('ISED','Peak',120)])
  self.assertEqual(plan['secuencia'][0]['cortes'],{'ISED':360,'FCC':1800})
  self.assertEqual(plan['duracion_rms_nominal_s']+plan['duracion_peak_nominal_s'],32*60)
 def test_tres_regiones_comparten_si_coincide_geometria(self):
  ns={};config(ns);load({'calcular_plan_medida'},ns)
  plan=ns['calcular_plan_medida'](['CE','FCC','ISED'])
  self.assertEqual(plan['duracion_rms_nominal_s'],1800)
  self.assertEqual(plan['secuencia'][0]['cortes'],{'ISED':360,'CE':360,'FCC':1800})
 def test_distancias_diferentes_no_comparten(self):
  ns={};config(ns);load({'calcular_plan_medida','distancia_base_fcc'},ns)
  plan=ns['calcular_plan_medida'](['ISED','FCC'],20,'puntual')
  self.assertEqual([p['distancia_cm'] for p in plan['secuencia'] if p['modo']=='RMS'],[20,0])
  self.assertEqual(plan['duracion_rms_nominal_s'],2160)
 def test_un_solo_rms_y_valores_distintos_en_excel(self):
  fixture,ns,resultado,dur,refs,orden=self.ejecutar_real(['FCC','ISED'])
  self.assertEqual(dur,[1800,120]);self.assertEqual(orden,[('FCC','RMS'),('ISED','Peak')])
  self.assertEqual(ns['acciones'].count('start'),2)  # un RMS y un PEAK, nunca 30+6 RMS
  self.assertEqual(ns['acciones'].count('stop'),2)
  self.assertEqual(resultado[1]['_por_region']['ISED']['h_prom'],1)
  self.assertAlmostEqual(resultado[1]['_por_region']['FCC']['h_prom'],4.6)
  wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
  self.assertEqual(wb['ISED Results'].cell(9,17).value,1)
  self.assertEqual(wb['FCC Results'].cell(9,17).value,4.6)
  self.assertEqual(wb['ISED Results'].cell(9,42).value,round(2*math.sqrt(2),4))
 def test_cortes_conservan_muestras_y_no_incluyen_datos_futuros(self):
  fixture,ns,_,_,_,_=self.ejecutar_real(['ISED','FCC'])
  archivos=list(Path(fixture.tmp.name).glob('ISED/Left/Corte_RMS_6min_*.json'))
  self.assertEqual(len(archivos),1)
  corte=json.loads(archivos[0].read_text())
  self.assertTrue(corte['definitivo'])
  self.assertEqual(max(f['timestamp'] for f in corte['muestras']),360000)
  self.assertEqual(corte['promedio']['h_prom'],1)
  self.assertEqual(corte['standard_adquisicion'],'FCC')
  self.assertEqual(len(ns['colectores'][0].filas_measurement),6)  # originales intactos
 def test_ce_recibe_6_min_de_la_misma_adquisicion(self):
  fixture,ns,resultado,dur,_,_=self.ejecutar_real(['CE','FCC','ISED'])
  self.assertEqual(dur,[1800,120])
  self.assertEqual(resultado[1]['_por_region']['CE']['h_prom'],1)
  self.assertEqual(resultado[1]['_por_region']['FCC']['h_prom'],4.6)
 def test_corte_vacio_no_recurre_a_todas_las_muestras(self):
  ns=dict(pd=pd,math=math,msg=lambda *a:None)
  load({'promediar_medidas','calcular_h_total','calcular_e_total'},ns)
  prom,filas=ns['promedio_ventana_rms']([{'timestamp':400000,'h_field_rms_x':99}],360000,0)
  self.assertEqual(filas,[]);self.assertIsNone(prom['h_prom'])
 def test_fcc_contacto_tiene_distancia_propia(self):
  ns={};load({'distancia_base_fcc'},ns)
  self.assertEqual(ns['distancia_base_fcc'](['ISED','FCC'],20,'puntual'),0)
  self.assertEqual(ns['distancia_base_fcc'](['ISED','FCC'],20,'no'),20)
 def test_referencias_de_la_imagen(self):
  ns={};load(set(),ns)
  for d,esperado in [(0,'Tip Max'),(.749,'Tip Max'),(.75,'Sensor Max'),(1.85,'Sensor Max'),(2,'Probe Center'),(3,'Probe Center'),(4,'Probe Center')]:
   self.assertEqual(ns['modo_por_distancia'](d)[0],esperado)
 def test_cortes_se_ejecutan_una_vez_y_sin_detener_adquisicion(self):
  ns={};load(set(),ns);pasos=[]
  cortes=[(360,lambda:pasos.append(6)),(1800,lambda:pasos.append(30))]
  ns['ejecutar_cortes'](cortes,359);self.assertEqual(pasos,[])
  ns['ejecutar_cortes'](cortes,360);self.assertEqual(pasos,[6])
  ns['ejecutar_cortes'](cortes,1800);ns['ejecutar_cortes'](cortes,1801)
  self.assertEqual(pasos,[6,30]);self.assertEqual(cortes,[])
 def test_resultados_validaciones_json_por_region(self):
  with tempfile.TemporaryDirectory() as tmp:
   ns=dict(os=os,json=json,datetime=datetime,msg=lambda *a:None)
   load({'guardar_validacion_region','guardar_json_atomico'},ns)
   a=ns['guardar_validacion_region'](tmp,'ISED','E_H_3cm',{'estado':'OK'})
   b=ns['guardar_validacion_region'](tmp,'FCC','Estimated_Measured',{'estado':'NO_CUMPLE'})
   self.assertNotEqual(a,b);self.assertEqual(json.loads(Path(b).read_text())['estado'],'NO_CUMPLE')
 def test_csv_por_region_no_copia_h(self):
  with tempfile.TemporaryDirectory() as tmp:
   ns=dict(os=os,pd=pd,msg=lambda *a:None,sep=lambda *a:None,print=lambda *a:None)
   load({'guardar_csv_resumen'},ns)
   ns['guardar_csv_resumen']([{'posicion':'A','regiones':'ISED','h_prom_A_m':1},{'posicion':'A','regiones':'FCC','h_prom_A_m':5}],str(Path(tmp)/'resumen.csv'))
   self.assertEqual(pd.read_csv(Path(tmp)/'resumen_ISED.csv',sep=';')['h_prom_A_m'][0],1)
   self.assertEqual(pd.read_csv(Path(tmp)/'resumen_FCC.csv',sep=';')['h_prom_A_m'][0],5)

class ContactoPuntualAlFinalTests(unittest.TestCase):
 def test_todos_los_rms_antes_del_primer_peak(self):
  pasos=[]
  ns=dict(os=os,math=math,DIST_PICO_CONTACTO_CM=0.,pedir_numero=lambda *a:2,
   cuadro=lambda *a:None,msg=lambda *a:None,preparar_region_medida=lambda *a,**k:True)
  load({'_medidas_puntuales_regionales','filas_resumen_regionales','_fila_resumen','promedio_completo'},ns)
  prom=dict(h_prom=1,e_prom=2,freq_mhz=.125)
  def rms(nombre,*a,**kw):
   pasos.append(('RMS',nombre))
   self.assertTrue(kw['solo_rms'])
   return None,dict(prom,_por_region={'ISED':prom,'FCC':prom}),None,0
  def peak(nombre,*a):pasos.append(('Peak',nombre));return prom
  def extra(*a):pasos.append(('3cm',a[0]));return 'OK',a[-3],a[-2],a[-1]
  ns.update(procesar_posicion=rms,medir_peak_posicion=peak,_medida_peor_posicion=extra)
  estado,*_=ns['_medidas_puntuales_regionales'](['ISED','FCC'],0,125,'out',None,'','','',lambda i,n:f'P{i}',2,None)
  self.assertEqual(estado,'OK')
  self.assertEqual(pasos[:4],[('RMS','P1'),('RMS','P2'),('Peak','P1'),('Peak','P2')])
  self.assertEqual(pasos[4][0],'3cm')

if __name__=='__main__':unittest.main()
