import ast
import copy
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace
import unittest
import pandas as pd
import openpyxl
import test_excel

BASE=Path(__file__).resolve().parents[1]

def cargar(names,ns):
 ns.setdefault("guardar_validacion_region",lambda *a,**kw:None)
 names=set(names)|({"filas_resumen_regionales"} if "_medida_peor_posicion" in names else set())
 tree=ast.parse((BASE/'automatizacion_magpy3_exe4.py').read_text())
 exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'core','exec'),ns)

class Peak3cmTests(unittest.TestCase):
 def ejecutar_posicion(self,fija=True,vacias=False):
  fixture=test_excel.ExcelTests();fixture.setUp();self.addCleanup(fixture.doCleanups)
  ns=fixture.ns
  filas=[] if vacias else [dict(timestamp=i*700,frequency=f,
   h_field_rms_x=1,h_field_rms_y=2,h_field_rms_z=2,
   e_field_rms_x=2,e_field_rms_y=0,e_field_rms_z=0)
   for i,f in enumerate([101448.59375,102500.,103500.])]
  original=copy.deepcopy(filas)
  def colector(**kw):return SimpleNamespace(filas_measurement=filas,ts_inicio_ms=0,detener=lambda:None)
  plan=dict(duracion_rms_nominal_s=360,duracion_peak_nominal_s=120,
   duracion_rms_s=360,duracion_peak_s=120,necesita_peak=True,
   ventanas={'ISED':{'RMS':360000,'Peak':120000}},
   ventanas_nom={'ISED':{'RMS':360000,'Peak':120000}})
  ns['CONFIG_REGION']['ISED'].update(nombre='ISED',fases=[{'etiqueta':'RMS'},{'etiqueta':'PEAK'}])
  ns.update(pd=pd,math=math,ColectorDatos=colector,modo_por_distancia=lambda d:('Sensor Max','sensor-max'),
   DIST_COMPROBACION_CM=3.,AVISO_TECLADO='Cierra teclado',
   calcular_plan_medida=lambda r:plan,sep=lambda *a:None,beep=lambda *a:None,
   cuadro=lambda *a:None,enter=lambda *a:None,click_clear_gui=lambda:None,
   time=SimpleNamespace(sleep=lambda *a:None),iniciar_medida_con_reintentos=lambda *a,**kw:True,
   barra_progreso=lambda *a:None,parar_medida=lambda:None,
   capturar_pantalla=lambda *a:None,guardar_datos_zip=lambda *a:None)
  cargar({'procesar_posicion','promediar_medidas','calcular_peak_desde_rms','calcular_h_total','calcular_e_total'},ns)
  resultado=ns['procesar_posicion']('Left Edge 3cm',fixture.tmp.name,['ISED'],3.,125.,str(fixture.path),
   'RFID','N/A','N/A',peak_fisico=True,restablecer_modo=False,frecuencia_peak_fija=fija)
  self.assertEqual(filas,original)
  return resultado,fixture

 def test_3cm_variacion_api_conserva_campos_y_guarda_excel(self):
  resultado,fixture=self.ejecutar_posicion()
  peak=resultado[2]
  self.assertIsNotNone(peak);self.assertFalse(peak['multi_frecuencia'])
  self.assertEqual(peak['freq_mhz'],.125)
  self.assertAlmostEqual(peak['h_prom'],3*math.sqrt(2),places=6)
  self.assertAlmostEqual(peak['e_prom'],2*math.sqrt(2),places=6)
  wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
  self.assertEqual(wb.active.cell(9,30).value,'Left Edge 3cm')
  self.assertEqual(wb.active.cell(9,31).value,3)
  self.assertEqual(wb.active.cell(9,33).value,round(2*math.sqrt(2),4))
  self.assertEqual(wb.active.cell(9,42).value,round(3*math.sqrt(2),4))

 def test_sin_opcion_se_conserva_el_control_original(self):
  resultado,fixture=self.ejecutar_posicion(fija=False)
  self.assertIsNone(resultado[1]);self.assertIsNone(resultado[2])
  wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
  self.assertIsNone(wb.active.cell(9,30).value)

 def test_no_inventa_campos_cuando_no_hay_muestras(self):
  resultado,_=self.ejecutar_posicion(vacias=True)
  self.assertIsNone(resultado[1]);self.assertIsNone(resultado[2])

 def test_comprobacion_3cm_activa_opcion_antes_de_validar_eh(self):
  llamadas=[]
  def medir(*a,**kw):
   llamadas.append(kw)
   return 'OK',[('Left 3cm',dict(h_prom=2,e_prom=6),dict(h_prom=3,e_prom=9))]
  ns=dict(DIST_COMPROBACION_CM=3.,EH_LIMITE_OHM=37.7,msg=lambda *a:None,
   cuadro=lambda *a:None,enter=lambda *a:None,_medir_posiciones_con_reintento=medir,
   _fila_resumen=lambda nombre,*a:{'posicion':nombre},comprobar_eh=lambda e,h:(e/h,True))
  cargar({'_medida_peor_posicion'},ns)
  resultado=ns['_medida_peor_posicion']('Left',9,0,['ISED'],'out',(125,None,'','',''),None,[],[],4)
  self.assertEqual(resultado[0],'OK')
  self.assertTrue(llamadas[0]['frecuencia_peak_fija'])
  self.assertTrue(llamadas[0]['peak_fisico'])

 def test_resto_de_funciones_identicas_al_zip_recibido(self):
  baseline=json.loads((BASE/'tests/baseline_3cm.json').read_text())
  for path,antes in baseline.items():
   tree=ast.parse((BASE/path).read_text())
   despues={n.name:hashlib.sha256(ast.dump(n).encode()).hexdigest()
            for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
   nuevos={'distancia_base_fcc','regiones_en_orden','preparar_region_medida',
     'filas_resumen_regionales','guardar_validacion_region','_procesar_posicion_regiones',
     '_medidas_puntuales_regionales','pedir_cantidad_contacto','pedir_nombre_posicion_unico',
     'fase_rms_region','agrupar_regiones_rms','promedio_ventana_rms','ejecutar_cortes',
     'adquirir_rms_compartido','describir_plan_medida'}
   self.assertEqual(set(despues)-set(antes),nuevos)
   self.assertEqual(set(antes)-set(despues),set())
   self.assertEqual({n for n in antes if antes[n]!=despues[n]},
     {'_medida_peor_posicion','procesar_posicion','calcular_plan_medida','medidas_con_contacto',
      'guardar_csv_resumen','validar_caida_fcc','validar_estimado_medido_fcc','main','medir_peak_posicion','_medir_posiciones_con_reintento',
      'barra_progreso','pedir_configuracion_sesion','imprimir_resumen_sesion'})

if __name__=='__main__':unittest.main()
