import ast,queue,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import time
from test_multirregion import load,BASE

class Reloj:
 def __init__(self):self.t=0.
 def monotonic(self):return self.t
 def sleep(self,segundos):self.t+=segundos

class TemporizacionTests(unittest.TestCase):
 def test_barra_gui_mantiene_un_solo_periodo_de_30_min(self):
  reloj=Reloj();cortes=[];ns={};load(set(),ns)
  gui=ast.parse((BASE/'gui_magpy3_exe4.py').read_text())
  funcion=next(n for n in gui.body if isinstance(n,ast.FunctionDef) and n.name=='gui_barra_progreso')
  ctx=dict(core=SimpleNamespace(ejecutar_cortes=ns['ejecutar_cortes']),
   sesion_abortada=threading.Event(),eventos_q=queue.Queue(),SesionAbortadaPorOperador=RuntimeError)
  exec(compile(ast.Module(body=[funcion],type_ignores=[]),'GUI','exec'),ctx)
  def corte6():cortes.append(reloj.t);reloj.t+=5  # IO consume tiempo, no se anade a los 30 min.
  with patch.object(time,'monotonic',reloj.monotonic),patch.object(time,'sleep',reloj.sleep):
   ctx['gui_barra_progreso'](1800,'Compartida',cortes=[(360,corte6)])
  self.assertEqual(len(cortes),1);self.assertAlmostEqual(cortes[0],360,delta=.2)
  self.assertAlmostEqual(reloj.t,1800,places=4)
  eventos=[]
  while not ctx['eventos_q'].empty():eventos.append(ctx['eventos_q'].get())
  self.assertEqual(sum(t=='PROGRESO_INICIO' for t,p in eventos),1)
  self.assertEqual(eventos[-1][0],'PROGRESO_FIN')
 def test_barra_cli_no_reinicia_el_reloj_en_el_corte(self):
  reloj=Reloj();cortes=[]
  ns=dict(time=reloj,print=lambda *a,**k:None);load({'barra_progreso'},ns)
  def corte6():cortes.append(reloj.t);reloj.t+=5
  ns['barra_progreso'](1800,'Compartida',cortes=[(360,corte6)])
  self.assertEqual(len(cortes),1);self.assertAlmostEqual(reloj.t,1800,places=4)
 def test_datos_con_misma_referencia_pero_distancia_distinta_no_comparten(self):
  ns={};load(set(),ns)
  grupos=ns['agrupar_regiones_rms'](['ISED','FCC'],3,contacto_fcc=True)
  self.assertEqual(len(grupos),2)
  self.assertEqual([g['distancia_cm'] for g in grupos],[3,0])


class ProteccionAdquisicionTests(unittest.TestCase):
 def test_abortar_conserva_corte_y_detiene_equipo(self):
  import test_multirregion as r
  from pathlib import Path
  import json,openpyxl
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   def progreso(duracion,etiqueta,cortes=None):
    cortes[0][1]()
    raise RuntimeError('Aborto simulado')
   ns['barra_progreso']=progreso
   with self.assertRaisesRegex(RuntimeError,'Aborto simulado'):
    ns['procesar_posicion']('Left',fixture.tmp.name,regiones,0,125,str(fixture.path),'RFID','N/A','N/A',solo_rms=True)
   self.assertEqual(ns['acciones'].count('stop'),1);self.assertEqual(ns['acciones'].count('zip'),1)
   ruta=next(Path(fixture.tmp.name).glob('ISED/Left/Corte_RMS_6min_*.json'))
   self.assertFalse(json.loads(ruta.read_text())['definitivo'])
   wb=openpyxl.load_workbook(fixture.path)
   try:self.assertIsNone(wb['FCC Results'].cell(9,17).value)
   finally:wb.close()
   return None,None,None,None
  case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
 def test_sin_muestras_del_primer_corte_no_usa_el_resto_de_los_30_min(self):
  import test_multirregion as r
  import openpyxl
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   original=ns['ColectorDatos']
   def colector(**kw):
    obj=original(**kw)
    obj.filas_measurement=[dict(f,timestamp=f['timestamp']+400000) for f in obj.filas_measurement]
    return obj
   ns.update(ColectorDatos=colector,preguntar_opcion=lambda *a:'ABORTAR')
   resultado=ns['procesar_posicion']('Left',fixture.tmp.name,regiones,0,125,str(fixture.path),'RFID','N/A','N/A',solo_rms=True)
   self.assertIsNone(resultado[1])
   wb=openpyxl.load_workbook(fixture.path)
   try:
    self.assertIsNone(wb['ISED Results'].cell(9,17).value)
    self.assertIsNone(wb['FCC Results'].cell(9,17).value)
   finally:wb.close()
   return resultado
  case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
 def test_tiempos_reducidos_conservan_ventanas_independientes(self):
  import test_multirregion as r
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   for region,seg in [('ISED',60),('FCC',30)]:
    fase=ns['fase_rms_region'](region);fase['duracion_s']=seg;fase['ms_ventana']=seg*1000
   original=ns['ColectorDatos']
   def colector(**kw):
    obj=original(**kw)
    base=obj.filas_measurement[0]
    obj.filas_measurement=[dict(base,timestamp=ts,h_field_rms_x=h,e_field_rms_x=2*h)
                          for ts,h in [(0,1),(20000,2),(30000,3),(60000,4),(60001,999)]]
    return obj
   cortes=[]
   def progreso(duracion,etiqueta,cortes=None):
    self.assertEqual(duracion,60)
    self.assertEqual([s for s,c in cortes],[30])
    for _,callback in cortes:callback()
   ns.update(ColectorDatos=colector,barra_progreso=progreso)
   resultado=ns['procesar_posicion']('Left',fixture.tmp.name,regiones,0,125,str(fixture.path),'RFID','N/A','N/A',solo_rms=True)
   self.assertEqual(resultado[1]['_por_region']['ISED']['h_prom'],2.5)
   self.assertEqual(resultado[1]['_por_region']['FCC']['h_prom'],2)
   return resultado
  case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
 def test_resumen_informa_rms_compartido_y_peak_al_final(self):
  import test_multirregion as r
  ns={};r.config(ns);r.load({'calcular_plan_medida','distancia_base_fcc','fcc_aplica_validacion_cero'},ns)
  ns['FCC_CERO_CM_MAX']=.1
  core=SimpleNamespace(**ns,FCC_DISTANCIA_MIN_VALIDACION_CM=20)
  tree=ast.parse((BASE/'gui_magpy3_exe4.py').read_text())
  cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='AppMagpy3')
  metodo=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_mostrar_resumen_y_confirmar')
  textos=[];ctx=dict(core=core,messagebox=SimpleNamespace(askokcancel=lambda t,s:textos.append(s) or False))
  exec(compile(ast.Module(body=[metodo],type_ignores=[]),'GUI','exec'),ctx)
  cfg=dict(plan=ns['calcular_plan_medida'](['ISED','FCC'],0,'puntual'),regiones=['ISED','FCC'],
   contacto='puntual',nombres_regiones='ISED,FCC',n_posiciones=4,distancia_cm=0,frecuencia=125,
   technology='RFID',wpt_client='N/A',battery='N/A',carpeta_raiz='out',ruta_excel=None)
  ctx['_mostrar_resumen_y_confirmar'](SimpleNamespace(),cfg)
  self.assertIn('Una adquisicion RMS de 30 min',textos[0])
  self.assertIn('ISED: primeros 6 min',textos[0]);self.assertIn('FCC: primeros 30 min',textos[0])
  self.assertIn('despues de todos los RMS',textos[0])


class FalloInicioTests(unittest.TestCase):
 def test_error_tras_iniciar_equipo_solicita_parada(self):
  import test_multirregion as r
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   def fallo(*a,**kw):raise RuntimeError('Error del colector')
   ns['iniciar_medida_con_reintentos']=fallo
   with self.assertRaisesRegex(RuntimeError,'Error del colector'):
    ns['procesar_posicion']('Left',fixture.tmp.name,regiones,0,125,str(fixture.path),'RFID','N/A','N/A',solo_rms=True)
   self.assertEqual(ns['acciones'].count('stop'),1)
   self.assertEqual(ns['acciones'].count('colector_stop'),1)
   return None,None,None,None
  case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)


class ConfiguracionCompartidaTests(unittest.TestCase):
 def test_estandar_y_modo_se_confirman_antes_de_medir(self):
  import test_multirregion as r
  mensajes=[];validaciones=[]
  ns=dict(cuadro=lambda *a:None,enter=mensajes.append,AVISO_TECLADO='Cierra teclado')
  r.config(ns)
  def validar(region):validaciones.append(region);return True
  ns['validar_configuracion_magpy']=validar
  r.load({'preparar_region_medida'},ns)
  self.assertTrue(ns['preparar_region_medida']('FCC'))
  self.assertTrue(ns['preparar_region_medida']('ISED',modo='Peak'))
  self.assertEqual(validaciones,['FCC','ISED'])
  self.assertIn('FCC',mensajes[0]);self.assertIn('RMS',mensajes[0])
  self.assertIn('HC Code 6',mensajes[1]);self.assertIn('Peak',mensajes[1])

if __name__=='__main__':unittest.main()
