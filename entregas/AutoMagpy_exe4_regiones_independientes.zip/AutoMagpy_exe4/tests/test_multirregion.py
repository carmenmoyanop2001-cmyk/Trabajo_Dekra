import ast,copy,json,math,os,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime
import pandas as pd
import openpyxl
import test_excel

BASE=Path(__file__).resolve().parents[1]
TREE=ast.parse((BASE/'automatizacion_magpy3_exe4.py').read_text())

def load(names,ns):
 exec(compile(ast.Module(body=[n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'core','exec'),ns)

def config(ns):
 ns.update(DURACION_6MIN=360,DURACION_30MIN=1800,DURACION_2MIN=120,
           NOM_6MIN=360,NOM_30MIN=1800,NOM_2MIN=120,MS_6MIN=360000,MS_30MIN=1800000,MS_2MIN=120000)
 for n in TREE.body:
  if isinstance(n,ast.Assign) and any(getattr(t,'id','') in ['CONFIG_REGION','EXCEL_COL_MAP'] for t in n.targets):
   exec(compile(ast.Module(body=[n],type_ignores=[]),'config','exec'),ns)

class MultirregionTests(unittest.TestCase):
 def test_secuencia_plan_ised_fcc_no_comparte_rms(self):
  ns={};config(ns);load({'calcular_plan_medida','regiones_en_orden'},ns)
  plan=ns['calcular_plan_medida'](['FCC','ISED'])
  self.assertEqual([(p['region'],p['modo'],p['nominal_s']) for p in plan['secuencia']],
   [('ISED','RMS',360),('ISED','Peak',120),('FCC','RMS',1800)])
  self.assertEqual(plan['duracion_rms_nominal_s']+plan['duracion_peak_nominal_s'],38*60)
 def test_tres_regiones_tienen_cuatro_adquisiciones(self):
  ns={};config(ns);load({'calcular_plan_medida','regiones_en_orden'},ns)
  plan=ns['calcular_plan_medida'](['CE','FCC','ISED'])
  self.assertEqual([p['region'] for p in plan['secuencia']],['ISED','ISED','CE','FCC'])
  self.assertEqual(sum(p['nominal_s'] for p in plan['secuencia']),44*60)
 def ejecutar_real(self,regiones):
  fixture=test_excel.ExcelTests();fixture.setUp();self.addCleanup(fixture.doCleanups)
  wb=openpyxl.load_workbook(fixture.path)
  wb.create_sheet('FCC Results');wb.create_sheet('EN Results');wb.save(fixture.path);wb.close()
  ns=fixture.ns;config(ns)
  duraciones=[];referencias=[];secuencia=[];muestras=[]
  campos=iter([1.,2.,5.] if len(regiones)==2 else [1.,2.,4.,5.])
  def collector(api_location):
   h=next(campos)
   filas=[dict(timestamp=700*i,frequency=125000.,h_field_rms_x=h,h_field_rms_y=0,h_field_rms_z=0,
       e_field_rms_x=h*2,e_field_rms_y=0,e_field_rms_z=0) for i in range(3)]
   muestras.append(copy.deepcopy(filas));referencias.append(api_location)
   return SimpleNamespace(filas_measurement=filas,ts_inicio_ms=0,detener=lambda:None)
  ns.update(pd=pd,math=math,ColectorDatos=collector,
    DIST_COMPROBACION_CM=3.,DIST_PICO_CONTACTO_CM=0.,AVISO_TECLADO='Cierra teclado',
    preparar_region_medida=lambda r:secuencia.append(r) or True,
    sep=lambda *a:None,beep=lambda *a:None,cuadro=lambda *a:None,enter=lambda *a:None,
    click_clear_gui=lambda:None,time=SimpleNamespace(sleep=lambda *a:None),
    iniciar_medida_con_reintentos=lambda *a,**k:True,
    barra_progreso=lambda duracion,etiqueta:duraciones.append(duracion),
    parar_medida=lambda:None,capturar_pantalla=lambda *a:None,guardar_datos_zip=lambda *a:None,
    _registrar_promedio_fcc=lambda *a:None)
  load({'procesar_posicion','_procesar_posicion_regiones','calcular_plan_medida','regiones_en_orden',
        'promediar_medidas','calcular_peak_desde_rms','calcular_h_total','calcular_e_total',
        'modo_por_distancia','filas_resumen_regionales','_fila_resumen'},ns)
  ns.update(UMBRAL_TIP_MAX_CM=.75,UMBRAL_PROBE_CENTER_CM=1.85)
  resultado=ns['procesar_posicion']('Left',fixture.tmp.name,regiones,0,125,str(fixture.path),'RFID','N/A','N/A',peak_fisico=True)
  return fixture,ns,resultado,duraciones,referencias,secuencia
 def test_adquisiciones_reales_y_excel_independientes(self):
  fixture,ns,resultado,dur,refs,orden=self.ejecutar_real(['FCC','ISED'])
  self.assertEqual(dur,[360,120,1800]);self.assertEqual(orden,['ISED','FCC'])
  self.assertEqual(refs,['tip-max']*3)
  rows=ns['filas_resumen_regionales']('Left',['FCC','ISED'],0,125,resultado[1])
  self.assertEqual([(r['regiones'],r['h_prom_A_m']) for r in rows],[('ISED',1.),('FCC',5.)])
  wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
  self.assertEqual(wb['ISED Results'].cell(9,17).value,1.)
  self.assertEqual(wb['ISED Results'].cell(9,42).value,round(2*math.sqrt(2),4))
  self.assertEqual(wb['FCC Results'].cell(9,17).value,5.)
 def test_tres_regiones_usan_tres_resultados_rms(self):
  _,ns,resultado,dur,_,orden=self.ejecutar_real(['CE','FCC','ISED'])
  self.assertEqual(dur,[360,120,360,1800]);self.assertEqual(orden,['ISED','CE','FCC'])
  rows=ns['filas_resumen_regionales']('Left',['CE','FCC','ISED'],0,125,resultado[1])
  self.assertEqual([(r['regiones'],r['h_prom_A_m']) for r in rows],[('ISED',1.),('CE',4.),('FCC',5.)])
 def test_reintento_no_repite_regiones_completadas(self):
  llamadas=[];ns=dict(os=os,preparar_region_medida=lambda r:True,
      preguntar_opcion=lambda *a:'REPETIR',promedio_completo=lambda p,**k:bool(p))
  def medir(nombre,carpeta,regiones,*a,**kw):
   r=regiones[0];llamadas.append(r)
   if llamadas==['ISED','FCC']:return carpeta,None,None,0
   return carpeta,{'h_prom':1,'e_prom':2},({'h_prom':2,'e_prom':4} if r=='ISED' else None),0
  ns['procesar_posicion']=medir;load({'_procesar_posicion_regiones','regiones_en_orden'},ns)
  ns['_procesar_posicion_regiones']('A','out',['FCC','ISED'],0,125,None,'','','')
  self.assertEqual(llamadas,['ISED','FCC','FCC'])
 def test_distancia_y_peak_puntual_antes_de_fcc(self):
  eventos=[];ns=dict(os=os,preparar_region_medida=lambda r:True,
   promedio_completo=lambda p,**k:bool(p),DIST_PICO_CONTACTO_CM=0.)
  def medir(nombre,carpeta,regiones,d,*a,**kw):
   eventos.append((regiones[0],'RMS',d))
   return carpeta,{'h_prom':1,'e_prom':2},None,d
  def pico(*a):eventos.append(('ISED','Peak',a[2]));return {'h_prom':3,'e_prom':6}
  ns.update(procesar_posicion=medir,medir_peak_posicion=pico)
  load({'_procesar_posicion_regiones','regiones_en_orden','filas_resumen_regionales','_fila_resumen'},ns)
  resultado=ns['_procesar_posicion_regiones']('A','out',['ISED','FCC'],20,125,None,'','','',solo_rms=True,contacto_puntual=True,contacto_fcc=True)
  self.assertEqual(eventos,[('ISED','RMS',20),('ISED','Peak',0),('FCC','RMS',0)])
  rows=ns['filas_resumen_regionales']('A',['ISED','FCC'],20,125,resultado[1])
  self.assertEqual([r['distancia_cm'] for r in rows],[20,0])
 def test_fcc_contacto_tiene_distancia_propia(self):
  ns={};load({'distancia_base_fcc'},ns)
  self.assertEqual(ns['distancia_base_fcc'](['ISED','FCC'],20,'puntual'),0)
  self.assertEqual(ns['distancia_base_fcc'](['ISED','FCC'],20,'no'),20)
 def test_referencias_con_umbral_de_la_imagen(self):
  ns=dict(UMBRAL_TIP_MAX_CM=.75,UMBRAL_PROBE_CENTER_CM=1.85);load({'modo_por_distancia'},ns)
  for d,esperado in [(0,'Tip Max'),(.749,'Tip Max'),(.75,'Sensor Max'),(1.85,'Sensor Max'),(1.851,'Probe Center'),(2,'Probe Center'),(3,'Probe Center'),(4,'Probe Center')]:
   self.assertEqual(ns['modo_por_distancia'](d)[0],esperado)
 def test_cambio_estandar_pide_y_valida_la_region_correcta(self):
  llamados=[];validaciones=iter([False,True]);ns=dict(AVISO_TECLADO='Cierra teclado',cuadro=lambda *a:None,
   enter=lambda t:llamados.append(t),validar_configuracion_magpy=lambda r:next(validaciones),preguntar_opcion=lambda *a:'REINTENTAR')
  config(ns);load({'preparar_region_medida'},ns)
  self.assertTrue(ns['preparar_region_medida']('FCC'))
  self.assertEqual(len(llamados),2);self.assertTrue(all('FCC' in t and 'RMS' in t for t in llamados))
 def test_resultados_validaciones_json_por_region(self):
  with tempfile.TemporaryDirectory() as tmp:
   ns=dict(os=os,json=json,datetime=datetime,msg=lambda *a:None)
   load({'guardar_validacion_region','guardar_json_atomico'},ns)
   a=ns['guardar_validacion_region'](tmp,'ISED','E_H_3cm',{'estado':'OK'})
   b=ns['guardar_validacion_region'](tmp,'FCC','Estimated_Measured',{'estado':'NO_CUMPLE'})
   self.assertNotEqual(a,b)
   self.assertEqual(json.loads(Path(a).read_text())['region'],'ISED')
   self.assertEqual(json.loads(Path(b).read_text())['estado'],'NO_CUMPLE')
 def test_csv_por_region_no_copia_h_entre_estandares(self):
  with tempfile.TemporaryDirectory() as tmp:
   ns=dict(os=os,pd=pd,msg=lambda *a:None,sep=lambda *a:None,print=lambda *a:None)
   load({'guardar_csv_resumen'},ns)
   ns['guardar_csv_resumen']([{'posicion':'A','regiones':'ISED','h_prom_A_m':1},
                             {'posicion':'A','regiones':'FCC','h_prom_A_m':5}],str(Path(tmp)/'resumen.csv'))
   self.assertEqual(pd.read_csv(Path(tmp)/'resumen_ISED.csv',sep=';')['h_prom_A_m'][0],1)
   self.assertEqual(pd.read_csv(Path(tmp)/'resumen_FCC.csv',sep=';')['h_prom_A_m'][0],5)


class InterfazYPeoresCasosTests(unittest.TestCase):
 def test_resumen_muestra_38_min_y_fcc_0cm_en_contacto_puntual(self):
  ns={};config(ns)
  load({'calcular_plan_medida','regiones_en_orden','modo_por_distancia','distancia_base_fcc','fcc_aplica_validacion_cero'},ns)
  ns.update(UMBRAL_TIP_MAX_CM=.75,UMBRAL_PROBE_CENTER_CM=1.85,FCC_CERO_CM_MAX=.1)
  core=SimpleNamespace(**ns,FCC_DISTANCIA_MIN_VALIDACION_CM=20)
  texto=[]
  gui=ast.parse((BASE/'gui_magpy3_exe4.py').read_text())
  cls=next(n for n in gui.body if isinstance(n,ast.ClassDef) and n.name=='AppMagpy3')
  metodo=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_mostrar_resumen_y_confirmar')
  ctx=dict(core=core,messagebox=SimpleNamespace(askokcancel=lambda titulo,mensaje:texto.append(mensaje) or False))
  exec(compile(ast.Module(body=[metodo],type_ignores=[]),'gui','exec'),ctx)
  cfg=dict(plan=ns['calcular_plan_medida'](['FCC','ISED']),regiones=['FCC','ISED'],contacto='puntual',
   nombres_regiones='FCC, ISED',n_posiciones=4,distancia_cm=20,frecuencia=125,technology='RFID',
   wpt_client='N/A',battery='N/A',carpeta_raiz='out',ruta_excel='test.xlsx')
  ctx['_mostrar_resumen_y_confirmar'](SimpleNamespace(),cfg)
  self.assertIn('38 min en adquisiciones independientes',texto[0])
  self.assertIn('FCC: RMS a 0 cm, Tip Max',texto[0])
  self.assertIn('ISED: RMS a 20 cm, Probe Center',texto[0])
  self.assertIn('peor posicion propia',texto[0])
  self.assertIn('Estimated y Measured a 2 y 4 cm',texto[0])

 def test_gui_exporta_regiones_separadas_no_copia_ised_a_fcc(self):
  import queue
  ctx=dict(eventos_q=queue.Queue(),datetime=datetime,_pedir_respuesta=lambda:'A',
    SesionAbortadaPorOperador=type('Abortada',(Exception,),{}))
  datos=[]
  core=SimpleNamespace(verificar_conexion=lambda:True,validar_configuracion_magpy=lambda r:True,
   configurar_adquisicion=lambda f:None,time=SimpleNamespace(sleep=lambda t:None),reiniciar_historial_fcc=lambda:None,
   medir_ruido_ambiente=lambda *a:('OK',[]),msg=lambda *a:None,
   fcc_aplica_validacion_cero=lambda *a:False,validar_estimado_medido_fcc=lambda *a,**k:('NA',[]),
   validar_caida_fcc=lambda *a,**k:('NA',[]),FCC_DISTANCIA_MIN_VALIDACION_CM=20,
   guardar_csv_resumen=lambda filas,ruta:datos.append((copy.deepcopy(filas),ruta)))
  ns={};load({'filas_resumen_regionales','_fila_resumen','distancia_base_fcc'},ns)
  core.filas_resumen_regionales=ns['filas_resumen_regionales'];core.distancia_base_fcc=ns['distancia_base_fcc']
  uno=dict(h_prom=1,e_prom=2,freq_mhz=.125);dos=dict(h_prom=5,e_prom=6,freq_mhz=.125)
  pico=dict(h_prom=3,e_prom=4,freq_mhz=.125)
  core.procesar_posicion=lambda *a,**k:('out',dict(uno,_por_region={'ISED':uno,'FCC':dos}),dict(pico,_por_region={'ISED':pico}),0)
  ctx['core']=core
  gui=ast.parse((BASE/'gui_magpy3_exe4.py').read_text())
  f=next(n for n in gui.body if isinstance(n,ast.FunctionDef) and n.name=='hilo_sesion_medida')
  exec(compile(ast.Module(body=[f],type_ignores=[]),'gui','exec'),ctx)
  cfg=dict(regiones=['FCC','ISED'],carpeta_raiz='out',ruta_excel=None,n_posiciones=1,distancia_cm=0,
           frecuencia=125,technology='',wpt_client='',battery='',archivo_csv='rms.csv',archivo_csv_peak='peak.csv',
           nombres_regiones='FCC,ISED',contacto='no')
  ctx['hilo_sesion_medida'](cfg)
  self.assertEqual([(r['regiones'],r['h_prom_A_m']) for r in datos[0][0]],[('ISED',1),('FCC',5)])
  self.assertEqual([(r['regiones'],r['h_prom_A_m']) for r in datos[1][0]],[('ISED',3)])
  eventos=[]
  while not ctx['eventos_q'].empty():eventos.append(ctx['eventos_q'].get()[0])
  self.assertIn('SESION_COMPLETADA',eventos);self.assertNotIn('ERROR_FATAL',eventos)

 def test_ised_y_fcc_eligen_peores_posiciones_independientes(self):
  seleccion=[]
  ns=dict(math=math,os=os,DIST_PICO_CONTACTO_CM=0.,DIST_COMPROBACION_CM=3.,NOMBRE_RUIDO='Ruido',
   _accion_fallo_consola=lambda n:'ABORTAR',cuadro=lambda *a:None,enter=lambda *a:None,msg=lambda *a:None,
   preparar_region_medida=lambda r:True)
  load({'regiones_en_orden','_procesar_posicion_regiones','medidas_con_contacto',
        '_medir_posiciones_con_reintento','promedio_completo','filas_resumen_regionales','_fila_resumen',
        'peor_posicion_h'},ns)
  def medir(nombre,carpeta,regiones,d,*a,**kw):
   if len(regiones)>1:
    return ns['_procesar_posicion_regiones'](nombre,carpeta,regiones,d,*a,**kw)
   r=regiones[0]
   h=({'P1':1,'P2':9} if r=='ISED' else {'P1':99,'P2':2})[nombre]
   rms=dict(h_prom=h,e_prom=2,freq_mhz=.125)
   return carpeta,rms,(dict(h_prom=h*2,e_prom=4,freq_mhz=.125) if r=='ISED' else None),d
  def adicional(*args):
   seleccion.append(args[0]);return 'OK',args[-3],args[-2],args[-1]
  ns.update(procesar_posicion=medir,_medida_peor_posicion=adicional)
  estado,filas,picos,n=ns['medidas_con_contacto'](['FCC','ISED'],0,125,'out',None,'','','',lambda i,n:f'P{i}',2,True)
  self.assertEqual(estado,'OK');self.assertEqual(seleccion,['P2'])
  self.assertEqual(ns['peor_posicion_h'](filas,0,'FCC')['posicion'],'P1')

class ContactoPuntualRegionalTests(unittest.TestCase):
 def test_seleccion_contacto_no_contamina_resultados_fcc(self):
  calls=[];peores=[]
  ns=dict(DIST_PICO_CONTACTO_CM=0.,pedir_numero=lambda *a:1,
   preguntar_opcion=lambda *a:'P2',cuadro=lambda *a:None)
  load({'_medidas_puntuales_regionales','filas_resumen_regionales','_fila_resumen'},ns)
  def process(nombre,*a,**kw):
   calls.append((nombre,kw['contacto_puntual'],kw['contacto_fcc']))
   rms=dict(h_prom=1,e_prom=2,_por_region={'ISED':dict(h_prom=1,e_prom=2),'FCC':dict(h_prom=5,e_prom=6)},
            _distancias_region={'ISED':20,'FCC':0})
   pico=(dict(h_prom=3,e_prom=4,_por_region={'ISED':dict(h_prom=3,e_prom=4)}) if kw['contacto_puntual'] else None)
   return 'out',rms,pico,0
  def adicional(*a):peores.append(a[0]);return 'OK',a[-3],a[-2],a[-1]
  ns.update(procesar_posicion=process,_medida_peor_posicion=adicional)
  estado,rms,pico,n=ns['_medidas_puntuales_regionales'](['FCC','ISED'],20,125,'out',None,'','','',lambda i,n:f'P{i}',2,None)
  self.assertEqual(estado,'OK');self.assertEqual(calls,[('P1',False,True),('P2',True,True)])
  self.assertEqual(len(rms),4);self.assertEqual(len(pico),1);self.assertEqual(peores,['P2'])
  self.assertEqual({r['distancia_cm'] for r in rms if r['regiones']=='FCC'},{0})
  self.assertEqual(pico[0]['regiones'],'ISED')

 def test_repetir_pico_no_repite_rms_ni_otra_region(self):
  eventos=[];picos=iter([None,dict(h_prom=3,e_prom=6)])
  ns=dict(os=os,DIST_PICO_CONTACTO_CM=0.,preparar_region_medida=lambda r:True,
    promedio_completo=lambda p,**k:bool(p),preguntar_opcion=lambda *a:'REPETIR')
  def process(nombre,carpeta,regiones,d,*a,**k):
   eventos.append((regiones[0],'RMS'));return carpeta,dict(h_prom=1,e_prom=2),None,d
  def peak(*a):eventos.append(('ISED','Peak'));return next(picos)
  ns.update(procesar_posicion=process,medir_peak_posicion=peak)
  load({'_procesar_posicion_regiones','regiones_en_orden'},ns)
  ns['_procesar_posicion_regiones']('A','out',['ISED','FCC'],20,125,None,'','','',solo_rms=True,
    contacto_puntual=True,contacto_fcc=True)
  self.assertEqual(eventos,[('ISED','RMS'),('ISED','Peak'),('ISED','Peak'),('FCC','RMS')])

if __name__=='__main__':unittest.main()
