import ast,math,os,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime
import pandas as pd
import test_multirregion as r

BASE=r.BASE
CORE=r.TREE
GUI=ast.parse((BASE/'gui_magpy3_exe4.py').read_text())

class RestriccionPortatilTests(unittest.TestCase):
 def test_limites_de_la_imagen(self):
  ns={};r.load(set(),ns)
  for regiones,d,f,permitido in [(['ISED'],0,3,True),(['FCC'],19.999,4000,True),
      (['FCC','ISED'],19.999,4000.001,False),(['ISED'],0,2.999,False),
      (['FCC'],20,5000,True),(['CE'],0,5000,True)]:
   with self.subTest(regiones=regiones,d=d,f=f):
    self.assertEqual(ns['error_restriccion_portatil'](regiones,d,f) is None,permitido)
 def test_contacto_puntual_previene_frecuencia_invalida_para_el_peak_0(self):
  ns={};r.load(set(),ns)
  with self.assertRaisesRegex(ValueError,'SAR'):
   ns['validar_plan_portatil'](dict(regiones=['ISED','FCC'],distancia_cm=20,frecuencia=5000,contacto='puntual'))
  ns['validar_plan_portatil'](dict(regiones=['ISED','FCC'],distancia_cm=20,frecuencia=5000,contacto='no'))
 def test_formulario_rechaza_antes_de_iniciar_la_sesion(self):
  ns={};r.config(ns);r.load({'calcular_plan_medida'},ns)
  core=SimpleNamespace(**ns)
  ctx=dict(core=core,os=os,datetime=datetime,ErrorValidacion=type('ErrorValidacion',(Exception,),{}))
  f=next(n for n in GUI.body if isinstance(n,ast.FunctionDef) and n.name=='validar_config_formulario')
  exec(compile(ast.Module(body=[f],type_ignores=[]),'GUI','exec'),ctx)
  with tempfile.TemporaryDirectory() as tmp:
   datos=dict(regiones=['ISED','FCC'],carpeta_raiz=tmp,ruta_excel='',n_posiciones='1',contacto='puntual',
     distancia_cm='20',frecuencia='5000',technology='',wpt_client='',battery='')
   with self.assertRaisesRegex(ctx['ErrorValidacion'],'SAR'):ctx['validar_config_formulario'](datos)
   datos['contacto']='no'
   self.assertEqual(ctx['validar_config_formulario'](datos)['frecuencia'],5000)
 def test_guardia_runtime_no_arranca_medida_fuera_de_rango(self):
  ns={};r.load({'procesar_posicion'},ns)
  with self.assertRaisesRegex(ValueError,'SAR'):
   ns['procesar_posicion']('P1','out',['ISED'],0,5000,None,'','','')

class MensajesCapturasYContactoTests(unittest.TestCase):
 def test_puntual_hace_3cm_y_solo_guarda_capturas_peak(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   r.load({'medidas_con_contacto','_medidas_puntuales_regionales','promedio_completo',
           'filas_resumen_regionales','_fila_resumen','_medida_peor_posicion','_medir_posiciones_con_reintento',
           'comprobar_eh','guardar_validacion_region','guardar_json_atomico'},ns)
   capturas=[];instrucciones=[]
   ns.update(pedir_numero=lambda *a:2,_accion_fallo_consola=lambda *a:'ABORTAR',
    EH_LIMITE_OHM=37.7,capturar_pantalla=lambda carpeta,nombre:capturas.append(nombre),
    enter=instrucciones.append)
   estado,filas,picos,n=ns['medidas_con_contacto'](regiones,20,125,fixture.tmp.name,str(fixture.path),
            'RFID','N/A','N/A',lambda i,n:f'P{i}',2,False)
   self.assertEqual(estado,'OK');self.assertEqual(len(picos),3)
   self.assertTrue(any(f['distancia_cm']==3 for f in filas))
   self.assertTrue(any(f['distancia_cm']==3 for f in picos))
   self.assertEqual(capturas,['pico_0cm_P1','pico_0cm_P2','pico_3cm_P2_3cm'])
   self.assertFalse(any('Selecciona HC Code' in t or 'Selecciona FCC' in t for t in instrucciones))
   return None,None,None,None
  _,_,_,dur,_,_=case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
  self.assertEqual(dur,[1800,1800,120,120,360,120])
 def test_si_si_peak_mantiene_la_misma_posicion(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   instrucciones=[];capturas=[]
   ns.update(enter=instrucciones.append,capturar_pantalla=lambda carpeta,nombre:capturas.append(nombre))
   resultado=ns['procesar_posicion']('Actual',fixture.tmp.name,regiones,0,125,str(fixture.path),'RFID','N/A','N/A',peak_fisico=True)
   pico=next(t for t in instrucciones if '[ISED] PEAK' in t)
   self.assertIn('Manten la sonda',pico);self.assertIn('no la reposiciones',pico)
   self.assertIn('Peak/RMS = Peak',pico);self.assertIn('Tip Max',pico)
   self.assertEqual(capturas,['pico_0cm_Actual'])
   return resultado
  case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
 def test_rms_solo_no_toma_capturas(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   def prohibido(*a):raise AssertionError('Captura RMS no permitida')
   ns['capturar_pantalla']=prohibido
   return ns['procesar_posicion']('P1',fixture.tmp.name,regiones,20,125,str(fixture.path),'RFID','N/A','N/A',solo_rms=True)
  case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
 def test_ruido_no_toma_capturas(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   r.load({'medir_ruido_ambiente'},ns)
   def prohibido(*a):raise AssertionError('Captura de ruido no permitida')
   ns.update(capturar_pantalla=prohibido,NOMBRE_RUIDO='Ruido',RUIDO_API_LOCATION=None,pedir_valor=lambda *a:6)
   estado,_=ns['medir_ruido_ambiente'](fixture.tmp.name,regiones,125,None,'','','')
   self.assertEqual(estado,'OK')
   return None,None,None,None
  case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
 def test_nombre_captura_sin_caracteres_invalidos_windows(self):
  ns={};r.load(set(),ns)
  self.assertEqual(ns['nombre_captura_pico']('Right / Edge: *?',0),'pico_0cm_Right_Edge')
  self.assertEqual(ns['nombre_captura_pico']('Left',3),'pico_3cm_Left')

class DiagnosticoMuestrasTests(unittest.TestCase):
 def ns(self):
  ns=dict(pd=pd,math=math,msg=lambda *a:None)
  r.load({'promediar_medidas','calcular_h_total','calcular_e_total','calcular_peak_desde_rms'},ns)
  return ns
 def fila(self,**kw):
  return dict(timestamp=0,frequency=125000,h_field_rms_x=1,h_field_rms_y=0,h_field_rms_z=0,
               e_field_rms_x=2,e_field_rms_y=0,e_field_rms_z=0,**kw)
 def test_sin_frecuencia_no_crashea_ni_inventa_campos(self):
  ns=self.ns();fila=self.fila();fila['frequency']=None
  prom=ns['promediar_medidas']([fila],1000,0)
  self.assertEqual(prom['h_prom'],1);self.assertIsNone(prom['freq_hz'])
 def test_frecuencia_cero_no_produce_division_por_cero(self):
  ns=self.ns();a=self.fila();b=self.fila();a['frequency']=0;b['frequency']=125000
  prom=ns['promediar_medidas']([a,b],1000,0)
  self.assertEqual(prom['h_prom'],1)
 def test_campos_ausentes_no_se_sustituyen_por_cero(self):
  ns=self.ns();prom=ns['promediar_medidas']([{'timestamp':0,'frequency':125000}],1000,0)
  self.assertIsNone(prom['h_prom']);self.assertIsNone(prom['e_prom'])
  self.assertIn('H sin muestras',ns['motivo_resultado_invalido'](prom))
 def test_ceros_reales_siguen_siendo_validos(self):
  ns=self.ns();fila=self.fila();fila['h_field_rms_x']=0;fila['e_field_rms_x']=0
  prom=ns['promediar_medidas']([fila],1000,0)
  self.assertEqual(prom['h_prom'],0);self.assertEqual(prom['e_prom'],0)
 def test_muestra_fuera_de_ventana_no_se_usa_de_reserva(self):
  ns=self.ns();fila=self.fila();fila['timestamp']=2000
  prom=ns['promediar_medidas']([fila],1000,0)
  self.assertIsNone(prom['h_prom']);self.assertIn('ventana temporal',prom['motivo'])
 def test_no_finitos_tienen_un_motivo_claro(self):
  ns=self.ns()
  self.assertIn('H no finito',ns['motivo_resultado_invalido']({'h_prom':float('inf'),'e_prom':1}))


class ISEDSoloTests(unittest.TestCase):
 def test_solo_ised_a0_no_anula_peak_por_variacion_entre_frames(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   original=ns['ColectorDatos']
   def colector(**kw):
    obj=original(**kw)
    obj.filas_measurement=[dict(f,frequency=125000+i*1000) for i,f in enumerate(obj.filas_measurement)]
    return obj
   ns['ColectorDatos']=colector
   resultado=ns['procesar_posicion']('Solo',fixture.tmp.name,['ISED'],0,125,str(fixture.path),
       'RFID','N/A','N/A',peak_fisico=True)
   self.assertTrue(math.isfinite(resultado[1]['h_prom']))
   self.assertTrue(math.isfinite(resultado[2]['h_prom']))
   self.assertTrue(math.isfinite(resultado[2]['e_prom']))
   self.assertFalse(resultado[2]['multi_frecuencia'])
   self.assertEqual(ns['acciones'].count('captura'),1)
   return resultado
  _,_,_,dur,_,_=case.ejecutar_real(['ISED'],ejecutar=ejecutar)
  self.assertEqual(dur,[360,120])


class EstadoTerminalTests(unittest.TestCase):
 def test_se_muestran_los_pasos_de_io_y_los_cortes_rms(self):
  ns=dict(LOG_MODE='ESSENTIAL')
  r.load({'_mensaje_esencial'},ns)
  for texto in ['Guardando datos: 100 filas','Abriendo Excel: ISED',
                'Escribiendo y verificando Excel: ISED','[ISED] Corte RMS 6 min recogido']:
   self.assertTrue(ns['_mensaje_esencial'](texto,'ESPERA'))

if __name__=='__main__':unittest.main()
