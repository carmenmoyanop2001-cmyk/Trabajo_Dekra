import ast,json,unittest
from pathlib import Path
import openpyxl
import test_multirregion as r
BASE=Path(__file__).resolve().parents[1]
REF=json.loads((BASE/'tests/referencia_gui_magpy3.json').read_text())

def literal(p,nombre):
 tree=ast.parse(p.read_text())
 return ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign)
   and any(getattr(t,'id','')==nombre for t in n.targets)))

class IntegracionAdjuntoTests(unittest.TestCase):
 def test_conserva_funciones_y_mapa_excel_del_adjunto(self):
  tree=ast.parse((BASE/'automatizacion_magpy3_exe4.py').read_text())
  funciones={n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
  self.assertTrue(set(REF['funciones_core'])<=funciones)
  self.assertEqual(literal(BASE/'automatizacion_magpy3_exe4.py','EXCEL_COL_MAP'),REF['excel_col_map'])
 def test_perfil_y_persistencia_compatibles_con_adjunto(self):
  p=BASE/'config_store_exe4.py'
  self.assertEqual(list(literal(p,'CLAVES_PERFIL')),REF['claves_perfil'])
  self.assertEqual(literal(p,'NOMBRE_APP'),REF['nombre_app'])
 def test_canada_6_usa_30_escritos_en_columnas_del_adjunto(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  fixture,ns,resultado,duraciones,_,_=case.ejecutar_real(['FCC','ISED'])
  # Un solo RMS de 30 min. La segunda adquisicion es el PEAK separado.
  self.assertEqual(duraciones,[1800,120])
  self.assertEqual(ns['acciones'].count('start'),2)
  wb=openpyxl.load_workbook(fixture.path)
  try:
   for region,hoja,h,e in [('ISED','ISED Results',1.,2.),('FCC','FCC Results',4.6,9.2)]:
    for bloque in REF['excel_col_map'][region]:
     if bloque['valor']!='RMS':continue
     self.assertEqual(wb[hoja].cell(9,bloque['hfield']).value,h)
     self.assertEqual(wb[hoja].cell(9,bloque['efield']).value,e)
     self.assertEqual(wb[hoja].cell(9,bloque['freq_h']).value,.125)
     self.assertEqual(wb[hoja].cell(9,bloque['testside']).value,'Left')
  finally:wb.close()

if __name__=='__main__':unittest.main()
