import ast,math,os,unittest
from pathlib import Path
import openpyxl
import test_multirregion as r

class DistanciaFormularioTests(unittest.TestCase):
 def test_un_solo_rms_30_a20_excel_con_corte6_y_sin_pedir0(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   instrucciones=[];ns['enter']=instrucciones.append
   resultado=ns['procesar_posicion']('Primera',fixture.tmp.name,regiones,20,125,
                    str(fixture.path),'RFID','N/A','N/A',solo_rms=True)
   self.assertEqual(ns['acciones'].count('start'),1)
   self.assertEqual(ns['acciones'].count('stop'),1)
   self.assertTrue(all('a 0 cm' not in t for t in instrucciones))
   self.assertTrue(any('20 cm' in t and 'primeros 6 min' in t for t in instrucciones))
   self.assertEqual(resultado[1]['_distancias_region'],{'ISED':20,'FCC':20})
   self.assertEqual(resultado[1]['_por_region']['ISED']['h_prom'],1)
   self.assertEqual(resultado[1]['_por_region']['FCC']['h_prom'],4.6)
   wb=openpyxl.load_workbook(fixture.path)
   try:
    self.assertEqual(wb['ISED Results'].cell(9,6).value,20)
    self.assertEqual(wb['FCC Results'].cell(9,6).value,20)
    self.assertEqual(wb['ISED Results'].cell(9,17).value,1)
    self.assertEqual(wb['FCC Results'].cell(9,17).value,4.6)
   finally:wb.close()
   return resultado
  _,_,_,duraciones,referencias,_=case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
  self.assertEqual(duraciones,[1800]);self.assertEqual(referencias,['probe-center'])

 def test_puntual_dos_posiciones_rms20_y_peak0_al_final(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   r.load({'medidas_con_contacto','_medidas_puntuales_regionales','filas_resumen_regionales',
           '_fila_resumen','promedio_completo','distancia_base_fcc'},ns)
   ns.update(pedir_numero=lambda *a:2,_accion_fallo_consola=lambda *a:'ABORTAR')
   extras=[]
   def adicional(*a):extras.append(a[0]);return 'OK',a[-3],a[-2],a[-1]
   ns['_medida_peor_posicion']=adicional
   estado,rms,picos,n=ns['medidas_con_contacto'](regiones,20,125,fixture.tmp.name,str(fixture.path),
         'RFID','N/A','N/A',lambda i,n:f'P{i}',2,False)
   self.assertEqual(estado,'OK')
   self.assertEqual({fila['distancia_cm'] for fila in rms},{20})
   self.assertEqual({fila['regiones'] for fila in picos},{'ISED'})
   self.assertEqual({fila['distancia_cm'] for fila in picos},{0})
   self.assertEqual(len(rms),4);self.assertEqual(len(picos),2)
   wb=openpyxl.load_workbook(fixture.path)
   try:
    for fila in [9,10]:
     self.assertEqual(wb['ISED Results'].cell(fila,6).value,20)
     self.assertEqual(wb['FCC Results'].cell(fila,6).value,20)
     self.assertEqual(wb['ISED Results'].cell(fila,31).value,0)
   finally:wb.close()
   return None,None,None,None
  _,_,_,duraciones,referencias,_=case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
  self.assertEqual(duraciones,[1800,1800,120,120])
  self.assertEqual(referencias,['probe-center','probe-center','tip-max','tip-max'])

 def test_fcc_20_aplica_1d_y_no_estimated_measured_0(self):
  ns={};r.config(ns)
  r.load({'distancia_base_fcc','fcc_aplica_validacion_cero'},ns)
  ns['FCC_CERO_CM_MAX']=.1
  d=ns['distancia_base_fcc'](['ISED','FCC'],20,'puntual')
  self.assertEqual(d,20)
  self.assertFalse(ns['fcc_aplica_validacion_cero'](['ISED','FCC'],d))

if __name__=='__main__':unittest.main()
