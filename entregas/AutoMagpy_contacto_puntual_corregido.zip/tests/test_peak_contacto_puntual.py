import ast
import copy
import math
from pathlib import Path
from types import SimpleNamespace
import unittest
import pandas as pd
import openpyxl
import test_excel

BASE=Path(__file__).resolve().parents[1]

def funciones(path):
 return {n.name:ast.dump(n) for n in ast.parse(path.read_text()).body
         if isinstance(n,(ast.FunctionDef,ast.ClassDef))}

class PuntualTests(unittest.TestCase):
 def test_ultima_posicion_peak_se_guarda_con_frecuencia_configurada(self):
  fixture=test_excel.ExcelTests();fixture.setUp();self.addCleanup(fixture.doCleanups)
  ns=fixture.ns
  filas=[dict(timestamp=i*700,frequency=f,h_field_rms_x=1,h_field_rms_y=2,h_field_rms_z=2,
               e_field_rms_x=2,e_field_rms_y=0,e_field_rms_z=0)
         for i,f in enumerate([124500.,125000.,125500.])]
  originales=copy.deepcopy(filas)
  colector=SimpleNamespace(filas_measurement=filas,ts_inicio_ms=0,iniciar=lambda:None,detener=lambda:None)
  ns.update(pd=pd,math=math,ColectorDatos=lambda **kw:colector,
    calcular_plan_medida=lambda r:dict(duracion_peak_s=120,ventanas={'ISED':{'Peak':120000}},duracion_peak_nominal_s=120),
    sep=lambda *a:None,cuadro=lambda *a:None,enter=lambda *a:None,click_clear_gui=lambda:None,
    time=SimpleNamespace(sleep=lambda t:None),
    iniciar_medida_con_reintentos=lambda *a,**kw:True,barra_progreso=lambda *a:None,
    parar_medida=lambda:None,capturar_pantalla=lambda *a:None,guardar_datos_zip=lambda *a:None)
  names={'medir_peak_posicion','promediar_medidas','calcular_peak_desde_rms','calcular_h_total','calcular_e_total'}
  tree=ast.parse((BASE/'automatizacion_magpy3.py').read_text())
  exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'core','exec'),ns)
  # Las mismas muestras disparaban la deteccion por frecuencias API distintas.
  self.assertTrue(ns['promediar_medidas'](filas,120000,0)['multi_frecuencia'])
  for nombre in ['Front','Back','Left','Right']:
   resultado=ns['medir_peak_posicion'](nombre,fixture.tmp.name,0,125,str(fixture.path),'RFID','N/A','N/A')
   self.assertIsNotNone(resultado)
   self.assertFalse(resultado['multi_frecuencia'])
   self.assertEqual(resultado['freq_mhz'],.125)
   self.assertAlmostEqual(resultado['h_prom'],3*math.sqrt(2),places=6)
   self.assertAlmostEqual(resultado['e_prom'],2*math.sqrt(2),places=6)
  self.assertEqual(filas,originales)  # No alterar las muestras ni los ZIP originales.
  wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
  self.assertEqual(wb.active.cell(12,30).value,'Right')
  self.assertEqual(wb.active.cell(12,33).value,round(2*math.sqrt(2),4))
  self.assertEqual(wb.active.cell(12,42).value,round(3*math.sqrt(2),4))

 def test_cambios_core_limitados_al_peak_puntual(self):
  import hashlib,json
  baseline=json.loads((BASE/'tests/baseline_core_functions.json').read_text())
  for name,oldmap in baseline.items():
   newmap={name:hashlib.sha256(dump.encode()).hexdigest() for name,dump in funciones(BASE/name).items()}
   self.assertEqual(set(oldmap),set(newmap))
   self.assertEqual([n for n in oldmap if oldmap[n]!=newmap[n]],['medir_peak_posicion'])

 def test_normal_y_pruebas_tienen_mismas_funciones(self):
  self.assertEqual(funciones(BASE/'automatizacion_magpy3.py'),funciones(BASE/'PRUEBAS/automatizacion_magpy3.py'))

if __name__=='__main__':unittest.main()
