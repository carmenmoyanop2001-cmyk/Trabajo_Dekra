import ast
from pathlib import Path
from types import SimpleNamespace
import unittest
BASE=Path(__file__).resolve().parents[1]
TREE=ast.parse((BASE/'gui_magpy3.py').read_text())
CLS=next(n for n in TREE.body if isinstance(n,ast.ClassDef) and n.name=='AppMagpy3')

def metodo(nombre,ns):
 n=next(n for n in CLS.body if isinstance(n,ast.FunctionDef) and n.name==nombre)
 exec(compile(ast.Module(body=[n],type_ignores=[]),'gui','exec'),ns)
 return ns[nombre]

class ResumenTests(unittest.TestCase):
 def resumen(self,contacto):
  mensajes=[]
  fases=[dict(etiqueta='6 min RMS',nominal_s=360,peak_rms='RMS'),dict(etiqueta='2 min Pico',nominal_s=120,peak_rms='Peak')]
  ns=dict(core=SimpleNamespace(CONFIG_REGION={'ISED':{'fases':fases}}),messagebox=SimpleNamespace(askokcancel=lambda titulo,texto:mensajes.append(texto) or False))
  config=dict(contacto=contacto,plan=dict(duracion_rms_nominal_s=360,duracion_peak_nominal_s=120),regiones=['ISED'],nombres_regiones='ISED',n_posiciones=4,distancia_cm=0 if contacto=='periodo' else 20,frecuencia=125,technology='RFID',wpt_client='N/A',battery='N/A',carpeta_raiz='salida',ruta_excel='medidas.xlsm')
  metodo('_mostrar_resumen_y_confirmar',ns)(SimpleNamespace(),config)
  return mensajes[0]
 def test_puntual_muestra_si_no_y_fases_separadas(self):
  t=self.resumen('puntual')
  self.assertIn('¿Se toca el equipo?         : Sí',t)
  self.assertIn('¿Durante un tiempo?        : No',t)
  self.assertIn('Contacto puntual',t)
  self.assertIn('6 min RMS en cada posición',t)
  self.assertIn('2 min PEAK solo',t)
  self.assertNotIn('config.get',t);self.assertNotIn("{'no'",t)
 def test_sin_contacto_muestra_no_no(self):
  t=self.resumen('no');self.assertIn('¿Se toca el equipo?         : No',t);self.assertIn('¿Durante un tiempo?        : No',t)
 def test_periodo_muestra_si_si(self):
  t=self.resumen('periodo');self.assertIn('¿Se toca el equipo?         : Sí',t);self.assertIn('¿Durante un tiempo?        : Sí',t)
 def test_teclado_aviso_modal_no_confirma_adquisicion(self):
  mensajes=[]
  widget=SimpleNamespace(configure=lambda **kw:None)
  app=SimpleNamespace(lbl_paso_titulo=widget,lbl_paso_texto=widget,btn_paso_continuar=widget,btn_paso_abortar=widget)
  ns=dict(messagebox=SimpleNamespace(showinfo=lambda *a,**kw:mensajes.append(a)),core=SimpleNamespace(PITIDOS_ACTIVOS=False))
  metodo('_mostrar_paso_manual',ns)(app,dict(titulo='Acción',lineas=['CIERRA la pestaña del teclado']))
  self.assertEqual(len(mensajes),1);self.assertTrue(app.esperando_paso_manual)
if __name__=='__main__':unittest.main()
