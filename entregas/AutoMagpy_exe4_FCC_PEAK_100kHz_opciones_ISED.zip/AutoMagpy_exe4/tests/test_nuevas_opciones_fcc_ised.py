import ast, math, unittest
from types import SimpleNamespace
import openpyxl
import test_multirregion as r
import test_fcc

class NuevasOpcionesTests(unittest.TestCase):
 def test_umbral_100_exacto_y_referencia_a_cualquier_distancia(self):
  ns={};r.config(ns);r.load({'calcular_plan_medida'},ns)
  for f in (3,99.999,100,125):
   for d in (0,1,20):
    with self.subTest(f=f,d=d):
     plan=ns['calcular_plan_medida'](['ISED','FCC'],d,'puntual',f)
     principales=[x for x in plan['secuencia'] if x.get('principal')]
     if f<100:
      self.assertEqual(len(principales),2)
      fcc=next(x for x in principales if x['regiones']==['FCC'])
      self.assertEqual((fcc['modo'],fcc['location'],fcc['nominal_s']),('Peak','probe-center',1800))
      self.assertEqual(principales[0]['regiones'],['ISED'])
     else:
      self.assertEqual(len(principales),1)
      self.assertEqual(principales[0]['cortes'],{'ISED':360,'FCC':1800})
 def test_fcc_solo_peak_real_sin_rms_extra_y_excel_completo(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   instrucciones=[];capturas=[]
   ns.update(enter=instrucciones.append,capturar_pantalla=lambda *a:capturas.append(a))
   resultado=ns['procesar_posicion']('P1',fixture.tmp.name,regiones,0,50,str(fixture.path),'','N/A','N/A')
   self.assertEqual(resultado[1]['_por_region']['FCC']['modo_adquisicion'],'Peak')
   self.assertIn('modo Peak',instrucciones[0]);self.assertIn('Probe Center',instrucciones[0]);self.assertIn('Cierra teclado',instrucciones[0])
   self.assertEqual(len(capturas),1)
   wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
   self.assertAlmostEqual(wb['FCC Results'].cell(9,17).value,round(4.6*math.sqrt(2),4))
   self.assertEqual(wb['FCC Results'].cell(9,5).value,'P1')
   self.assertEqual(wb['FCC Results'].cell(9,29).value,'P1')
   return resultado
  _,_,_,dur,refs,_=case.ejecutar_real(['FCC'],ejecutar=ejecutar)
  self.assertEqual(dur,[1800]);self.assertEqual(refs,['probe-center'])
 def test_ised_fcc_50khz_adquisiciones_y_excel_separados(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   instrucciones=[];ns['enter']=instrucciones.append
   result=ns['procesar_posicion']('P1',fixture.tmp.name,regiones,0,50,str(fixture.path),'RFID','','',peak_fisico=True)
   wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
   self.assertEqual(wb['ISED Results'].cell(9,17).value,1)
   self.assertEqual(wb['FCC Results'].cell(9,17).value,round(5.6*math.sqrt(2),4))
   self.assertEqual(wb['ISED Results'].cell(9,42).value,round(3*math.sqrt(2),4))
   self.assertTrue(any('modo Peak' in x and 'Probe Center' in x for x in instrucciones))
   return result
  _,_,_,dur,refs,_=case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
  self.assertEqual(dur,[360,1800,120]);self.assertEqual(refs,['tip-max','probe-center','tip-max'])
 def test_puntual_no_inicia_validaciones_fcc(self):
  ns=test_fcc.cargar({})
  for contacto in ('puntual',):
   self.assertFalse(ns['fcc_aplica_validacion_cero'](['FCC'],0,contacto))
   self.assertEqual(ns['validar_estimado_medido_fcc']([],['FCC'],0,'out',125,None,'','','',contacto=contacto),('NA',[]))
   self.assertEqual(ns['validar_caida_fcc'](['FCC'],20,'out',125,None,'','','',contacto=contacto),('NA',[]))
  self.assertEqual(ns['medidas'],[])
  self.assertTrue(ns['fcc_aplica_validacion_cero'](['FCC'],0,'periodo'))
 def test_ised_texto_cubre_las_tres_respuestas(self):
  ns={};r.load(set(),ns)
  for contacto in ('no','puntual','periodo'):
   texto=' '.join(ns['opciones_ised'](contacto,20))
   self.assertIn('RMS 6 min',texto);self.assertIn('PEAK 2 min',texto)
   if contacto!='no':self.assertIn('3 cm',texto);self.assertIn('E/H',texto)
   if contacto=='puntual':self.assertIn('20 cm',texto);self.assertIn('Al final',texto)
 def test_fcc_solo_permite_configurar_contacto_desde_formulario(self):
  ns={};r.config(ns);r.load({'calcular_plan_medida'},ns)
  import tempfile,os
  from datetime import datetime
  gui=ast.parse((r.BASE/'gui_magpy3_exe4.py').read_text())
  f=next(n for n in gui.body if isinstance(n,ast.FunctionDef) and n.name=='validar_config_formulario')
  ctx=dict(core=SimpleNamespace(**ns),os=os,datetime=datetime,ErrorValidacion=ValueError)
  exec(compile(ast.Module(body=[f],type_ignores=[]),'gui','exec'),ctx)
  with tempfile.TemporaryDirectory() as tmp:
   config=ctx['validar_config_formulario'](dict(regiones=['FCC'],carpeta_raiz=tmp,ruta_excel='',n_posiciones='1',contacto='periodo',distancia_cm='20',frecuencia='50',technology='',wpt_client='',battery=''))
   self.assertEqual(config['contacto'],'periodo');self.assertEqual(config['distancia_cm'],0)
   self.assertEqual(config['plan']['secuencia'][0]['modo'],'Peak')

class ValidacionFccConfirmadaTests(unittest.TestCase):
 def test_si_si_menor_100_conserva_cuatro_medidas_peak_estimated_measured(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   r.load({'validar_estimado_medido_fcc','fcc_aplica_validacion_cero','peor_posicion_h',
           'diferencia_estimada_medida_pct','guardar_validacion_region'},ns)
   ns.update(FCC_CERO_CM_MAX=.1,FCC_DISTANCIAS_EST_MEAS_CM=(2.,4.),FCC_DIF_MAX_PCT=30.,NOMBRE_RUIDO='Ruido',_accion_fallo_consola=lambda *a:'ABORTAR')
   instrucciones=[];ns['enter']=instrucciones.append
   estado,filas=ns['validar_estimado_medido_fcc'](
       [dict(posicion='A',regiones='FCC',distancia_cm=0,h_prom_A_m=1)],['FCC'],0,fixture.tmp.name,
       50,str(fixture.path),'RFID','','',contacto='periodo')
   self.assertEqual(len(filas),4);self.assertIn(estado,('OK','NO_CUMPLE'))
   wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
   self.assertEqual([wb['FCC Results'].cell(i,5).value for i in range(9,13)],
     ['A_2cm_Estimated','A_2cm_Measured','A_4cm_Estimated','A_4cm_Measured'])
   adquisiciones=[t for t in instrucciones if 'modo Peak' in t]
   self.assertEqual(len(adquisiciones),4)
   return None,None,None,None
  _,_,_,dur,refs,_=case.ejecutar_real(['FCC'],ejecutar=ejecutar)
  self.assertEqual(dur,[1800]*4);self.assertEqual(refs,['tip-max','probe-center','tip-max','probe-center'])
 def test_puntual_50khz_todos_los_rms_antes_de_fcc_peak_y_especiales(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   r.load({'medidas_con_contacto','_medidas_puntuales_regionales','promedio_completo',
       'filas_resumen_regionales','_fila_resumen','_medida_peor_posicion','_medir_posiciones_con_reintento',
       'comprobar_eh','guardar_validacion_region','guardar_json_atomico'},ns)
   ns.update(pedir_numero=lambda *a:2,_accion_fallo_consola=lambda *a:'ABORTAR',EH_LIMITE_OHM=37.7)
   estado,filas,picos,n=ns['medidas_con_contacto'](regiones,20,50,fixture.tmp.name,str(fixture.path),
      'RFID','','',lambda i,n:f'P{i}',2,False)
   self.assertEqual(estado,'OK');self.assertEqual(len(picos),3)
   self.assertEqual([f['posicion'] for f in filas if f['regiones']=='FCC'],['P1','P2'])
   self.assertTrue(all(f['modo_adquisicion']=='Peak' for f in filas if f['regiones']=='FCC'))
   return None,None,None,None
  _,_,_,dur,refs,_=case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
  self.assertEqual(dur,[360,360,1800,1800,120,120,360,120])
 def test_no_no_conserva_validacion_previa_y_puntual_la_omite(self):
  ns=test_fcc.cargar({})
  self.assertTrue(ns['fcc_aplica_validacion_cero'](['FCC'],0,'no'))
  self.assertFalse(ns['fcc_aplica_validacion_cero'](['FCC'],0,'puntual'))
  self.assertTrue(ns['fcc_aplica_validacion_cero'](['FCC'],0,'periodo'))
