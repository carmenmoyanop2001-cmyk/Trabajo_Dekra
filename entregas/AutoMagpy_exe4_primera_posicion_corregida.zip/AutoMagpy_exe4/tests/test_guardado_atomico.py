import unittest,ast,tempfile,io,os
from pathlib import Path
from unittest.mock import patch
import openpyxl
BASE=Path(__file__).resolve().parents[1]
tree=ast.parse((BASE/'automatizacion_magpy3_exe4.py').read_text())
ns={'io':io,'os':os,'_EXCEL_PASSWORD':None}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_guardar_excel_protegido'],type_ignores=[]),'core','exec'),ns)
class AtomicTests(unittest.TestCase):
 def test_saves_real_workbook(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'sample.xlsx';w=openpyxl.Workbook();w.active['A1']=.123
   ns['_guardar_excel_protegido'](w,str(p));w.close()
   r=openpyxl.load_workbook(p);self.assertEqual(r.active['A1'].value,.123);r.close()
 def test_locked_destination_preserves_original(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'sample.xlsx';w=openpyxl.Workbook();w.save(p);original=p.read_bytes();w.active['A1']=7
   with patch.object(os,'replace',side_effect=PermissionError('locked')):
    with self.assertRaises(PermissionError):ns['_guardar_excel_protegido'](w,str(p))
   self.assertEqual(p.read_bytes(),original);self.assertEqual(len(list(Path(tmp).iterdir())),1);w.close()
if __name__=='__main__':unittest.main()
