import math
import ast,itertools,queue,threading,unittest,traceback,os,tempfile,json
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

BASE=Path(__file__).resolve().parents[1]
GUI=ast.parse((BASE/'gui_magpy3_exe4.py').read_text())
CORE=ast.parse((BASE/'automatizacion_magpy3_exe4.py').read_text())

def load(tree,names,ns):
 if tree is CORE:
  names=set(names)|{"pedir_cantidad_contacto","pedir_nombre_posicion_unico"}
  ns.setdefault("math",math)
 exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'programa','exec'),ns)

def interfaz():
 ns=dict(queue=queue,itertools=itertools,eventos_q=queue.Queue(),respuesta_q=queue.Queue(),
         sesion_abortada=threading.Event(),_ids_solicitud=itertools.count(1),
         SesionAbortadaPorOperador=type('Abortada',(Exception,),{}))
 load(GUI,{'_pedir_respuesta','_solicitar_respuesta','_enviar_respuesta'},ns)
 return ns

class SolicitudesTests(unittest.TestCase):
 def test_respuesta_antigua_no_confirma_la_pregunta_siguiente(self):
  ns=interfaz();salida=[]
  def trabajador():
   salida.append(ns['_solicitar_respuesta']('NOMBRE',{}))
   salida.append(ns['_solicitar_respuesta']('CONTINUAR',{}))
  hilo=threading.Thread(target=trabajador,daemon=True);hilo.start()
  try:
   _,p=ns['eventos_q'].get(timeout=2);primero=p['_solicitud_id']
   ns['_enviar_respuesta'](primero,'Primera')
   _,p=ns['eventos_q'].get(timeout=2);segundo=p['_solicitud_id']
   ns['_enviar_respuesta'](primero,'Primera')  # doble confirmacion antigua
   ns['respuesta_q'].put(2)  # dato sin ID, de otro paso
   ns['_enviar_respuesta'](segundo,None)
   hilo.join(2)
   self.assertFalse(hilo.is_alive());self.assertEqual(salida,['Primera',None])
  finally:ns['sesion_abortada'].set();hilo.join(2)

 def test_abortar_interrumpe_cualquier_pregunta(self):
  ns=interfaz();excepciones=[]
  def trabajador():
   try:ns['_solicitar_respuesta']('NOMBRE',{})
   except ns['SesionAbortadaPorOperador']:excepciones.append('ABORTADA')
  hilo=threading.Thread(target=trabajador,daemon=True);hilo.start()
  ns['eventos_q'].get(timeout=2);ns['sesion_abortada'].set();hilo.join(2)
  self.assertFalse(hilo.is_alive());self.assertEqual(excepciones,['ABORTADA'])

class OrdenPrimeraPosicionTests(unittest.TestCase):
 def flujo(self,fallar=False):
  pasos=[];ns=dict(DIST_PICO_CONTACTO_CM=0.,pedir_numero=lambda *a:2,
       cuadro=lambda *a:None,msg=lambda *a:None)
  load(CORE,{'_medidas_puntuales_regionales','filas_resumen_regionales','_fila_resumen'},ns)
  def nombre(i,n):pasos.append(('nombre',i));return f'P{i}'
  def medir(nombre,*a,**kw):
   pasos.append(('medir',nombre))
   if fallar:return None,None,None,0
   prom=dict(h_prom=1,e_prom=2,freq_mhz=.125)
   return None,dict(prom,_por_region={'ISED':prom,'FCC':prom}),dict(prom,_por_region={'ISED':prom}),0
  def adicional(*a):pasos.append(('adicional',a[0]));return 'OK',a[-3],a[-2],a[-1]
  ns.update(procesar_posicion=medir,_medida_peor_posicion=adicional)
  estado,*_=ns['_medidas_puntuales_regionales'](['ISED','FCC'],20,125,'out',None,'','','',nombre,2,None)
  return estado,pasos
 def test_primera_posicion_medida_antes_de_pedir_segunda(self):
  estado,pasos=self.flujo()
  self.assertEqual(estado,'OK')
  self.assertEqual(pasos[:4],[('nombre',1),('medir','P1'),('nombre',2),('medir','P2')])
 def test_fallo_en_primera_no_pide_segunda(self):
  estado,pasos=self.flujo(fallar=True)
  self.assertEqual(estado,'ABORTADA');self.assertEqual(pasos,[('nombre',1),('medir','P1')])

class DiagnosticoTests(unittest.TestCase):
 def test_se_conserva_el_traceback_real_y_la_version(self):
  with tempfile.TemporaryDirectory() as tmp:
   ns=dict(os=os,datetime=datetime,__file__='gui_nueva.py',core=SimpleNamespace(__file__='core_nuevo.py'))
   load(GUI,{'registrar_error_sesion'},ns)
   try:list(3)
   except TypeError:detalle=traceback.format_exc()
   ruta=ns['registrar_error_sesion'](dict(carpeta_raiz=tmp,regiones=['ISED'],contacto='puntual',password='NO_GUARDAR'),detalle)
   texto=Path(ruta).read_text()
   self.assertIn('TypeError',texto);self.assertIn('line ',texto)
   self.assertIn('core_nuevo.py',texto);self.assertNotIn('NO_GUARDAR',texto)


class IntegracionContactoConColasTests(unittest.TestCase):
 def test_flows_completos_con_respuestas_reales_y_confirmaciones_antiguas(self):
  import inspect,textwrap,time
  import test_multirregion as regional
  for regiones in (['ISED'],['ISED','FCC'],['CE','ISED','FCC']):
   for periodo in (False,True):
    with self.subTest(regiones=regiones,periodo=periodo):
     self.correr(regional,regiones,periodo)

 def correr(self,regional,regiones,periodo):
  import inspect,textwrap,time
  estado={}
  def ejecutar_interfaz(ns,fixture,regiones):
   for n in CORE.body:
    if isinstance(n,ast.Assign) and any(getattr(x,'id','').startswith(('FCC_','EH_')) or getattr(x,'id','') in
      ('NOMBRE_RUIDO','DIST_COMPROBACION_CM','DIST_PICO_CONTACTO_CM','_HISTORIAL_FCC') for x in n.targets):
     exec(compile(ast.Module(body=[n],type_ignores=[]),'const','exec'),ns)
   load(CORE,{'medidas_con_contacto','_medidas_puntuales_regionales','_medir_posiciones_con_reintento',
        '_medida_peor_posicion','_fila_resumen','comprobar_eh','guardar_validacion_region',
        'guardar_json_atomico','validar_estimado_medido_fcc','fcc_aplica_validacion_cero',
        'peor_posicion_h','diferencia_estimada_medida_pct','calcular_peak_desde_rms',
        'medir_peak_posicion','modo_por_distancia','distancia_base_fcc'},ns)
   ctx=interfaz()
   load(GUI,{'gui_enter','gui_pedir_numero','gui_preguntar_opcion','hilo_sesion_medida','registrar_error_sesion'},ctx)
   ns.update(enter=ctx['gui_enter'],pedir_numero=ctx['gui_pedir_numero'],preguntar_opcion=ctx['gui_preguntar_opcion'],
             _accion_fallo_consola=lambda n:'ABORTAR')
   timeline=[]
   progreso=ns['barra_progreso']
   def barra(duracion,etiqueta):
    timeline.append(('medir',duracion,etiqueta));return progreso(duracion,etiqueta)
   ns['barra_progreso']=barra
   core=SimpleNamespace(**ns)
   core.verificar_conexion=lambda:True
   core.validar_configuracion_magpy=lambda r:True
   core.configurar_adquisicion=lambda f:None
   core.reiniciar_historial_fcc=lambda:None
   core.medir_ruido_ambiente=lambda *a:('OK',[])
   core.validar_caida_fcc=lambda *a,**k:('NA',[])
   core.guardar_csv_resumen=lambda *a:None
   ctx.update(core=core,datetime=datetime,os=os,traceback=traceback,__file__='gui_prueba.py')
   cfg=dict(regiones=regiones,carpeta_raiz=fixture.tmp.name,ruta_excel=str(fixture.path),n_posiciones=2,
    distancia_cm=0 if periodo else 20,frecuencia=125,technology='RFID',wpt_client='N/A',battery='N/A',
    archivo_csv='rms.csv',archivo_csv_peak='peak.csv',nombres_regiones=','.join(regiones),
    contacto='periodo' if periodo else 'puntual')
   hilo=threading.Thread(target=ctx['hilo_sesion_medida'],args=(cfg,),daemon=True)
   hilo.start();termino=False;id_anterior=None;limite=time.monotonic()+10
   try:
    while hilo.is_alive() or not ctx['eventos_q'].empty():
     self.assertLess(time.monotonic(),limite,'El flujo quedo bloqueado')
     try:tipo,p=ctx['eventos_q'].get(timeout=.2)
     except queue.Empty:continue
     if tipo=='ERROR_FATAL':self.fail(p)
     if tipo=='SESION_COMPLETADA':termino=True
     if tipo in ('PEDIR_NOMBRE_POSICION','PEDIR_NUMERO','PASO_MANUAL','PREGUNTA_OPCION'):
      ident=p['_solicitud_id']
      if id_anterior is not None:ctx['_enviar_respuesta'](id_anterior,None)
      if tipo=='PEDIR_NOMBRE_POSICION':
       timeline.append(('nombre',p['num']));valor=f"P{p['num']}"
      elif tipo=='PEDIR_NUMERO':valor=2
      elif tipo=='PREGUNTA_OPCION':valor=p['opciones'][0]
      else:valor=None
      ctx['_enviar_respuesta'](ident,valor);id_anterior=ident
    hilo.join(2);self.assertTrue(termino)
    indice2=timeline.index(('nombre',2));indice1=timeline.index(('nombre',1))
    anteriores=[e for e in timeline[indice1+1:indice2] if e[0]=='medir']
    self.assertTrue(anteriores,'Se pidio la segunda posicion sin medir la primera')
    if len(regiones)>1:
     esperado=[360,120,1800] if len(regiones)==2 else [360,120,360,1800]
     self.assertEqual([e[1] for e in anteriores],esperado)
    else:self.assertEqual(anteriores[0][1],360)
    estado['timeline']=timeline
   finally:ctx['sesion_abortada'].set();hilo.join(2)
   return None,None,None,None
  source=textwrap.dedent(inspect.getsource(regional.MultirregionTests.ejecutar_real))
  old="resultado=ns['procesar_posicion']('Left',fixture.tmp.name,regiones,0,125,str(fixture.path),'RFID','N/A','N/A',peak_fisico=True)"
  self.assertIn(old,source)
  source=source.replace(old,'resultado=ejecutar_interfaz(ns,fixture,regiones)')
  source=source.replace("campos=iter([1.,2.,5.] if len(regiones)==2 else [1.,2.,4.,5.])",'campos=itertools.cycle([1.,2.,5.,3.,4.,6.])')
  contexto=dict(vars(regional),itertools=itertools,ejecutar_interfaz=ejecutar_interfaz)
  exec(source,contexto)
  case=regional.MultirregionTests()
  try:contexto['ejecutar_real'](case,regiones)
  finally:case.doCleanups()


class ControlesContactoTests(unittest.TestCase):
 def test_cantidad_fraccionaria_no_se_trunca(self):
  valores=iter([1.5,2]);avisos=[]
  ns=dict(math=math,pedir_numero=lambda *a:next(valores),msg=lambda *a:avisos.append(a))
  load(CORE,{'pedir_cantidad_contacto'},ns)
  self.assertEqual(ns['pedir_cantidad_contacto'](3),2)
  self.assertEqual(len(avisos),1)
 def test_nombre_repetido_se_corrige_antes_de_medir(self):
  nombres=iter(['Primera','primera','Segunda']);avisos=[]
  ns=dict(msg=lambda *a:avisos.append(a))
  load(CORE,{'pedir_nombre_posicion_unico'},ns)
  usados=set()
  self.assertEqual(ns['pedir_nombre_posicion_unico'](lambda *a:next(nombres),1,2,usados),'Primera')
  self.assertEqual(ns['pedir_nombre_posicion_unico'](lambda *a:next(nombres),2,2,usados),'Segunda')
  self.assertEqual(len(avisos),1)
 def test_gui_no_envia_nombre_duplicado(self):
  ns=interfaz();avisos=[]
  ns['_cerrar_teclado_tactil_windows']=lambda:None
  cls=next(n for n in GUI.body if isinstance(n,ast.ClassDef) and n.name=='AppMagpy3')
  method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_on_confirmar_nombre_posicion')
  exec(compile(ast.Module(body=[method],type_ignores=[]),'GUI','exec'),ns)
  app=SimpleNamespace(esperando_nombre_posicion=True,_nombres_confirmados={'primera'},
    var_nombre_pos=SimpleNamespace(get=lambda:'Primera'),_log=lambda *a:avisos.append(a))
  ns['_on_confirmar_nombre_posicion'](app)
  self.assertTrue(ns['respuesta_q'].empty());self.assertTrue(app.esperando_nombre_posicion)
  self.assertEqual(len(avisos),1)

if __name__=='__main__':unittest.main()
