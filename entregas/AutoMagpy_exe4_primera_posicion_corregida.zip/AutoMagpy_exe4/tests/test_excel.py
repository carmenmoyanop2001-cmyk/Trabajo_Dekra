import ast,unittest,tempfile,math,os,json
from pathlib import Path
from datetime import datetime
import openpyxl
BASE=Path(__file__).resolve().parents[1]
def functions(names, ns):
 tree=ast.parse((BASE/'automatizacion_magpy3_exe4.py').read_text())
 nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'core','exec'),ns)
 return ns
class ExcelTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.path=Path(self.tmp.name)/'test.xlsx'
  wb=openpyxl.Workbook();wb.active.title='ISED Results';wb.save(self.path);wb.close()
  self.logs=[]
  self.ns=functions({'guardar_json_atomico','promedio_completo','actualizar_excel','_actualizar_excel_un_intento','encontrar_primera_fila_libre','escribir_fila_excel'},dict(math=math,os=os,json=json,datetime=datetime,_EXCEL_PASSWORD=None,
   CONFIG_REGION={'ISED':{'sheet':'ISED Results'}},
   EXCEL_COL_MAP={'ISED':[
    dict(valor='RMS',technology=2,wpt=3,battery=4,testside=5,distance=6,freq_e=7,efield=8,date_e=12,freq_h=16,hfield=17,date_h=21,first_data_row=9),
    dict(valor='Peak',technology=27,wpt=28,battery=29,testside=30,distance=31,freq_e=32,efield=33,date_e=37,freq_h=41,hfield=42,date_h=46,first_data_row=9)]},
   _abrir_excel_protegido=lambda p,k:openpyxl.load_workbook(p),
   _guardar_excel_protegido=lambda w,p:w.save(p),msg=lambda *a:self.logs.append(a),
   preguntar_opcion=lambda *a:'PENDIENTE'))
 def args(self,types=('RMS','Peak'),name='Right Edge'):
  return dict(ruta_excel=str(self.path),region='ISED',nombre_posicion=name,
   distancias_cm={k:0 for k in types},promedios_por_tipo={k:dict(h_prom=.13579,e_prom=.24681,freq_mhz=.125) for k in types},technology='RFID',wpt_client='N/A',battery='N/A',
   fechas_fin={k:datetime(2026,11,9) for k in types},frecuencia_khz=125)
 def test_both_modes_fields_saved_and_verified(self):
  self.assertTrue(self.ns['actualizar_excel'](**self.args()))
  w=openpyxl.load_workbook(self.path)
  for c in [8,33]:self.assertEqual(w.active.cell(9,c).value,.2468)
  for c in [17,42]:self.assertEqual(w.active.cell(9,c).value,.1358)
  w.close()
 def test_invalid_peak_blocks_blank_row(self):
  a=self.args();a['promedios_por_tipo']['Peak']['h_prom']=None
  self.assertFalse(self.ns['actualizar_excel'](**a))
  w=openpyxl.load_workbook(self.path);self.assertIsNone(w.active.cell(9,30).value);w.close()
  backup=list(self.path.parent.glob('AutoMagpy_resultados/*.json'))
  self.assertEqual(json.loads(backup[0].read_text())['estado'],'PENDIENTE')
 def test_zero_valid_nan_invalid(self):
  f=self.ns['promedio_completo'];self.assertTrue(f(dict(h_prom=0,e_prom=0)))
  for v in [None,float('nan'),float('inf')]:self.assertFalse(f(dict(h_prom=v,e_prom=1)))
 def test_corrupt_field_detected(self):
  def save(w,p):
   w.active.cell(9,42).value=None;w.save(p)
  self.ns['_guardar_excel_protegido']=save
  self.assertFalse(self.ns['actualizar_excel'](**self.args()))
 def test_locked_excel_retries_without_new_row_or_measurement(self):
  count=[]
  def save(w,p):
   count.append(1)
   if len(count)==1:raise PermissionError('Excel abierto')
   w.save(p)
  self.ns['_guardar_excel_protegido']=save
  self.ns['preguntar_opcion']=lambda *a:'REINTENTAR'
  self.assertTrue(self.ns['actualizar_excel'](**self.args()))
  self.assertEqual(len(count),2)
  w=openpyxl.load_workbook(self.path);self.assertIsNone(w.active.cell(10,30).value);w.close()
 def test_verification_retry_same_row(self):
  count=[]
  def save(w,p):
   count.append(1)
   if len(count)==1:w.active.cell(9,42).value=None
   w.save(p)
  self.ns['_guardar_excel_protegido']=save
  self.ns['preguntar_opcion']=lambda *a:'REINTENTAR'
  self.assertTrue(self.ns['actualizar_excel'](**self.args()))
  w=openpyxl.load_workbook(self.path);self.assertEqual(w.active.cell(9,42).value,.1358);self.assertIsNone(w.active.cell(10,30).value);w.close()
 def test_separate_peak_aligned_with_rms(self):
  self.assertTrue(self.ns['actualizar_excel'](**self.args(('RMS',))))
  self.assertTrue(self.ns['actualizar_excel'](**self.args(('Peak',))))
  w=openpyxl.load_workbook(self.path);self.assertEqual(w.active.cell(9,5).value,w.active.cell(9,30).value);w.close()
 def test_separate_peak_compact_no_gaps(self):
  for n in ('A','B','C'):self.assertTrue(self.ns['actualizar_excel'](**self.args(('RMS',),name=n)))
  for n in ('A','C'):self.assertTrue(self.ns['actualizar_excel'](**self.args(('Peak',),name=n)))
  w=openpyxl.load_workbook(self.path);ws=w.active
  self.assertEqual((ws.cell(9,30).value,ws.cell(10,30).value,ws.cell(11,30).value),('A','C',None));w.close()
 def test_multi_peak_rejected_not_rms(self):
  p=dict(h_prom=1,e_prom=2,multi_frecuencia=True)
  self.assertTrue(self.ns['promedio_completo'](p));self.assertFalse(self.ns['promedio_completo'](p,es_peak=True))
if __name__=='__main__':unittest.main()
