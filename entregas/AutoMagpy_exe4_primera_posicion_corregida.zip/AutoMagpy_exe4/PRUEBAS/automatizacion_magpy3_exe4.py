import time, sys, os, io, json, zipfile, csv, threading, math, getpass
import requests, pyautogui, ctypes, pandas as pd, openpyxl
import msoffcrypto
from datetime import datetime, date
from openpyxl import load_workbook


# ═══════════════════════════════════════════════════════════════
# CONFIGURACIÓN GLOBAL
# ═══════════════════════════════════════════════════════════════

MAGPY_HOST            = "http://localhost:6000"
ACQUISITION_PERIOD_MS = 700
# Sin sleep en el bucle de measurement — la latencia HTTP (~100-200ms) ya actúa
# como cadencia natural. Así nunca perdemos frames intermedios.
POLL_INTERVAL_S       = 0.0

DURACION_6MIN  =  6 * 60
DURACION_30MIN = 30 * 60
DURACION_2MIN  =  2 * 60
# Duraciones NOMINALES: son las que se muestran siempre (etiquetas, avisos, resumen).
NOM_6MIN, NOM_30MIN, NOM_2MIN = DURACION_6MIN, DURACION_30MIN, DURACION_2MIN

# ── MODO DEPURACIÓN RÁPIDA ────────────────────────────────────────────────
# Activar con la variable de entorno MAGPY_DEBUG_FAST=1 antes de ejecutar
# el script (por ejemplo: set MAGPY_DEBUG_FAST=1  &&  py automatizacion_magpy3_V13.py)
# Comprime las duraciones de medida para poder probar el flujo completo
# (RMS + Peak + Excel) en segundos en vez de minutos. NO USAR EN CAMPO:
# los valores resultantes no son validos para compliance con este modo activo.
# Alternativa sin variable de entorno: poner FORZAR_DEBUG_FAST = True para probar
# (y volver a False para medir de verdad).
FORZAR_DEBUG_FAST = True
DEBUG_FAST = FORZAR_DEBUG_FAST or os.environ.get("MAGPY_DEBUG_FAST") == "1"
if DEBUG_FAST:
    # Solo cambia lo que se ESPERA de verdad; en pantalla se sigue viendo 6 min / 2 min.
    DURACION_6MIN  = 60   # "6 min" -> en realidad 1 min
    DURACION_30MIN = 30   # "30 min" (FCC) -> en realidad 30 s
    DURACION_2MIN  = 20   # "2 min" -> en realidad 20 s

LOCATIONS       = ["ProbeCenter", "SensorMax", "TipCenter", "TipMax"]
QUANTITY_FILTRO = "IncidentMagneticField"

# ── CAPTURA DE PANTALLA DE MAGPY (solo la ventana de MAGPy, nunca toda la tablet) ──
# Fragmentos del título de la ventana de MAGPy (sin distinguir mayúsculas).
# La propia GUI/consola de automatización se excluye sola (mismo proceso / clase de consola).
MAGPY_WINDOW_TITLE_HINTS = ("magpy",)
# Endpoints de la API local que MAGPy podría exponer para su "capture screenshot".
# Se prueban una sola vez por sesión; si ninguno devuelve un PNG, se captura la ventana.
# Déjalo en () para desactivar el intento por API.
MAGPY_SCREENSHOT_ENDPOINTS = ("screenshot", "capture/screenshot", "capture_screenshot")
CAPTURA_ESPERA_FOCO_S = 0.7     # espera tras traer MAGPy al frente, antes de capturar
CAPTURA_REINTENTOS    = 3

# Consola reducida: solo mensajes realmente necesarios para el operador.
# Cambia a "NORMAL" si algún día quieres volver a ver todos los mensajes técnicos.
LOG_MODE = "ESSENTIAL"

# Reintentos de arranque de adquisición. La posición actual no se salta
# automáticamente si falla el inicio de medida.
MAX_REINTENTOS_INICIO_MEDIDA = 8
ESPERA_REINTENTO_INICIO_S    = 2


# Formato de exportación MAGPy V3.4 para Measurements.csv.
# No se pulsa el botón SAVE DATA. Se transforma la lectura de la API al
# formato largo documentado por MAGPy 3.4.
API_LOCATIONS_EXPORT = ["probe-center", "sensor-max", "tip-center", "tip-max"]
LOCATION_API_TO_EXPORT = {
    "probe-center": "ProbeCenter",
    "sensor-max":   "SensorMax",
    "tip-center":   "TipCenter",
    "tip-max":      "TipMax",
}
MEASUREMENTS_TIDY_COLUMNS = [
    "timestamp", "frame_source", "quantity", "location", "sensor_index",
    "frequency", "x", "y", "z", "total"
]

MS_6MIN         =  6 * 60 * 1000
MS_30MIN        = 30 * 60 * 1000
MS_2MIN         =  2 * 60 * 1000

if DEBUG_FAST:
    # La ventana de promediado debe caber dentro de la duración real medida,
    # si no, promediar_medidas() nunca tendría suficientes frames.
    MS_6MIN  = DURACION_6MIN  * 1000
    MS_30MIN = DURACION_30MIN * 1000
    MS_2MIN  = DURACION_2MIN  * 1000

CONFIG_REGION = {
    "CE": {
        "nombre":              "CE (Europa - ICNIRP 2010/2020)",
        "standard":            "ICNIRP 2010/2020",
        "environment":         "General public",
        "health_effect":       "Combined",
        "peak_rms_inicial":    "RMS",
        "sheet":               "EN Results",
        "fases": [
            {"etiqueta": "6 min RMS", "duracion_s": DURACION_6MIN,
             "nominal_s": NOM_6MIN, "peak_rms": "RMS", "ms_ventana": MS_6MIN},
        ],
    },
    "FCC": {
        "nombre":              "FCC (Estados Unidos)",
        "standard":            "FCC",
        "environment":         "General public",
        "health_effect":       "Combined",
        "peak_rms_inicial":    "RMS",
        "sheet":               "FCC Results",
        "fases": [
            {"etiqueta": "30 min RMS", "duracion_s": DURACION_30MIN,
             "nominal_s": NOM_30MIN, "peak_rms": "RMS", "ms_ventana": MS_30MIN},
        ],
    },
    "ISED": {
        "nombre":              "ISED / HC Code 6 (Canada)",
        "standard":            "HC Code 6",
        "environment":         "General public",
        "health_effect":       "Combined",
        "peak_rms_inicial":    "RMS",
        "sheet":               "ISED Results",
        "fases": [
            {"etiqueta": "6 min RMS",  "duracion_s": DURACION_6MIN,
             "nominal_s": NOM_6MIN, "peak_rms": "RMS",  "ms_ventana": MS_6MIN},
            {"etiqueta": "2 min Pico", "duracion_s": DURACION_2MIN,
             "nominal_s": NOM_2MIN, "peak_rms": "Peak", "ms_ventana": MS_2MIN},
        ],
    },
}

# Cada bloque = una tabla de la hoja. La clave "valor" indica QUE promedio se
# escribe en esa tabla:
#     "RMS"  -> promedio RMS de la ventana de compliance
#     "Peak" -> valor de pico (medido o calculado como RMS x sqrt(2))
#     None   -> tabla que se deja en blanco (la rellena el operador a mano)
EXCEL_COL_MAP = {
    "CE": [
        {   "valor": "RMS",
            "technology": 2,  "wpt": 3,      "battery": 4,
            "testside": 5,    "distance": 6,
            "freq_e": 7,      "efield": 8,   "date_e": 12,
            "freq_h": 16,     "hfield": 17,  "date_h": 21,
            "first_data_row": 9,
        }
    ],
    "FCC": [
        {   "valor": "RMS",
            "technology": 2,  "wpt": 3,      "battery": 4,
            "testside": 5,    "distance": 6,
            "freq_e": 7,      "efield": 8,   "date_e": 12,
            "freq_h": 16,     "hfield": 17,  "date_h": 21,
            "first_data_row": 9,
        },
        {   "valor": "RMS",
            "technology": 26, "wpt": 27,     "battery": 28,
            "testside": 29,   "distance": 30,
            "freq_e": 31,     "efield": 32,  "date_e": 36,
            "freq_h": 40,     "hfield": 41,  "date_h": 45,
            "first_data_row": 9,
        },
    ],
    "ISED": [
        # Tabla 1: RMS (6 min)
        {   "valor": "RMS",
            "technology": 2,  "wpt": 3,      "battery": 4,
            "testside": 5,    "distance": 6,
            "freq_e": 7,      "efield": 8,   "date_e": 12,
            "freq_h": 16,     "hfield": 17,  "date_h": 21,
            "first_data_row": 9,
        },
        # Tabla 2: Pico (2 min)
        {   "valor": "Peak",
            "technology": 27, "wpt": 28,     "battery": 29,
            "testside": 30,   "distance": 31,
            "freq_e": 32,     "efield": 33,  "date_e": 37,
            "freq_h": 41,     "hfield": 42,  "date_h": 46,
            "first_data_row": 9,
        },
        # Tabla 3: se deja en blanco
        {   "valor": None,
            "technology": 52, "wpt": 53,     "battery": 54,
            "testside": 55,   "distance": 56,
            "freq_e": 57,     "efield": 58,  "date_e": 62,
            "freq_h": 66,     "hfield": 67,  "date_h": 71,
            "first_data_row": 9,
        },
    ],
}


# ═══════════════════════════════════════════════════════════════
# UTILIDADES DE CONSOLA
# ═══════════════════════════════════════════════════════════════

# Pitidos desactivados. Poner True para volver a activarlos.
PITIDOS_ACTIVOS = False

def beep(n=1):
    if not PITIDOS_ACTIVOS:
        return
    for _ in range(n):
        ctypes.windll.kernel32.Beep(1000, 500)
        time.sleep(0.2)

def _mensaje_esencial(texto, tipo):
    """Filtro central para reducir ruido en consola sin tocar la lógica de medida."""
    if LOG_MODE.upper() != "ESSENTIAL":
        return True

    texto_l = str(texto).lower()

    # Estos mensajes son útiles para depuración, pero demasiado ruidosos para operación normal.
    ocultar = (
        "endpoint histórico encontrado",
        "no hay endpoint histórico",
        "config raw recibida",
        "campo '",
        "configuración obtenida desde endpoint",
        "configuracion obtenida desde endpoint",
        "empaquetando",
        "captura guardada",
        "promediar_medidas:",
        "excel '",
        "api:",
    )
    if any(p in texto_l for p in ocultar):
        return False

    # Errores y avisos reales se mantienen, salvo los ocultados arriba.
    if tipo in ("ERROR", "AVISO"):
        return True

    # Mensajes OK/INFO/ESPERA que sí necesita ver el operador.
    esenciales = (
        "verificando conexion",
        "conectado",
        "sin conexion",
        "validando configuracion",
        "configuracion validada",
        "configuración validada",
        "medida iniciada",
        "medida detenida",
        "magpy ya estaba midiendo",
        "reintent",
        "no se pudo",
        "captura de magpy",
        "fcc 1/d",
        "zip guardado",
        "excel guardado",
        "csv de resumen",
        "promedios calculados",
        "excel actualizado",
        "posicion '",
        "posición '",
        "sesion completada",
        "sesión completada",
    )
    return any(p in texto_l for p in esenciales)

def msg(texto, tipo="INFO"):
    if not _mensaje_esencial(texto, tipo):
        return
    ts = datetime.now().strftime("%H:%M:%S")
    iconos = {"INFO": "i", "OK": "OK", "AVISO": "!", "ERROR": "X", "ESPERA": "..."}
    print(f"[{ts}] [{iconos.get(tipo,'?')}]  {texto}")

def sep(titulo=""):
    linea = "-" * 62
    print(f"\n{linea}\n  {titulo}\n{linea}" if titulo else linea)

def cuadro(titulo, lineas):
    ancho = max(len(l) for l in [titulo] + lineas) + 4
    print()
    print("+" + "=" * ancho + "+")
    print("|" + f"  {titulo}".ljust(ancho) + "|")
    print("+" + "=" * ancho + "+")
    for l in lineas:
        print("|" + f"  {l}".ljust(ancho) + "|")
    print("+" + "=" * ancho + "+")
    print()

def _vaciar_teclado():
    """Descarta pulsaciones pendientes (p. ej. un ENTER dado mientras se medía) para que el
    siguiente 'Continuar' no se salte solo. Solo consola de Windows; si falla, no hace nada."""
    try:
        import msvcrt
        while msvcrt.kbhit():
            msvcrt.getwch()
    except Exception:
        pass

def enter(texto="Presiona Continuar para seguir..."):
    _vaciar_teclado()
    input(f"\n  --> {texto}")



class ReiniciarConfiguracion(Exception):
    """Señal interna para volver a pedir todos los parámetros de la sesión."""
    pass


class VolverAtrasConfiguracion(Exception):
    """Señal interna para volver un paso atrás en la configuración."""
    pass


class CancelarSesion(Exception):
    """Señal interna para cancelar la sesión antes de empezar a medir."""
    pass


def input_config(prompt, permitir_vacio=False):
    """Entrada de parámetros con comandos de control comunes.

    Comandos disponibles durante la configuración inicial:
      B -> volver al parámetro anterior
      R -> reiniciar la selección completa de parámetros
      Q -> cancelar/salir del programa
    """
    while True:
        valor = input(prompt).strip().strip('"')
        comando = valor.upper()
        if comando == "B":
            raise VolverAtrasConfiguracion
        if comando == "R":
            raise ReiniciarConfiguracion
        if comando == "Q":
            raise CancelarSesion
        if valor or permitir_vacio:
            return valor
        print("  X Introduce un valor valido.")


def _fmt_actual(valor):
    if valor is None:
        return "No configurado"
    if isinstance(valor, list):
        return " ".join(str(v) for v in valor)
    return str(valor)


def _prompt_actual(prompt, actual):
    if actual is None:
        return prompt
    prompt_base = prompt[:-2] if prompt.endswith(": ") else prompt
    return f"{prompt_base} [actual: {_fmt_actual(actual)}]: "


def mostrar_ayuda_parametros():
    print("\n  Comandos durante la configuracion:")
    print("    B  --> volver al parametro anterior")
    print("    R  --> reiniciar la seleccion de parametros desde cero")
    print("    Q  --> cancelar y salir")
    print("    ENTER sobre un campo con [actual: ...] conserva ese valor")

def barra_progreso(segundos_total, etiqueta="Midiendo"):
    """
    Barra de progreso con actualización visual cada 1%.
    Mantiene la duración real de la fase y evita acumulación de deriva usando time.monotonic().
    """
    segundos_total = max(1, int(segundos_total))
    inicio = time.monotonic()

    for pct in range(0, 101):
        transcurrido = min(time.monotonic() - inicio, segundos_total)
        restante = max(0, int(round(segundos_total - transcurrido)))
        mr, sr = divmod(restante, 60)

        barra = "#" * int(pct / 2) + "-" * (50 - int(pct / 2))
        print(f"\r  {etiqueta}: [{barra}] {pct:3d}%  Restante: {mr:02d}:{sr:02d}   ",
              end="", flush=True)

        if pct < 100:
            siguiente = inicio + segundos_total * ((pct + 1) / 100.0)
            espera = max(0.0, siguiente - time.monotonic())
            time.sleep(espera)

    print()


# ═══════════════════════════════════════════════════════════════
# API MAGPY3
# ═══════════════════════════════════════════════════════════════

# Sesión persistente con keep-alive: reutiliza la conexión TCP
# y reduce la latencia por request de ~400ms a ~50ms en localhost.
_session = requests.Session()
_session.headers.update({"Connection": "keep-alive"})

# Contraseña del Excel protegido: se pide una vez por consola (input oculto)
# y se cachea SOLO en memoria para el resto de la sesión. Nunca se escribe a disco.
_EXCEL_PASSWORD = None

def api_get(endpoint):
    try:
        r = _session.get(f"{MAGPY_HOST}/{endpoint}", timeout=5)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None

def api_post(endpoint, datos):
    try:
        r = _session.post(f"{MAGPY_HOST}/{endpoint}", json=datos, timeout=5)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None

def verificar_conexion():
    msg("Verificando conexion con MAGpy3...", "ESPERA")
    info = api_get("version")
    if info:
        msg(f"Conectado -- MAGpy3 version {info.get('application','?')}", "OK")
        return True
    msg("Sin conexion con MAGpy3", "ERROR")
    return False

def iniciar_medida(silencioso=False):
    r = api_get("acquisition/start")
    if r and r.get("active"):
        if not silencioso:
            msg("Medida iniciada", "OK")
        return True
    if not silencioso:
        msg("No se pudo iniciar la medida", "ERROR")
    return False

def adquisicion_activa():
    """Comprueba si MAGPy informa que la adquisición está activa."""
    status = api_get("acquisition/status")
    return bool(status and status.get("active"))

def reset_adquisicion_para_reintento():
    """Reset suave entre intentos: stop + clear GUI, sin mensajes extra."""
    try:
        api_get("acquisition/stop")
    except Exception:
        pass
    time.sleep(0.8)
    try:
        click_clear_gui()
    except Exception:
        pass
    time.sleep(0.8)

def iniciar_medida_con_reintentos(contexto="medida", max_reintentos=MAX_REINTENTOS_INICIO_MEDIDA, colector=None):
    """
    Intenta iniciar la adquisición sin saltar la posición actual.
    Si falla el bloque de intentos automáticos, pide intervención y vuelve a intentar
    la MISMA posición/fase. Solo devuelve False si el operador decide abortar.
    """
    enter(f"Antes de iniciar {contexto}: CIERRA la pestaña o ventana del teclado "
          "táctil para que no aparezca en la captura. Comprueba la posición y el "
          "modo de MAGPy. Pulsa Continuar cuando esté cerrado.")
    ciclo = 1
    while True:
        for intento in range(1, max_reintentos + 1):
            if iniciar_medida(silencioso=True):
                msg(f"Medida iniciada ({contexto})", "OK")
                if colector is not None:
                    colector.iniciar()
                return True

            time.sleep(ESPERA_REINTENTO_INICIO_S)

            if adquisicion_activa():
                msg(f"MAGPy ya estaba midiendo ({contexto}). Continuando.", "OK")
                if colector is not None:
                    colector.iniciar()
                return True

            # Cada 3 intentos hacemos un reset suave antes de volver a arrancar.
            if intento in (3, 6):
                msg(f"Reintentando {contexto}: reset suave de adquisicion ({intento}/{max_reintentos})", "AVISO")
                reset_adquisicion_para_reintento()
            elif intento in (1, max_reintentos):
                msg(f"Reintentando {contexto}: intento {intento}/{max_reintentos}", "AVISO")

        beep(2)
        cuadro(
            "NO SE HA PODIDO INICIAR LA MEDIDA",
            [f"Fase/posicion actual: {contexto}",
             "La posicion actual NO se va a saltar automaticamente.",
             "Revisa MAGPy, la sonda, el DUT y la conexion API.",
             "",
             "ENTER  --> reintentar la misma fase/posicion",
             "A      --> abortar la sesion"]
        )
        accion = input("  Opcion: ").strip().upper()
        if accion == "A":
            msg(f"Sesion abortada por el operador durante {contexto}.", "ERROR")
            return False
        ciclo += 1
        msg(f"Reintentando {contexto} de nuevo (bloque {ciclo}).", "AVISO")

def obtener_config_actual():
    """
    Consulta la configuración actual del software MAGPy.
    Prueba varios endpoints posibles porque la API puede variarlos entre versiones.
    """
    for endpoint in ("settings", "configuration", "config", "compliance/settings"):
        datos = api_get(endpoint)
        if datos:
            msg(f"Configuración obtenida desde endpoint '/{endpoint}'", "OK")
            return datos
    msg("Ningún endpoint de configuración respondió (settings/configuration/config/compliance/settings)", "AVISO")
    return None

def validar_configuracion_magpy(region_seleccionada):
    """
    Lee la config actual de MAGPy y la compara con la requerida.
    Muestra los campos raw que devuelve la API para facilitar el diagnóstico.
    """
    msg("Validando configuracion normativa en MAGpy3...", "ESPERA")
    config_actual = obtener_config_actual()

    if not config_actual:
        msg("No se pudo obtener la configuracion actual de MAGpy3 -- "
            "comprueba que la versión de MAGpy3 expone /settings o /configuration.", "AVISO")
        return True  # No bloqueamos la medida, pero avisamos

    # Log de los campos raw para diagnóstico futuro
    campos_raw = ", ".join(f"{k}={v}" for k, v in list(config_actual.items())[:8])
    msg(f"Config raw recibida: {campos_raw}", "INFO")

    cfg_esperada = CONFIG_REGION[region_seleccionada]

    # Mapeo ampliado: clave en nuestro dict -> posibles nombres en la API
    check_list = [
        ("standard",      ["standard", "norm", "normative_standard", "compliance_standard"]),
        ("environment",   ["environment", "env", "exposure_environment"]),
        ("health_effect", ["health_effect", "healthEffect", "health_effects", "effect"]),
    ]

    errores = []
    for dict_key, api_candidates in check_list:
        val_esperado = cfg_esperada.get(dict_key)
        val_actual   = None
        for candidate in api_candidates:
            if candidate in config_actual:
                val_actual = config_actual[candidate]
                break

        if val_actual is None:
            # Campo no encontrado en la respuesta: lo anotamos pero no bloqueamos
            msg(f"Campo '{dict_key}' no encontrado en la respuesta de la API "
                f"(buscado como: {api_candidates})", "AVISO")
            continue

        if str(val_actual).lower() != str(val_esperado).lower():
            errores.append(
                f"  * {dict_key.replace('_', ' ').title()}: "
                f"Actual='{val_actual}' | ESPERADO='{val_esperado}'"
            )

    if errores:
        cuadro("CONFIGURACION INCORRECTA",
               ["La configuracion en MAGpy3 NO coincide con el estandar requerido:", ""] + errores)
        return False

    msg("Configuracion validada correctamente.", "OK")
    return True

def parar_medida(reintentos=3, espera_s=2):
    """Detiene la adquisición con reintentos. Tolera que ya esté parada."""
    for intento in range(reintentos):
        r = api_get("acquisition/stop")
        # Éxito si la API confirma que ya no está activa
        if r is not None and not r.get("active", True):
            msg("Medida detenida", "OK")
            return True
        # Si r es None o active sigue en True, comprobar estado actual
        status = api_get("acquisition/status")
        if status and not status.get("active", True):
            msg("Medida ya estaba detenida (confirmado por status)", "OK")
            return True
        msg(f"Intento {intento+1}/{reintentos}: No se pudo detener la medida, reintentando...", "AVISO")
        time.sleep(espera_s)
    msg("No se pudo detener la medida tras varios intentos", "ERROR")
    return False

def configurar_adquisicion(frecuencia_khz):
    bw = round(frecuencia_khz * 0.20, 1)
    r  = api_post("acquisition/configure", {
        "period_ms": ACQUISITION_PERIOD_MS,
        "peak_search_kHz": {"frequency": frecuencia_khz, "bandwidth": bw},
    })
    if r:
        msg(f"API: {frecuencia_khz} kHz, BW={bw} kHz, periodo={ACQUISITION_PERIOD_MS} ms", "OK")
        return True
    return False



# ═══════════════════════════════════════════════════════════════
# TRANSFORMACIÓN API -> FORMATO MEASUREMENTS MAGPy 3.4
# ═══════════════════════════════════════════════════════════════

def normalizar_frame_source(source):
    """Convierte el campo opcional source de la API al nombre usado en el CSV MAGPy 3.4."""
    if source is None:
        return "Unknown"
    s = str(source).strip()
    compact = s.lower().replace("_", "").replace("-", "").replace(" ", "")
    if compact in ("periodic", "live"):
        return "Live"
    if compact in ("epeak", "electricfieldpeak"):
        return "ElectricFieldPeak"
    if compact in ("hpeak", "magneticfieldpeak"):
        return "MagneticFieldPeak"
    if s in ("ElectricFieldPeak", "MagneticFieldPeak", "Live", "Unknown"):
        return s
    return "Unknown"

def _to_float_or_none(v):
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None

def _vector_total(x, y, z):
    vals = [_to_float_or_none(x), _to_float_or_none(y), _to_float_or_none(z)]
    if any(v is None for v in vals):
        return None
    return math.sqrt(vals[0] ** 2 + vals[1] ** 2 + vals[2] ** 2)

def _campo_xyz_total(campo, total_keys=("rms_total", "total")):
    """Extrae x/y/z/total de un campo de la API aceptando variantes de nombre."""
    if not isinstance(campo, dict):
        return None
    x = campo.get("rms_x", campo.get("x"))
    y = campo.get("rms_y", campo.get("y"))
    z = campo.get("rms_z", campo.get("z"))
    total = None
    for k in total_keys:
        if k in campo:
            total = campo.get(k)
            break
    if total is None:
        total = _vector_total(x, y, z)
    return x, y, z, total

def _extraer_sensor_index(datos, api_location):
    """
    MAGPy 3.4 exporta sensor_index. El endpoint /data/current/measurement documentado
    no garantiza este campo, pero algunas versiones pueden incluirlo con nombres internos.
    Si no está disponible, se deja 0 para no inventar un sensor.
    """
    if api_location in ("probe-center", "tip-center"):
        return 0

    candidatos_directos = [
        "sensor_index", "sensorIndex", "sensor_idx", "sensor",
        "sensor_num", "sensorNum", "sensor_number", "sensorNumber",
        "sensor_num_surface", "sensorNumSurface",
    ]
    for k in candidatos_directos:
        v = datos.get(k) if isinstance(datos, dict) else None
        try:
            if v is not None and int(v) >= 0:
                return int(v)
        except (TypeError, ValueError):
            pass

    for contenedor in ("h_field", "measurement", "meta", "metadata", "location"):
        sub = datos.get(contenedor) if isinstance(datos, dict) else None
        if isinstance(sub, dict):
            for k in candidatos_directos:
                v = sub.get(k)
                try:
                    if v is not None and int(v) >= 0:
                        return int(v)
                except (TypeError, ValueError):
                    pass

    return 0

def _fila_tidy(timestamp_abs, ts_ref, frame_source, quantity, location, sensor_index,
               frequency, x, y, z, total):
    ts = timestamp_abs
    if ts is not None and ts_ref is not None:
        try:
            ts = int(round(float(ts) - float(ts_ref)))
        except (TypeError, ValueError):
            pass
    return {
        "timestamp": ts,
        "frame_source": frame_source,
        "quantity": quantity,
        "location": location,
        "sensor_index": sensor_index,
        "frequency": frequency,
        "x": x,
        "y": y,
        "z": z,
        "total": total,
    }

def construir_filas_measurement_tidy(datos_por_location, ts_ref):
    """
    Construye filas tipo MAGPy 3.4:
    timestamp, frame_source, quantity, location, sensor_index, frequency, x, y, z, total

    Se usan únicamente valores devueltos por la API. No se pulsa SAVE DATA y no se
    crea el formato legacy ancho.
    """
    filas = []

    # Orden similar al export nativo observado: E ProbeCenter, H ProbeCenter,
    # H SensorMax, H TipCenter, H TipMax, Gradient ProbeCenter.
    d_probe = datos_por_location.get("probe-center")
    if d_probe:
        ts = d_probe.get("timestamp")
        fs = normalizar_frame_source(d_probe.get("source") or d_probe.get("frame_source"))
        freq = d_probe.get("frequency")
        ef = _campo_xyz_total(d_probe.get("e_field"))
        if ef is not None:
            filas.append(_fila_tidy(ts, ts_ref, fs, "IncidentElectricField",
                                    "ProbeCenter", 0, freq, *ef))

    for api_loc in API_LOCATIONS_EXPORT:
        d = datos_por_location.get(api_loc)
        if not d:
            continue
        ts = d.get("timestamp")
        fs = normalizar_frame_source(d.get("source") or d.get("frame_source"))
        freq = d.get("frequency")
        hf = _campo_xyz_total(d.get("h_field"))
        if hf is not None:
            filas.append(_fila_tidy(ts, ts_ref, fs, "IncidentMagneticField",
                                    LOCATION_API_TO_EXPORT.get(api_loc, api_loc),
                                    _extraer_sensor_index(d, api_loc), freq, *hf))

    if d_probe:
        ts = d_probe.get("timestamp")
        fs = normalizar_frame_source(d_probe.get("source") or d_probe.get("frame_source"))
        gr = _campo_xyz_total(d_probe.get("h_field_gradient"), total_keys=("total", "rms_total"))
        if gr is not None:
            filas.append(_fila_tidy(ts, ts_ref, fs, "IncidentMagneticFieldGradient",
                                    "ProbeCenter", 0, None, *gr))

    return filas

# ═══════════════════════════════════════════════════════════════
# HILO COLECTOR — recoge medidas a alta velocidad filtrando repetidas
# ═══════════════════════════════════════════════════════════════

def _qloc(api_location, sep="&"):
    """Parametro location de la API. Con None no se envia: se usa el punto de
    referencia de la sonda seleccionado en el software de MAGpy3."""
    return f"{sep}location={api_location}" if api_location else ""


class ColectorDatos:
    def __init__(self, api_location="sensor-max"):
        self.api_location         = api_location
        self.filas_measurement    = []       # Formato interno ancho usado para promedios/Excel
        self.filas_measurement_tidy = []     # Formato MAGPy 3.4 para Measurements.csv
        self.filas_compliance     = []
        self.ultimo_timestamp     = None
        self.ultimo_ts_compliance = None
        self.last_update_time     = None
        self.ts_inicio_ms         = None   # FIX: primer timestamp real para ventana relativa
        self.debug_api_measurements = []   # Primeras respuestas raw para diagnosticar campos extra
        self._tidy_seen           = set()
        self._ultimo_aviso_bloqueo = 0
        self._activo              = False
        self._hilo                = None
        self._hilo_compliance     = None   # FIX: hilo separado para no bloquear el polling
        self._hilo_tidy           = None   # FIX: hilo separado para no bloquear el polling de measurement

    def iniciar(self):
        self.filas_measurement    = []
        self.filas_measurement_tidy = []
        self.filas_compliance     = []
        self.ultimo_timestamp     = None
        self.ultimo_ts_compliance = None
        self.ts_inicio_ms         = None
        self.debug_api_measurements = []
        self._tidy_seen           = set()
        # Forzar redescubrimiento de endpoints en cada nueva sesión de medida
        ColectorDatos._endpoint_history_measurement = None
        ColectorDatos._endpoint_history_compliance  = None
        self._activo = True
        self._hilo             = threading.Thread(target=self._bucle,            daemon=True)
        self._hilo_compliance  = threading.Thread(target=self._bucle_compliance, daemon=True)
        self._hilo_tidy        = threading.Thread(target=self._bucle_tidy,       daemon=True)
        self._hilo.start()
        self._hilo_compliance.start()
        self._hilo_tidy.start()

    def detener(self):
        self._activo = False
        if self._hilo:
            self._hilo.join(timeout=5)
        if self._hilo_compliance:
            self._hilo_compliance.join(timeout=5)
        if self._hilo_tidy:
            self._hilo_tidy.join(timeout=5)

    def _bucle(self):
        sin_datos_consecutivos = 0
        while self._activo:
            hubo_dato = self._leer()
            if hubo_dato:
                sin_datos_consecutivos = 0
                # Dato recibido: volvemos a pedir inmediatamente
            else:
                sin_datos_consecutivos += 1
                if self.last_update_time and (time.time() - self.last_update_time > 5):
                    ahora = time.time()
                    if ahora - self._ultimo_aviso_bloqueo > 30:
                        msg("MAGPy no devuelve datos nuevos desde hace mas de 5 s", "AVISO")
                        self._ultimo_aviso_bloqueo = ahora
                # Sin dato nuevo: esperamos un poco antes de reintentar
                # para no saturar la CPU (50ms << 787ms de cadencia MAGpy)
                time.sleep(0.05)

    def _bucle_compliance(self):
        """Hilo separado para compliance — no bloquea el polling de measurement."""
        while self._activo:
            self._leer_compliance()
            time.sleep(POLL_INTERVAL_S * 4)   # Compliance no cambia tan rápido

    def _bucle_tidy(self):
        """
        Hilo separado y de baja frecuencia (1 Hz) para el export tidy MAGPy 3.4.
        FIX: antes se llamaba a _capturar_tidy_desde_api() dentro de _leer(), en el
        propio hilo de polling de measurement. Esa función hace hasta 6 peticiones
        HTTP extra (3 locations x 2 endpoints) por cada frame, lo que ralentizaba
        el polling y provocaba pérdida de frames en la ventana de promediado
        (afectando a los valores volcados al Excel). Se desacopla aquí para que
        el polling de measurement no pierda cadencia.
        """
        while self._activo:
            if self.filas_measurement:
                self._capturar_tidy_desde_api(self.filas_measurement[-1])
            time.sleep(1.0)

    # ── Descubrimiento de endpoint histórico (se hace una sola vez) ──────────
    _endpoint_history_measurement = None  # None = aún no descubierto
    _endpoint_history_compliance  = None

    @classmethod
    def _descubrir_endpoint_history(cls, tipo="measurement"):
        """
        Prueba los posibles endpoints históricos de la API MAGpy.
        Devuelve el nombre del endpoint que responde, o None si ninguno lo hace.
        tipo: "measurement" | "compliance"
        """
        candidatos = [
            f"data/history/{tipo}",
            f"data/all/{tipo}",
            f"data/{tipo}/history",
            f"data/{tipo}/list",
        ]
        for ep in candidatos:
            # Probamos con un since=0 para ver si el endpoint existe
            r = api_get(f"{ep}?since=0&location=sensor-max")
            if r is not None:
                msg(f"Endpoint histórico encontrado: /{ep}", "OK")
                return ep
        msg(f"No hay endpoint histórico para '{tipo}', usando solo /data/latest/{tipo}.", "AVISO")
        return False   # False = descubierto pero no disponible

    def _leer(self):
        """
        Solicita todos los frames nuevos desde el último timestamp.
        Devuelve True si se capturó al menos un frame nuevo, False si no.
        """
        capturados = 0
        try:
            if ColectorDatos._endpoint_history_measurement is None:
                ColectorDatos._endpoint_history_measurement = \
                    ColectorDatos._descubrir_endpoint_history("measurement")

            usar_history = ColectorDatos._endpoint_history_measurement

            if usar_history:
                since = self.ultimo_timestamp if self.ultimo_timestamp is not None else 0
                respuesta = api_get(
                    f"{usar_history}?since={since}{_qloc(self.api_location)}"
                )
                if isinstance(respuesta, list):
                    frames = respuesta
                elif isinstance(respuesta, dict):
                    frames = (respuesta.get("items")
                              or respuesta.get("data")
                              or respuesta.get("measurements")
                              or [])
                else:
                    frames = []
            else:
                datos = api_get(f"data/latest/measurement{_qloc(self.api_location, '?')}")
                frames = [datos] if datos else []

            for datos in frames:
                if not datos:
                    continue
                ts = datos.get("timestamp")
                if ts is None or ts == self.ultimo_timestamp:
                    continue
                if any(f["timestamp"] == ts for f in self.filas_measurement[-10:]):
                    continue

                self.ultimo_timestamp = ts
                self.last_update_time = time.time()
                if self.ts_inicio_ms is None:
                    self.ts_inicio_ms = ts

                hf   = datos.get("h_field") or {}
                ef   = datos.get("e_field") or {}
                gr   = datos.get("h_field_gradient") or {}
                freq = datos.get("frequency", 0)

                self.filas_measurement.append({
                    "timestamp":            ts,
                    "frequency":            freq,
                    "h_field_rms_x":        hf.get("rms_x", 0),
                    "h_field_rms_y":        hf.get("rms_y", 0),
                    "h_field_rms_z":        hf.get("rms_z", 0),
                    "e_field_rms_x":        ef.get("rms_x", 0),
                    "e_field_rms_y":        ef.get("rms_y", 0),
                    "e_field_rms_z":        ef.get("rms_z", 0),
                    "h_field_gradient_x":   gr.get("x", 0),
                    "h_field_gradient_y":   gr.get("y", 0),
                    "h_field_gradient_z":   gr.get("z", 0),
                    "extrapolation_factor": datos.get("extrapolation_factor", 0),
                    "gradient_valid":       datos.get("h_field_gradient_valid", False),
                    "e_valid":              datos.get("e_field_valid", False),
                    "source":               datos.get("source", datos.get("frame_source", "")),
                })
                # FIX: _capturar_tidy_desde_api ya NO se llama aquí — se movió a
                # _bucle_tidy (hilo propio a 1 Hz) para no penalizar la cadencia
                # de este polling con las llamadas HTTP extra que hace.
                capturados += 1

        except Exception as e:
            msg(f"DEBUG _leer excepcion: {type(e).__name__}: {e}", "ERROR")

        return capturados > 0

    def _capturar_tidy_desde_api(self, datos_base):
        """Captura un snapshot en formato largo MAGPy 3.4 para todas las locations posibles."""
        datos_por_location = {}
        for loc in API_LOCATIONS_EXPORT:
            if loc == self.api_location:
                d = datos_base
            else:
                d = (api_get(f"data/current/measurement?location={loc}")
                     or api_get(f"data/latest/measurement?location={loc}"))
            if isinstance(d, dict) and d.get("timestamp") is not None:
                datos_por_location[loc] = d
                if len(self.debug_api_measurements) < 12:
                    self.debug_api_measurements.append({"location": loc, "data": d})

        if not datos_por_location:
            return 0

        filas = construir_filas_measurement_tidy(datos_por_location, self.ts_inicio_ms)
        nuevas = 0
        for f in filas:
            clave = (f.get("timestamp"), f.get("frame_source"), f.get("quantity"),
                     f.get("location"), f.get("sensor_index"), f.get("frequency"))
            if clave in self._tidy_seen:
                continue
            self._tidy_seen.add(clave)
            self.filas_measurement_tidy.append(f)
            nuevas += 1
        return nuevas

    def _leer_compliance(self):
        """Lee compliance con endpoint histórico si está disponible."""
        try:
            if ColectorDatos._endpoint_history_compliance is None:
                ColectorDatos._endpoint_history_compliance = \
                    ColectorDatos._descubrir_endpoint_history("compliance")

            usar_history = ColectorDatos._endpoint_history_compliance
            ts_ref = self.ultimo_ts_compliance or 0

            if usar_history:
                respuesta = api_get(
                    f"{usar_history}?since={ts_ref}{_qloc(self.api_location)}"
                )
                if isinstance(respuesta, list):
                    bloques = respuesta
                elif isinstance(respuesta, dict):
                    bloques = (respuesta.get("items")
                               or respuesta.get("data")
                               or [respuesta])
                else:
                    bloques = []
            else:
                comp = api_get(f"data/latest/compliance{_qloc(self.api_location, '?')}")
                bloques = [comp] if comp else []

            for comp in bloques:
                if not comp:
                    continue
                ts = comp.get("timestamp") or self.ultimo_timestamp
                if ts is None or ts == self.ultimo_ts_compliance:
                    continue
                self.ultimo_ts_compliance = ts
                for item in comp.get("results", []):
                    ext = item.get("extrapolated") or {}
                    self.filas_compliance.append({
                        "timestamp":                  ts,
                        "standard":                   item.get("standard", ""),
                        "quantity":                   item.get("quantity", ""),
                        "unit":                       item.get("unit", ""),
                        "environment":                item.get("environment", ""),
                        "frequency":                  item.get("frequency", ""),
                        "value_rms":                  item.get("value_rms", ""),
                        "value_dB":                   item.get("value_dB", ""),
                        "safety_factor":              item.get("safety_factor", ""),
                        "extrapolation_factor":       item.get("extrapolation_factor", ""),
                        "conclusion":                 item.get("conclusion", ""),
                        "extrapolated_value_rms":     ext.get("value_rms", ""),
                        "extrapolated_value_dB":      ext.get("value_dB", ""),
                        "extrapolated_safety_factor": ext.get("safety_factor", ""),
                        "extrapolated_conclusion":    ext.get("conclusion", ""),
                        "enhancement_factor":         item.get("enhancement_factor", ""),
                    })
        except Exception:
            pass

    def n_filas(self):
        return len(self.filas_measurement)


# ═══════════════════════════════════════════════════════════════
# CAPTURA Y GUARDADO
# ═══════════════════════════════════════════════════════════════

_PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
_screenshot_api_disponible = None   # None = sin probar | False = no existe | str = endpoint válido


def _win32():
    """user32/gdi32/dwmapi con argtypes/restype explícitos (imprescindible en Windows 64 bits:
    sin ellos los handles se truncan a 32 bits)."""
    from ctypes import wintypes as wt
    u, g = ctypes.windll.user32, ctypes.windll.gdi32
    H, V = ctypes.c_void_p, ctypes.c_void_p
    u.GetForegroundWindow.restype = H
    u.SetForegroundWindow.argtypes = [H]
    u.IsIconic.argtypes = [H];  u.IsWindowVisible.argtypes = [H]
    u.ShowWindow.argtypes = [H, ctypes.c_int]
    u.GetWindowRect.argtypes = [H, ctypes.POINTER(wt.RECT)]
    u.GetWindowTextLengthW.argtypes = [H]
    u.GetWindowTextW.argtypes = [H, wt.LPWSTR, ctypes.c_int]
    u.GetClassNameW.argtypes = [H, wt.LPWSTR, ctypes.c_int]
    u.GetWindowThreadProcessId.argtypes = [H, ctypes.POINTER(wt.DWORD)]
    u.GetWindowDC.argtypes = [H];  u.GetWindowDC.restype = V
    u.ReleaseDC.argtypes = [H, V]
    u.PrintWindow.argtypes = [H, V, ctypes.c_uint]
    g.CreateCompatibleDC.argtypes = [V];  g.CreateCompatibleDC.restype = V
    g.CreateCompatibleBitmap.argtypes = [V, ctypes.c_int, ctypes.c_int];  g.CreateCompatibleBitmap.restype = V
    g.SelectObject.argtypes = [V, V];  g.SelectObject.restype = V
    g.DeleteObject.argtypes = [V];  g.DeleteDC.argtypes = [V]
    return u, g, wt


def _buscar_ventana_magpy():
    """Devuelve (hwnd, titulo) de la ventana visible de MAGPy más grande, o (None, None).
    Excluye la propia GUI de automatización (mismo PID), consolas y ventanas del Explorador."""
    u, _, wt = _win32()
    pid_propio = os.getpid()
    excluidas = {"ConsoleWindowClass", "CASCADIA_HOSTING_WINDOW_CLASS", "CabinetWClass"}
    candidatas = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def _cb(hwnd, _lp):
        if not u.IsWindowVisible(hwnd):
            return True
        n = u.GetWindowTextLengthW(hwnd)
        if n == 0:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        u.GetWindowTextW(hwnd, buf, n + 1)
        titulo = buf.value
        tl = titulo.lower()
        if not any(h in tl for h in MAGPY_WINDOW_TITLE_HINTS):
            return True
        pid = wt.DWORD(0)
        u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == pid_propio:
            return True
        cls = ctypes.create_unicode_buffer(256)
        u.GetClassNameW(hwnd, cls, 256)
        if cls.value in excluidas or tl.endswith((".py", ".exe")) or "\\" in titulo:
            return True
        r = wt.RECT()
        u.GetWindowRect(hwnd, ctypes.byref(r))
        candidatas.append(((r.right - r.left) * (r.bottom - r.top), hwnd, titulo))
        return True

    u.EnumWindows(_cb, 0)
    if not candidatas:
        return None, None
    _, hwnd, titulo = max(candidatas, key=lambda c: c[0])
    return hwnd, titulo


def _rect_ventana(hwnd):
    """Rectángulo visible de la ventana (sin sombras invisibles) en píxeles de pantalla."""
    u, _, wt = _win32()
    r = wt.RECT()
    try:   # DWMWA_EXTENDED_FRAME_BOUNDS = 9
        ok = ctypes.windll.dwmapi.DwmGetWindowAttribute(
            ctypes.c_void_p(hwnd), 9, ctypes.byref(r), ctypes.sizeof(r)) == 0
    except Exception:
        ok = False
    if not ok:
        u.GetWindowRect(hwnd, ctypes.byref(r))
    return r.left, r.top, r.right, r.bottom


def _traer_al_frente(hwnd):
    """Restaura (si está minimizada) y trae la ventana al frente. Devuelve el hwnd que
    estaba en primer plano antes, para poder devolverle el foco después."""
    u, _, _ = _win32()
    previo = u.GetForegroundWindow()
    if u.IsIconic(hwnd):
        u.ShowWindow(hwnd, 9)          # SW_RESTORE
    # Pulsar/soltar ALT evita el bloqueo de Windows al cambiar de ventana en primer plano
    ctypes.windll.user32.keybd_event(0x12, 0, 0, 0)
    ctypes.windll.user32.keybd_event(0x12, 0, 2, 0)
    u.SetForegroundWindow(hwnd)
    time.sleep(CAPTURA_ESPERA_FOCO_S)
    return previo, (u.GetForegroundWindow() == hwnd)


def _captura_region(hwnd):
    from PIL import ImageGrab
    l, t, r, b = _rect_ventana(hwnd)
    return ImageGrab.grab(bbox=(l, t, r, b), all_screens=True)


def _captura_printwindow(hwnd):
    """Plan B: PrintWindow, captura el contenido de la ventana aunque otra la tape."""
    from PIL import Image
    u, g, wt = _win32()
    r = wt.RECT()
    u.GetWindowRect(hwnd, ctypes.byref(r))
    w, h = r.right - r.left, r.bottom - r.top

    class BMIH(ctypes.Structure):
        _fields_ = [("biSize", wt.DWORD), ("biWidth", wt.LONG), ("biHeight", wt.LONG),
                    ("biPlanes", wt.WORD), ("biBitCount", wt.WORD), ("biCompression", wt.DWORD),
                    ("biSizeImage", wt.DWORD), ("biXPelsPerMeter", wt.LONG),
                    ("biYPelsPerMeter", wt.LONG), ("biClrUsed", wt.DWORD),
                    ("biClrImportant", wt.DWORD)]

    g.GetDIBits.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint,
                            ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint]
    hdc = u.GetWindowDC(hwnd)
    mem = g.CreateCompatibleDC(hdc)
    bmp = g.CreateCompatibleBitmap(hdc, w, h)
    g.SelectObject(mem, bmp)
    try:
        if not u.PrintWindow(hwnd, mem, 2):          # PW_RENDERFULLCONTENT
            return None
        bi = BMIH(ctypes.sizeof(BMIH), w, -h, 1, 32, 0, 0, 0, 0, 0, 0)   # alto negativo = top-down
        buf = ctypes.create_string_buffer(w * h * 4)
        g.GetDIBits(mem, bmp, 0, h, buf, ctypes.byref(bi), 0)
        return Image.frombuffer("RGB", (w, h), buf, "raw", "BGRX", 0, 1)
    finally:
        g.DeleteObject(bmp); g.DeleteDC(mem); u.ReleaseDC(hwnd, hdc)


def _imagen_valida(img):
    """Descarta capturas vacías (todo negro), típicas de PrintWindow con superficies GPU."""
    return img is not None and img.width > 50 and img.height > 50 and img.convert("L").getextrema()[1] > 0


def _screenshot_via_api(ruta):
    """Intenta usar el 'capture screenshot' de MAGPy por API. True si guardó un PNG."""
    global _screenshot_api_disponible
    if not MAGPY_SCREENSHOT_ENDPOINTS or _screenshot_api_disponible is False:
        return False
    candidatos = ([_screenshot_api_disponible] if _screenshot_api_disponible
                  else list(MAGPY_SCREENSHOT_ENDPOINTS))
    for ep in candidatos:
        try:
            r = _session.get(f"{MAGPY_HOST}/{ep}", timeout=8)
        except Exception:
            continue
        if r.status_code == 200 and r.content[:8] == _PNG_MAGIC:
            with open(ruta, "wb") as f:
                f.write(r.content)
            _screenshot_api_disponible = ep
            return True
    _screenshot_api_disponible = False
    return False


def cerrar_teclado_tactil():
    """Cierra el teclado tactil de Windows (TabTip / OSK) para que no salga en la captura.
    Si no hay teclado abierto o no es Windows, no hace nada."""
    if sys.platform != "win32":
        return
    try:
        import subprocess
        for exe in ("TabTip.exe", "osk.exe"):
            subprocess.run(["taskkill", "/IM", exe, "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        time.sleep(0.5)
    except Exception:
        pass


AVISO_TECLADO = "Cierra el teclado tactil antes de continuar (si no, saldra en la captura)."


# ── MODO DE LA SONDA SEGUN LA DISTANCIA (Compliance Location en MAGpy3) ───────────────
#   < 7,5 mm            -> Tip Max      (obligatorio, p. ej. contacto a 0 cm)
#   >= 7,5 mm           -> Sensor Max   (obligatorio a mas de 7,5 mm del DUT)
#   > 18,5 mm           -> Probe Center (referencia = centro de la sonda)
UMBRAL_TIP_MAX_CM      = 0.75
UMBRAL_PROBE_CENTER_CM = 1.85


def modo_por_distancia(distancia_cm):
    """Devuelve (nombre del modo en MAGpy3, valor de 'location' de la API)."""
    d = float(distancia_cm)
    if d < UMBRAL_TIP_MAX_CM:
        return "Tip Max", "tip-max"
    if d <= UMBRAL_PROBE_CENTER_CM:
        return "Sensor Max", "sensor-max"
    return "Probe Center", "probe-center"



def capturar_pantalla(carpeta, nombre_fase):
    """
    Guarda un PNG de la ventana de MAGPy (NO de toda la pantalla) al terminar la medida.
    Orden: 1) screenshot nativo de MAGPy por API, si existe; 2) ventana de MAGPy traída al
    frente y recortada a su rectángulo; 3) PrintWindow de esa ventana.
    Si todo falla NO se hace captura de pantalla completa: se avisa y la medida sigue
    (los datos ya se guardan aparte). Devuelve la ruta del PNG o None.
    """
    cerrar_teclado_tactil()
    ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
    ruta = os.path.join(carpeta, f"screenshot_MAGPy_{nombre_fase.replace(' ','_')}_{ts}.png")
    try:
        if _screenshot_via_api(ruta):
            msg(f"Captura de MAGPy guardada (screenshot nativo): {os.path.basename(ruta)}", "OK")
            return ruta

        hwnd, titulo = None, None
        for intento in range(1, CAPTURA_REINTENTOS + 1):
            hwnd, titulo = _buscar_ventana_magpy()
            if hwnd:
                break
            time.sleep(1)
        if not hwnd:
            msg("No se encontro la ventana de MAGPy (titulo con "
                f"{'/'.join(MAGPY_WINDOW_TITLE_HINTS)}). No se guarda captura.", "ERROR")
            return None

        u = _win32()[0]
        previo, en_frente = _traer_al_frente(hwnd)
        img = None
        try:
            if en_frente:
                img = _captura_region(hwnd)
        finally:
            # Devolver el foco a lo que estaba delante (p. ej. la GUI de automatización)
            if previo and previo != hwnd:
                u.SetForegroundWindow(previo)

        if not _imagen_valida(img):
            img = _captura_printwindow(hwnd)
        if not _imagen_valida(img):
            msg(f"No se pudo capturar la ventana de MAGPy ('{titulo}'). No se guarda captura.", "ERROR")
            return None

        img.save(ruta)
        msg(f"Captura de MAGPy guardada: {os.path.basename(ruta)}", "OK")
        return ruta
    except Exception as e:
        msg(f"Fallo al capturar MAGPy: {type(e).__name__}: {e}. La medida continua sin captura.", "ERROR")
        return None

def _csv_bytes(filas, campos):
    buf = io.StringIO()
    w   = csv.DictWriter(buf, fieldnames=campos, extrasaction="ignore")
    w.writeheader(); w.writerows(filas)
    return buf.getvalue().encode("utf-8")

def _construir_spectra_tidy(api_location):
    """Devuelve Spectra en formato largo MAGPy 3.4 para la location seleccionada."""
    sp  = api_get(f"data/latest/spectra{_qloc(api_location, '?')}") or {}
    frq = sp.get("frequency") or []
    hf  = sp.get("h_field") or {}
    ef  = sp.get("e_field") or {}
    n   = len(frq)

    def _lista(d, *keys):
        for k in keys:
            v = d.get(k) if isinstance(d, dict) else None
            if isinstance(v, list):
                return v
        return [None] * n

    filas = []
    location = LOCATION_API_TO_EXPORT.get(api_location, api_location or "")
    for quantity, campo in (("IncidentMagneticField", hf), ("IncidentElectricField", ef)):
        xs = _lista(campo, "rms_x", "x")
        ys = _lista(campo, "rms_y", "y")
        zs = _lista(campo, "rms_z", "z")
        ts = _lista(campo, "rms_total", "total")
        mx = _lista(campo, "rms_max", "max")
        for i in range(n):
            x = xs[i] if i < len(xs) else None
            y = ys[i] if i < len(ys) else None
            z = zs[i] if i < len(zs) else None
            total = ts[i] if i < len(ts) else None
            if total is None:
                total = _vector_total(x, y, z)
            filas.append({
                "frequency": frq[i],
                "quantity": quantity,
                "location": location,
                "x": x,
                "y": y,
                "z": z,
                "total": total,
                "max": mx[i] if i < len(mx) else None,
            })
    return filas

def guardar_datos_zip(carpeta, nombre_fase, colector, api_location):
    msg(f"Empaquetando {colector.n_filas()} filas unicas medidas...", "ESPERA")
    ts_str     = datetime.now().strftime("%Y-%m-%dT%H_%M_%S")
    nombre_zip = f"Data_{nombre_fase.replace(' ','_')}_{ts_str}.zip"
    ruta_zip   = os.path.join(carpeta, nombre_zip)

    filas_measurements = list(colector.filas_measurement_tidy)
    if not filas_measurements:
        msg("No se capturaron filas en formato MAGPy 3.4. Se guardará Measurements con cabecera correcta pero sin datos.", "AVISO")

    filas_spec = _construir_spectra_tidy(api_location)

    metadata = {"timestamp": ts_str, "fase": nombre_fase,
                "n_muestras_unicas": colector.n_filas(),
                "n_measurements_tidy": len(filas_measurements),
                "location_utilizada_para_promedio": api_location or "seleccionada en MAGpy3",
                "measurements_format": "MAGPy 3.4 tidy API transform",
                "nota": "Measurements.csv se genera desde la API documentada, sin pulsar SAVE DATA.",
                "version": api_get("version") or {},
                "device":  api_get("device/info") or {}}

    campos_m = MEASUREMENTS_TIDY_COLUMNS
    campos_s = ["frequency", "quantity", "location", "x", "y", "z", "total", "max"]
    campos_c = ["timestamp","standard","quantity","unit","environment","frequency",
                "value_rms","value_dB","safety_factor","extrapolation_factor","conclusion",
                "extrapolated_value_rms","extrapolated_value_dB",
                "extrapolated_safety_factor","extrapolated_conclusion","enhancement_factor"]

    with zipfile.ZipFile(ruta_zip, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"Measurements_{ts_str}.csv",
                   _csv_bytes(filas_measurements, campos_m))
        z.writestr(f"Spectra_{ts_str}.csv",
                   _csv_bytes(filas_spec, campos_s))
        z.writestr(f"Compliance_{ts_str}.csv",
                   _csv_bytes(colector.filas_compliance, campos_c))
        z.writestr(f"Metadata_{ts_str}.json",
                   json.dumps(metadata, indent=2).encode("utf-8"))
        z.writestr(f"Promedio_samples_{ts_str}.json", json.dumps({
            "ts_inicio_ms": colector.ts_inicio_ms,
            "filas_measurement": colector.filas_measurement,
        }, indent=2, default=str).encode("utf-8"))
        # Debug útil para comprobar si la API expone sensor_index/sensor_num con otro nombre.
        z.writestr(f"DEBUG_API_Measurements_raw_{ts_str}.json",
                   json.dumps(colector.debug_api_measurements, indent=2).encode("utf-8"))

    msg(f"ZIP guardado: {nombre_zip} ({len(filas_measurements)} filas Measurements formato MAGPy 3.4)", "OK")
    return ruta_zip


# ═══════════════════════════════════════════════════════════════
# PROMEDIADO — campo H y campo E
# ═══════════════════════════════════════════════════════════════

def calcular_h_total(x, y, z):
    try:
        return math.sqrt(float(x)**2 + float(y)**2 + float(z)**2)
    except (TypeError, ValueError):
        return None

def calcular_e_total(x, y, z):
    try:
        return math.sqrt(float(x)**2 + float(y)**2 + float(z)**2)
    except (TypeError, ValueError):
        return None

def promediar_medidas(filas_measurement, ms_ventana, ts_inicio_ms=None):
    """
    Calcula promedios de H y E sobre la ventana ms_ventana.
    ts_inicio_ms: timestamp del primer frame capturado por el colector.
    Si no se pasa, se usa el mínimo del DataFrame (comportamiento anterior).
    """
    if not filas_measurement:
        return {"h_prom": None, "e_prom": None, "freq_hz": None, "freq_mhz": None}

    df = pd.DataFrame(filas_measurement)
    ts_ref = ts_inicio_ms if ts_inicio_ms is not None else df["timestamp"].min()
    df["ts_rel"] = df["timestamp"] - ts_ref
    # Solo datos dentro de la ventana (y con ts_rel >= 0 para evitar frames previos)
    df_v = df[(df["ts_rel"] >= 0) & (df["ts_rel"] <= ms_ventana)].copy()

    if df_v.empty:
        msg("AVISO: ningún frame dentro de la ventana temporal, usando todos los datos.", "AVISO")
        df_v = df.copy()

    df_v["h_total"] = df_v.apply(
        lambda r: calcular_h_total(r.get("h_field_rms_x", 0), r.get("h_field_rms_y", 0), r.get("h_field_rms_z", 0)), axis=1)

    df_v["e_total"] = df_v.apply(
        lambda r: calcular_e_total(r.get("e_field_rms_x", 0), r.get("e_field_rms_y", 0), r.get("e_field_rms_z", 0)), axis=1)

    h_prom = df_v["h_total"].mean() if df_v["h_total"].notna().any() else None
    e_prom = df_v["e_total"].mean() if df_v["e_total"].notna().any() else None

    freq_hz  = df_v["frequency"].mode().iloc[0] if not df_v["frequency"].empty else None
    freq_mhz = round(freq_hz / 1_000_000, 6) if freq_hz else None

    msg(f"promediar_medidas: {len(df_v)} frames usados de {len(df)} totales "
        f"(ventana {ms_ventana/60000:.1f} min)", "OK")

    # Deteccion de multi-frecuencia con TOLERANCIA RELATIVA (0.1%), no con
    # igualdad exacta en punto flotante. El equipo tiene jitter de medida de
    # la frecuencia frame a frame (variaciones de pocos kHz sobre una unica
    # señal real), que con comparacion exacta se contaba como "frecuencias
    # distintas" y disparaba avisos de multi-frecuencia falsos positivos.
    TOLERANCIA_FRECUENCIA = 0.001   # 0.1% relativo
    n_frecuencias_distintas = 0
    grupos_frecuencia = []
    if "frequency" in df_v and df_v["frequency"].notna().any():
        freqs_ordenadas = sorted(df_v["frequency"].dropna().unique())
        grupo_actual = [freqs_ordenadas[0]]
        for f in freqs_ordenadas[1:]:
            centro_grupo = sum(grupo_actual) / len(grupo_actual)
            if abs(f - centro_grupo) / centro_grupo <= TOLERANCIA_FRECUENCIA:
                grupo_actual.append(f)
            else:
                grupos_frecuencia.append(grupo_actual)
                grupo_actual = [f]
        grupos_frecuencia.append(grupo_actual)
        n_frecuencias_distintas = len(grupos_frecuencia)

    if n_frecuencias_distintas > 1:
        conteo = df_v["frequency"].value_counts()
        detalle_grupos = []
        for grupo in grupos_frecuencia:
            n_frames_grupo = sum(conteo.get(f, 0) for f in grupo)
            centro = sum(grupo) / len(grupo)
            detalle_grupos.append(
                f"~{centro/1_000_000:.6f} MHz ({n_frames_grupo} frames, "
                f"{n_frames_grupo/len(df_v)*100:.1f}%, {len(grupo)} lecturas distintas en el grupo)"
            )
        msg(f"Multi-frecuencia detectada ({n_frecuencias_distintas} grupos, "
            f"tolerancia {TOLERANCIA_FRECUENCIA*100:.1f}%): " + ", ".join(detalle_grupos), "AVISO")

    return {
        "h_prom":    round(h_prom, 6) if h_prom is not None else None,
        "e_prom":    round(e_prom, 6) if e_prom is not None else None,
        "freq_hz":   freq_hz,
        "freq_mhz":  freq_mhz,
        "multi_frecuencia": n_frecuencias_distintas > 1,
    }


def calcular_peak_desde_rms(prom_rms, ignorar_multifrecuencia=False):
    """
    Deriva el valor Peak a partir de un promedio RMS ya calculado, usando
    peak = RMS x sqrt(2). SOLO valido para senal monofrecuencia sinusoidal
    con multi-frequency assessment deshabilitado (confirmado por soporte SPEAG).

    Si prom_rms indica que se detecto mas de una frecuencia en la ventana,
    NO se aplica el factor (se devuelve None en los campos de campo) para
    evitar reportar un Peak matematicamente invalido.
    """
    SQRT2 = math.sqrt(2)
    es_multi_freq = prom_rms.get("multi_frecuencia", False) and not ignorar_multifrecuencia

    if es_multi_freq or prom_rms.get("h_prom") is None or prom_rms.get("e_prom") is None:
        return {
            "h_prom":   None,
            "e_prom":   None,
            "freq_hz":  prom_rms.get("freq_hz"),
            "freq_mhz": prom_rms.get("freq_mhz"),
            "multi_frecuencia": es_multi_freq,
        }

    return {
        "h_prom":   round(prom_rms["h_prom"] * SQRT2, 6),
        "e_prom":   round(prom_rms["e_prom"] * SQRT2, 6),
        "freq_hz":  prom_rms.get("freq_hz"),
        "freq_mhz": prom_rms.get("freq_mhz"),
        "multi_frecuencia": False,
    }


# ═══════════════════════════════════════════════════════════════
# ESCRITURA EN EXCEL
# ═══════════════════════════════════════════════════════════════

def encontrar_primera_fila_libre(ws, col_ref, first_data_row):
    r = first_data_row
    while ws.cell(r, col_ref).value is not None:
        r += 1
    return r

def escribir_fila_excel(ws, fila, cols, technology, wpt_client, battery,
                        nombre_posicion, distancia_cm, freq_mhz_e, e_prom,
                        fecha_e, freq_mhz_h, h_prom, fecha_h):
    ws.cell(fila, cols["technology"]).value = technology
    ws.cell(fila, cols["wpt"]).value        = wpt_client
    ws.cell(fila, cols["battery"]).value    = battery
    ws.cell(fila, cols["testside"]).value   = nombre_posicion
    ws.cell(fila, cols["distance"]).value   = distancia_cm

    if freq_mhz_e is not None:
        ws.cell(fila, cols["freq_e"]).value = freq_mhz_e
    if e_prom is not None:
        ws.cell(fila, cols["efield"]).value = round(e_prom, 4)
    ws.cell(fila, cols["date_e"]).value = fecha_e

    if freq_mhz_h is not None:
        ws.cell(fila, cols["freq_h"]).value = freq_mhz_h
    if h_prom is not None:
        ws.cell(fila, cols["hfield"]).value = round(h_prom, 4)
    ws.cell(fila, cols["date_h"]).value = fecha_h

def _abrir_excel_protegido(ruta_excel, keep_vba):
    """
    Descifra el .xlsm/.xlsx protegido con contraseña de Office en memoria
    (usando msoffcrypto-tool) y devuelve el Workbook de openpyxl ya abierto.
    Si el archivo no está cifrado, hace fallback a load_workbook directo.
    """
    global _EXCEL_PASSWORD
    with open(ruta_excel, "rb") as f:
        office_file = msoffcrypto.OfficeFile(f)
        if not office_file.is_encrypted():
            f.seek(0)
            return load_workbook(io.BytesIO(f.read()), keep_vba=keep_vba)

        if not _EXCEL_PASSWORD:
            _EXCEL_PASSWORD = getpass.getpass(
                "  Archivo Excel protegido. Contrasena (no se muestra en pantalla): "
            )
        buffer_descifrado = io.BytesIO()
        office_file.load_key(password=_EXCEL_PASSWORD)
        office_file.decrypt(buffer_descifrado)
        buffer_descifrado.seek(0)
        return load_workbook(buffer_descifrado, keep_vba=keep_vba)


def _guardar_excel_protegido(wb, ruta_excel):
    """Preparar el libro completo antes de reemplazar el original, manteniendo el cifrado."""
    import tempfile
    buffer_plano = io.BytesIO()
    wb.save(buffer_plano)
    buffer_plano.seek(0)
    if _EXCEL_PASSWORD:
        office_file = msoffcrypto.OfficeFile(buffer_plano)
        buffer_cifrado = io.BytesIO()
        office_file.encrypt(password=_EXCEL_PASSWORD, outfile=buffer_cifrado)
        contenido = buffer_cifrado.getvalue()
    else:
        contenido = buffer_plano.getvalue()
    temporal = None
    try:
        with tempfile.NamedTemporaryFile(dir=os.path.dirname(os.path.abspath(ruta_excel)),
                                         prefix=".magpy_excel_", suffix=".tmp", delete=False) as f:
            temporal = f.name
            f.write(contenido)
            f.flush()
            os.fsync(f.fileno())
        # Si Windows impide reemplazar el Excel abierto, el original queda intacto.
        os.replace(temporal, ruta_excel)
    finally:
        if temporal and os.path.exists(temporal):
            os.unlink(temporal)


def guardar_json_atomico(ruta, datos):
    import tempfile
    carpeta = os.path.dirname(os.path.abspath(ruta))
    temporal = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=carpeta,
                                         prefix=".magpy_", suffix=".tmp", delete=False) as f:
            temporal = f.name
            json.dump(datos, f, ensure_ascii=False, indent=2, default=str)
        os.replace(temporal, ruta)
    finally:
        if temporal and os.path.exists(temporal):
            os.unlink(temporal)


def promedio_completo(prom, es_peak=False):
    """Solo datos numericos finitos; cero es una medida valida."""
    if not isinstance(prom, dict) or (es_peak and prom.get("multi_frecuencia")):
        return False
    try:
        return all(prom.get(k) is not None and math.isfinite(float(prom[k]))
                   for k in ("h_prom", "e_prom"))
    except (TypeError, ValueError, OverflowError):
        return False


def actualizar_excel(ruta_excel, region, nombre_posicion, distancias_cm,
                     promedios_por_tipo, technology, wpt_client, battery,
                     fechas_fin, frecuencia_khz, avisar_sin_datos=True, destino_excel=None):
    """Conservar los resultados y permitir reintentar SOLO el volcado a Excel."""
    if not ruta_excel:
        return None  # Excel opcional, sin afirmar que se ha escrito.
    argumentos = dict(ruta_excel=ruta_excel, region=region,
        nombre_posicion=nombre_posicion, distancias_cm=distancias_cm,
        promedios_por_tipo=promedios_por_tipo, technology=technology,
        wpt_client=wpt_client, battery=battery, fechas_fin=fechas_fin,
        frecuencia_khz=frecuencia_khz, avisar_sin_datos=avisar_sin_datos)
    respaldo = None
    destino = destino_excel if destino_excel is not None else {}
    registro = {"estado": "PENDIENTE", "argumentos": argumentos, "destino": destino}
    try:
        carpeta = os.path.join(os.path.dirname(os.path.abspath(ruta_excel)),
                               "AutoMagpy_resultados")
        os.makedirs(carpeta, exist_ok=True)
        respaldo = os.path.join(carpeta, datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".json")
        guardar_json_atomico(respaldo, registro)
    except Exception as e:
        msg(f"No se pudo guardar el respaldo del resultado: {e}", "ERROR")
        respaldo = None
    while True:
        if _actualizar_excel_un_intento(_destino=destino, **argumentos):
            if respaldo:
                registro["estado"] = "GUARDADO_Y_VERIFICADO"
                try:
                    guardar_json_atomico(respaldo, registro)
                except Exception as e:
                    msg(f"Excel verificado, pero no se pudo actualizar el respaldo: {e}", "AVISO")
            return True
        if respaldo:
            try:
                guardar_json_atomico(respaldo, registro)
            except Exception as e:
                msg(f"No se pudo actualizar el respaldo pendiente: {e}", "ERROR")
        detalle = (f"Resultado conservado en {respaldo}." if respaldo else
                   "No se pudo crear el respaldo JSON; conserva los CSV/ZIP de la medida.")
        opcion = preguntar_opcion(
            f"No se ha confirmado el guardado de '{nombre_posicion}' ({region}). "
            "Cierra el archivo en Excel y pulsa REINTENTAR: no se repite la medida. "
            + detalle + " PENDIENTE permite seguir con el volcado pendiente.",
            ["REINTENTAR", "PENDIENTE"])
        if opcion == "PENDIENTE":
            msg(f"Excel PENDIENTE para '{nombre_posicion}' ({region}). {detalle}", "ERROR")
            return False


def _actualizar_excel_un_intento(ruta_excel, region, nombre_posicion, distancias_cm,
                     promedios_por_tipo, technology, wpt_client, battery,
                     fechas_fin, frecuencia_khz, avisar_sin_datos=True, _destino=None):
    """
    Escritura en Excel: best-effort. Si el archivo esta protegido con
    contrasena, se pide por consola (input oculto) SOLO si hace falta.
    Si falla por password incorrecta, se reintenta una vez; si sigue
    fallando, se avisa y se continua la sesion de medida sin abortar
    (los datos de la medida no se pierden, solo no se vuelcan al Excel).

    Cada bloque de EXCEL_COL_MAP lleva una clave "valor" ("RMS", "Peak" o
    None) que determina que promedio se escribe en esa tabla. Los tres
    parametros siguientes son dicts indexados por ese tipo:

        distancias_cm      {"RMS": 1.0, "Peak": 1.0}
        promedios_por_tipo {"RMS": {...}, "Peak": {...}}
        fechas_fin         {"RMS": datetime, "Peak": datetime}

    Un bloque con "valor": None nunca se escribe. Un bloque cuyo tipo no
    tenga promedio disponible se salta con aviso.
    """
    global _EXCEL_PASSWORD

    if not ruta_excel or not os.path.isfile(ruta_excel):
        msg("Ruta de Excel no valida, omitiendo escritura.", "AVISO")
        return False

    keep_vba = ruta_excel.lower().endswith(".xlsm")
    wb = None
    for intento in range(2):   # 1 intento normal + 1 reintento si la password es incorrecta
        try:
            wb = _abrir_excel_protegido(ruta_excel, keep_vba)
            break
        except Exception as e:
            es_error_password = _EXCEL_PASSWORD is not None and (
                "password" in str(e).lower() or "hmac" in str(e).lower()
                or isinstance(e, ValueError)
            )
            if es_error_password and intento == 0:
                msg("Contrasena incorrecta o fallo al descifrar. Reintentando...", "AVISO")
                _EXCEL_PASSWORD = None
                continue
            msg(f"No se pudo abrir el Excel: {type(e).__name__}: {e}. "
                f"Se omite la escritura en Excel para esta posicion.", "ERROR")
            return False

    if wb is None:
        msg("No se pudo abrir el Excel tras reintentar. Se omite la escritura.", "ERROR")
        return False

    sheet_name = CONFIG_REGION[region]["sheet"]
    if sheet_name not in wb.sheetnames:
        msg(f"Pestaña '{sheet_name}' no encontrada en el Excel.", "ERROR")
        wb.close()
        return False

    ws           = wb[sheet_name]
    bloques      = EXCEL_COL_MAP[region]
    freq_defecto = round(frecuencia_khz / 1000, 6)

    promedios_por_tipo = promedios_por_tipo or {}
    distancias_cm      = distancias_cm or {}
    fechas_fin         = fechas_fin or {}

    # Seleccion de bloques: solo los que tienen tipo asignado y datos disponibles
    a_escribir = []
    for cols in bloques:
        tipo = cols.get("valor")          # "RMS", "Peak" o None (tabla en blanco)
        if tipo is None:
            continue
        prom = promedios_por_tipo.get(tipo)
        if not prom:
            if avisar_sin_datos:
                msg(f"  Excel '{sheet_name}': sin datos {tipo}, bloque col "
                    f"{cols['technology']} no escrito.", "AVISO")
            continue
        if not promedio_completo(prom, es_peak=(tipo == "Peak")):
            msg(f"Excel {sheet_name}: datos {tipo} incompletos o invalidos para '{nombre_posicion}'. "
                "No se escribe una fila con campos vacios.", "ERROR")
            wb.close()
            return False
        a_escribir.append((cols, tipo, prom))

    if not a_escribir:
        msg(f"No hay datos que escribir en '{sheet_name}'.", "AVISO")
        wb.close()
        return False

    # Misma fila para todos los bloques -> las tablas RMS y Peak quedan alineadas
    fila = (_destino or {}).get("fila")
    if fila is None:
        # Si Peak se adquiere por separado (contacto puntual), la tabla Peak se rellena sola:
        # primera fila libre de esa tabla y la siguiente medida justo debajo, sin dejar huecos.
        if {tipo for _, tipo, _ in a_escribir} == {"Peak"}:
            peak_cols = a_escribir[0][0]
            fila = encontrar_primera_fila_libre(ws, peak_cols["technology"], peak_cols["first_data_row"])
        if fila is None:
            fila = max(encontrar_primera_fila_libre(ws, c["technology"], c["first_data_row"])
                       for c in bloques if c.get("valor") is not None)
        if _destino is not None:
            _destino["fila"] = fila
    else:
        for c, _, _ in a_escribir:
            ocupante = ws.cell(fila, c["testside"]).value
            if ocupante not in (None, nombre_posicion):
                msg(f"La fila {fila} contiene otra posicion. No se sobrescribe.", "ERROR")
                wb.close()
                return False

    esperadas = {}
    for cols, tipo, prom in a_escribir:
        h_prom   = prom.get("h_prom")
        e_prom   = prom.get("e_prom")
        freq_mhz = prom.get("freq_mhz") or freq_defecto

        fecha     = fechas_fin.get(tipo)
        fecha_str = fecha.strftime("%Y-%m-%d") if hasattr(fecha, "strftime") else ""

        dist = distancias_cm.get(tipo)

        if tipo == "Peak" and prom.get("multi_frecuencia"):
            msg(f"  Excel '{sheet_name}': Peak multi-frecuencia, se escribe la fila "
                f"sin valores de campo (rellenar a mano).", "AVISO")

        escribir_fila_excel(
            ws, fila, cols, technology, wpt_client, battery,
            nombre_posicion, dist, freq_mhz, e_prom, fecha_str,
            freq_mhz, h_prom, fecha_str
        )
        for clave in ("technology", "wpt", "battery", "testside", "distance",
                      "freq_e", "efield", "date_e", "freq_h", "hfield", "date_h"):
            col = cols[clave]
            esperadas[col] = ws.cell(fila, col).value
        msg(f"  Excel '{sheet_name}' bloque {tipo} (col {cols['technology']}): "
            f"fila {fila} escrita", "OK")

    try:
        _guardar_excel_protegido(wb, ruta_excel)
        msg(f"Excel guardado: {os.path.basename(ruta_excel)}", "OK")
        # Verificacion: se vuelve a abrir el archivo y se comprueba que la posicion esta en su fila
        try:
            wb2 = _abrir_excel_protegido(ruta_excel, keep_vba)
            ws2 = wb2[sheet_name]
            falta = [col for col, valor in esperadas.items()
                     if ws2.cell(fila, col).value != valor]
            wb2.close()
            if falta:
                msg(f"ATENCION: '{nombre_posicion}' NO aparece en el Excel (fila {fila}) tras guardar. "
                    f"Celdas sin verificar: {falta}. Reintenta el volcado, sin repetir la medida.", "ERROR")
                return False
            else:
                msg(f"Excel verificado: '{nombre_posicion}', fila {fila}, incluidos E y H RMS/Peak.", "OK")
                return True
        except Exception as e2:
            msg(f"No se pudo verificar el Excel tras guardar: {type(e2).__name__}: {e2}", "ERROR")
            return False
    except Exception as e:
        msg(f"Error al guardar Excel: {type(e).__name__}: {e}. "
            f"Los datos de esta medida NO se volcaron al Excel, "
            f"pero el CSV/ZIP de la posicion sigue intacto.", "ERROR")

    finally:
        wb.close()
    return False


# ═══════════════════════════════════════════════════════════════
# LÓGICA DE MEDIDA POR FASE
# ═══════════════════════════════════════════════════════════════

def click_clear_gui():
    w, h = pyautogui.size()
    pyautogui.click(int(w * 0.885), int(h * 0.155))
    time.sleep(0.8)

def realizar_fase(fase, nombre_posicion, carpeta_posicion, peak_rms_anterior, api_location):
    peak_rms_actual = fase["peak_rms"]

    if peak_rms_actual != peak_rms_anterior:
        # ... (mantén aquí tu lógica de cambio manual de configuración) ...
        enter("Presiona Continuar cuando hayas cambiado el modo en MAGpy3")

    msg(f"Preparando fase: {fase['etiqueta']}...", "ESPERA")
    click_clear_gui()
    time.sleep(2) # Aumentamos tiempo de espera tras el click

    colector = ColectorDatos(api_location=api_location)

    if not iniciar_medida_con_reintentos(f"{nombre_posicion} - {fase['etiqueta']}", colector=colector):
        colector.detener()
        return False, None, None

    barra_progreso(fase["duracion_s"], fase["etiqueta"])
    fecha_fin = datetime.now()

    # FIX: primero parar la adquisición en la API, luego detener el hilo colector
    parar_medida()
    time.sleep(1)      # Dar margen a la API para procesar el stop
    colector.detener()
    time.sleep(0.5)

    # Captura de pantalla y guardado de datos
    capturar_pantalla(carpeta_posicion, fase["etiqueta"])
    guardar_datos_zip(carpeta_posicion, fase["etiqueta"], colector, api_location)

    # Calcular promedios del campo H y E sobre la ventana temporal de la fase
    promedios = promediar_medidas(colector.filas_measurement, fase["ms_ventana"],
                                   ts_inicio_ms=colector.ts_inicio_ms)
    msg(f"Promedios calculados -- H: {promedios.get('h_prom')} A/m | "
        f"E: {promedios.get('e_prom')} V/m | "
        f"Freq: {promedios.get('freq_mhz')} MHz", "OK")

    return True, promedios, fecha_fin

def distancia_base_fcc(regiones, distancia_cm, contacto):
    if len(regiones) > 1 and "ISED" in regiones and "FCC" in regiones and contacto != "no":
        return 0.0
    return distancia_cm


def regiones_en_orden(regiones):
    """ISED completo, CE y FCC; cada region conserva su propia adquisicion."""
    return [r for r in ("ISED", "CE", "FCC") if r in regiones]


def preparar_region_medida(region):
    cfg = CONFIG_REGION[region]
    while True:
        cuadro(f"CONFIGURAR MAGPY -- {region}", [
            f"Standard: {cfg['standard']}", f"Environment: {cfg['environment']}",
            f"Health effect: {cfg['health_effect']}", "Peak/RMS: RMS",
            "Se inicia una adquisicion independiente para esta region.", AVISO_TECLADO])
        enter(f"Selecciona {cfg['standard']} ({region}), {cfg['environment']}, "
              f"{cfg['health_effect']} y RMS en MAGPy. {AVISO_TECLADO} Presiona Continuar")
        if validar_configuracion_magpy(region):
            return True
        if preguntar_opcion(f"Configuracion incorrecta para {region}. Corrige MAGPy.",
                            ["REINTENTAR", "ABORTAR"]) == "ABORTAR":
            return False


def filas_resumen_regionales(nombre, regiones, distancia_cm, frecuencia_khz, prom):
    por_region = (prom or {}).get("_por_region")
    if por_region is not None:
        return [_fila_resumen(nombre, [r], (prom or {}).get("_distancias_region", {}).get(r, distancia_cm),
                              frecuencia_khz, p) for r, p in por_region.items()]
    return [_fila_resumen(nombre, regiones, distancia_cm, frecuencia_khz, prom)]


def guardar_validacion_region(carpeta, region, tipo, datos):
    """Registro independiente del resultado de cada validacion, sin modificar Excel."""
    ruta = os.path.join(carpeta, "validaciones", region)
    os.makedirs(ruta, exist_ok=True)
    archivo = os.path.join(ruta, datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + tipo + ".json")
    guardar_json_atomico(archivo, dict(region=region, validacion=tipo, **datos))
    msg(f"[{region}] Resultado de validacion guardado: {archivo}", "OK")
    return archivo


def _procesar_posicion_regiones(nombre, carpeta_raiz, regiones, distancia_cm, frecuencia_khz,
                                ruta_excel, technology, wpt_client, battery,
                                solo_rms=False, peak_fisico=False, restablecer_modo=True,
                                texto_previo=None, modo_forzado=None, frecuencia_peak_fija=False,
                                contacto_puntual=False, contacto_fcc=False):
    rms_por_region, peak_por_region = {}, {}
    distancias_rms, distancias_peak = {}, {}
    carpeta = carpeta_raiz
    d_peak = distancia_cm
    for region in regiones_en_orden(regiones):
        distancia_region = 0.0 if region == "FCC" and contacto_fcc else distancia_cm
        if not preparar_region_medida(region):
            return carpeta_raiz, None, None, distancia_cm
        while True:
            carpeta, rms, pico, d_pico_region = procesar_posicion(
                nombre, os.path.join(carpeta_raiz, region), [region], distancia_region,
                frecuencia_khz, ruta_excel, technology, wpt_client, battery,
                solo_rms=solo_rms, peak_fisico=region == "ISED" and not solo_rms,
                restablecer_modo=restablecer_modo, texto_previo=texto_previo,
                modo_forzado=modo_forzado, frecuencia_peak_fija=frecuencia_peak_fija)
            necesita_peak = region == "ISED" and not solo_rms
            if promedio_completo(rms) and (not necesita_peak or promedio_completo(pico, es_peak=True)):
                break
            if preguntar_opcion(f"{region}: posicion '{nombre}' incompleta. "
                                "Solo se repetira esta region.", ["REPETIR", "ABORTAR"]) == "ABORTAR":
                return carpeta, None, None, distancia_cm
        rms_por_region[region] = rms
        distancias_rms[region] = distancia_region
        if region == "ISED" and contacto_puntual:
            while True:
                pico = medir_peak_posicion(nombre, os.path.join(carpeta_raiz, "ISED"),
                    DIST_PICO_CONTACTO_CM, frecuencia_khz, ruta_excel, technology, wpt_client, battery)
                if promedio_completo(pico, es_peak=True):
                    d_pico_region = DIST_PICO_CONTACTO_CM
                    break
                if preguntar_opcion(f"ISED PEAK: '{nombre}' incompleto. Repetir solo el pico.",
                                    ["REPETIR", "ABORTAR"]) == "ABORTAR":
                    return carpeta, None, None, distancia_cm
        if pico is not None:
            peak_por_region[region] = pico
            distancias_peak[region] = d_pico_region
            d_peak = d_pico_region
    principal = "ISED" if "ISED" in rms_por_region else regiones_en_orden(regiones)[0]
    rms_resumen = dict(rms_por_region[principal], _por_region=rms_por_region,
                       _distancias_region=distancias_rms)
    pico_resumen = (dict(next(iter(peak_por_region.values())), _por_region=peak_por_region,
                         _distancias_region=distancias_peak)
                    if peak_por_region else None)
    return carpeta_raiz, rms_resumen, pico_resumen, d_peak


def pedir_cantidad_contacto(n):
    while True:
        cantidad = float(pedir_numero(
            "En cuantas posiciones se toca el equipo (pico ISED a 0 cm)", 1, n, n))
        if math.isfinite(cantidad) and cantidad.is_integer() and 1 <= cantidad <= n:
            return int(cantidad)
        msg(f"El numero de posiciones con contacto debe ser entero entre 1 y {n}.", "AVISO")


def pedir_nombre_posicion_unico(pedir_nombre, i, total, usados):
    while True:
        nombre = pedir_nombre(i, total)
        if nombre is None:
            return None
        if not isinstance(nombre, str):
            raise ValueError(f"Se esperaba el nombre de la posicion {i}, recibido {type(nombre).__name__}.")
        nombre = nombre.strip()
        if not nombre or nombre.casefold() in usados:
            msg("Escribe un nombre de posicion no vacio y distinto de los anteriores.", "AVISO")
            continue
        usados.add(nombre.casefold())
        return nombre


def _medidas_puntuales_regionales(regiones, distancia_cm, frecuencia_khz, carpeta_raiz,
                                  ruta_excel, technology, wpt_client, battery,
                                  pedir_nombre, n, accion_si_falla):
    # No pedir el nombre siguiente hasta haber medido la posicion actual.
    n_tocadas = pedir_cantidad_contacto(n)
    pendientes_contacto = n_tocadas
    cuadro("ORDEN POR POSICION -- CONTACTO PUNTUAL", [
        "ISED: 6 min RMS; 2 min PEAK a 0 cm solo en las posiciones elegidas.",
        "Despues, las otras regiones en adquisiciones independientes (FCC: 30 min RMS).",
        "Al terminar las posiciones: comprobacion ISED a 3 cm y validaciones FCC por separado."])
    resultados, picos = [], []
    usados = set()
    for i in range(1, n + 1):
        nombre = pedir_nombre_posicion_unico(pedir_nombre, i, n, usados)
        if nombre is None:
            return "ABORTADA", resultados, picos, n
        restantes = n - i + 1
        if pendientes_contacto == 0:
            tocada = False
        elif pendientes_contacto == restantes:
            tocada = True
        else:
            tocada = preguntar_opcion(
                f"Posicion {i}/{n}: '{nombre}'. Se toca el equipo en esta posicion?",
                ["Si", "No"]) == "Si"
        pendientes_contacto -= int(tocada)
        msg(f"POSICION {i}/{n}: '{nombre}'. Se completa antes de pedir el siguiente nombre.", "INFO")
        _, rms, pico, d_peak = procesar_posicion(nombre, carpeta_raiz, regiones, distancia_cm,
            frecuencia_khz, ruta_excel, technology, wpt_client, battery,
            solo_rms=True, contacto_puntual=tocada, contacto_fcc=True)
        if not rms:
            return "ABORTADA", resultados, picos, n
        resultados.extend(filas_resumen_regionales(nombre, regiones, distancia_cm, frecuencia_khz, rms))
        if pico:
            picos.extend(filas_resumen_regionales(nombre, ["ISED"], d_peak, frecuencia_khz, pico))
    validas = [r for r in picos if r.get("h_prom_A_m") is not None]
    if not validas:
        return "ABORTADA", resultados, picos, n
    peor = max(validas, key=lambda r: r["h_prom_A_m"])
    args = (frecuencia_khz, ruta_excel, technology, wpt_client, battery)
    return _medida_peor_posicion(peor["posicion"], peor["h_prom_A_m"], DIST_PICO_CONTACTO_CM,
        regiones, carpeta_raiz, args, accion_si_falla, resultados, picos, n)


def calcular_plan_medida(regiones):
    """Duraciones y secuencia de adquisiciones independientes por region.
    ISED (RMS y PEAK), despues CE (RMS), despues FCC (RMS).
    No se reutiliza una ventana de 30 min FCC como medida ISED/CE.
    Las duraciones nominales se conservan incluso en modo PRUEBAS.
    """
    # Ventanas de promediado por región (en ms)
    ventanas = {}
    for r in regiones:
        cfg = CONFIG_REGION[r]
        ventanas[r] = {f["peak_rms"]: f["ms_ventana"] for f in cfg["fases"]}

    # Duracion total = suma de adquisiciones RMS independientes + PEAK si lo hay
    duracion_rms_s  = sum(
        max(f["duracion_s"] for f in CONFIG_REGION[r]["fases"] if f["peak_rms"] == "RMS")
        for r in regiones
    )
    necesita_peak = any(
        any(f["peak_rms"] == "Peak" for f in CONFIG_REGION[r]["fases"])
        for r in regiones
    )
    nom = lambda tipo: sum((f["nominal_s"] for r in regiones for f in CONFIG_REGION[r]["fases"]
                            if f["peak_rms"] == tipo))
    duracion_peak_s = 0
    if necesita_peak:
        duracion_peak_s = max(
            (max((f["duracion_s"] for f in CONFIG_REGION[r]["fases"] if f["peak_rms"] == "Peak"), default=0)
             for r in regiones),
            default=0
        )

    return {
        "duracion_rms_s":  duracion_rms_s,
        "duracion_peak_s": duracion_peak_s,
        "duracion_rms_nominal_s":  nom("RMS"),
        "duracion_peak_nominal_s": nom("Peak"),
        "ventanas_nom": {r: {f["peak_rms"]: f["nominal_s"] * 1000 for f in CONFIG_REGION[r]["fases"]}
                         for r in regiones},
        "necesita_peak":   necesita_peak,
        "ventanas":        ventanas,
        "orden_regiones": regiones_en_orden(regiones),
        "secuencia": [dict(region=r, modo=f["peak_rms"], nominal_s=f["nominal_s"],
                            duracion_s=f["duracion_s"]) for r in regiones_en_orden(regiones)
                      for f in CONFIG_REGION[r]["fases"]],
    }


# ═══════════════════════════════════════════════════════════════
# PARTICULARIDAD FCC: VALIDACIÓN DE LA CAÍDA 1/d (medidas a >= 20 cm)
# ═══════════════════════════════════════════════════════════════
# Tras medir todas las posiciones (y volcarlas al Excel como siempre):
#  1. PEOR CASO ÚNICO: entre todas las posiciones y los dos campos (H y E), el de mayor
#     % del límite FCC. Las medidas adicionales se hacen en esa posición y se valida el
#     campo que dio ese % más alto.
#  2. Se pide medir alejando la sonda en pasos de 2 cm (22 cm, 24 cm si d0 = 20 cm).
#     Cada medida se hace pidiendo Continuar, igual que el resto.
#  3. CRITERIO: la intensidad debe decaer en orden de 1/d. Con 1/d0 = 0,05 a 20 cm (d0 = distancia
#     base) y un campo de referencia v_ref = 1: a 22 cm debe ser <= 0,95 y a 24 cm <= 0,90.
#     Cada medida se compara con la del PASO ANTERIOR:
#           v_n <= v_(n-1) * (1 - 1/d0)       (v_0 = v_ref, el valor a la distancia base)
#     Si el criterio real fuese otro, basta con cambiar fcc_limite_caida().
#  4. CUÁNDO PARAR: 22 cm y 24 cm se miden SIEMPRE. Si 22 cm cumple, se mide 24 cm y se termina
#     (la de 24 cm no tiene que cumplir). Si 22 cm NO cumple, 24 cm se compara con la de 22 cm; si
#     tampoco cumple, 26 cm contra la de 24 cm... hasta que una cumpla (tope: FCC_MAX_PASOS_EXTRA).
FCC_DISTANCIA_MIN_VALIDACION_CM = 20.0   # por debajo de esto no se aplica la validación
FCC_PASO_CM                     = 2.0
FCC_MIN_PASOS_EXTRA             = 2      # 22 y 24 cm (si d0 = 20 cm) se miden siempre
FCC_MAX_PASOS_EXTRA             = 8      # tope de seguridad (hasta d0 + 16 cm)
# Campos que se comparan: (clave en los promedios, etiqueta, unidad)
FCC_CAMPOS_VALIDACION = (("h_prom", "H", "A/m"), ("e_prom", "E", "V/m"))

# (posicion, distancia_cm) -> {"posicion", "distancia_cm", "valores": {...}, "freq_mhz"}.
# Lo rellena procesar_posicion con el promedio FCC (ventana de 30 min) de cada medida.
_HISTORIAL_FCC = {}


def reiniciar_historial_fcc():
    _HISTORIAL_FCC.clear()


def _registrar_promedio_fcc(nombre_posicion, distancia_cm, prom):
    if not prom:
        return
    valores = {k: (float(prom[k]) if prom.get(k) is not None else None)
               for k, _, _ in FCC_CAMPOS_VALIDACION}
    if all(v is None for v in valores.values()):
        return
    _HISTORIAL_FCC[(nombre_posicion, round(float(distancia_cm), 4))] = {
        "posicion": nombre_posicion, "distancia_cm": float(distancia_cm),
        "valores": valores, "freq_mhz": prom.get("freq_mhz")}


def fcc_limite_mpe(clave, freq_mhz):
    """Límite MPE FCC de población general (47 CFR 1.1310, Tabla 1 (B)), RMS.
    100-300 kHz: se usan los valores de 300 kHz (KDB 680106). None si no hay límite
    aplicable (< 100 kHz o > 300 MHz)."""
    if not freq_mhz or freq_mhz < 0.1 or freq_mhz > 300:
        return None
    es_e = (clave == "e_prom")
    if freq_mhz <= 1.34:
        return 614.0 if es_e else 1.63
    if freq_mhz <= 30:
        return (824.0 if es_e else 2.19) / freq_mhz
    return 27.5 if es_e else 0.073


def fcc_peor_caso(distancia_base_cm, freq_mhz_defecto=None):
    """
    Peor caso ÚNICO entre todas las posiciones medidas a la distancia base y entre H y E:
    el de mayor % del límite FCC. Devuelve dict con posicion, clave, etiqueta, unidad, valor,
    limite, pct y pcts (% de cada campo en esa posición), o None si no hay datos.
    Si no hay límite aplicable (frecuencia fuera de rango) se usa el mayor H, sin %.
    """
    cand = [e for e in _HISTORIAL_FCC.values()
            if abs(e["distancia_cm"] - float(distancia_base_cm)) < 1e-6]
    mejor = None
    for e in cand:
        f = e.get("freq_mhz") or freq_mhz_defecto
        pcts = {}
        for k, et, u in FCC_CAMPOS_VALIDACION:
            v, lim = e["valores"].get(k), fcc_limite_mpe(k, f)
            if v is not None and lim:
                pcts[et] = v / lim * 100.0
        for k, et, u in FCC_CAMPOS_VALIDACION:
            if et in pcts and (mejor is None or pcts[et] > mejor["pct"]):
                mejor = {"posicion": e["posicion"], "clave": k, "etiqueta": et, "unidad": u,
                         "valor": e["valores"][k], "limite": fcc_limite_mpe(k, f),
                         "pct": pcts[et], "pcts": dict(pcts)}
    if mejor is None:   # sin límites aplicables: mayor H (sin porcentaje)
        con_h = [e for e in cand if e["valores"].get("h_prom") is not None]
        if con_h:
            e = max(con_h, key=lambda x: x["valores"]["h_prom"])
            mejor = {"posicion": e["posicion"], "clave": "h_prom", "etiqueta": "H",
                     "unidad": "A/m", "valor": e["valores"]["h_prom"],
                     "limite": None, "pct": None, "pcts": {}}
    return mejor


def fcc_limite_caida(valor_anterior, distancia_base_cm):
    """Valor máximo permitido en un paso de 2 cm respecto al valor del paso anterior."""
    return valor_anterior * (1.0 - 1.0 / float(distancia_base_cm))


def _accion_fallo_consola(nombre):
    beep(2)
    cuadro("POSICION NO COMPLETADA",
           [f"La medida '{nombre}' no se ha completado.",
            "ENTER  --> repetir la misma medida",
            "A      --> abortar la sesion"])
    return "ABORTAR" if input("  Opcion: ").strip().upper() == "A" else "REPETIR"


def validar_caida_fcc(regiones, distancia_cm, carpeta_raiz, frecuencia, ruta_excel,
                      technology, wpt_client, battery, accion_si_falla=None):
    """
    Devuelve (estado, filas_resumen). estado: "NA" (no aplica: sin FCC o distancia < 20 cm),
    "SIN_DATOS", "OK" (caída 1/d cumplida), "NO_CUMPLE" (tope de medidas alcanzado) o
    "ABORTADA". accion_si_falla(nombre) -> "REPETIR" | "ABORTAR" si una medida no arranca.
    """
    if "FCC" not in regiones or distancia_cm < FCC_DISTANCIA_MIN_VALIDACION_CM:
        return "NA", []
    if len(regiones) > 1:
        carpeta_raiz = os.path.join(carpeta_raiz, "FCC")
        if not preparar_region_medida("FCC"):
            return "ABORTADA", []
    accion_si_falla = accion_si_falla or _accion_fallo_consola

    peor = fcc_peor_caso(distancia_cm, (frecuencia or 0) / 1000.0)
    if peor is None or not peor["valor"]:
        msg("FCC 1/d: no hay promedios FCC validos (o el campo de referencia es 0) para "
            "determinar el peor caso. No se puede validar la caida 1/d.", "AVISO")
        return "SIN_DATOS", []

    nombre_ref, et, u, v_ref = peor["posicion"], peor["etiqueta"], peor["unidad"], peor["valor"]
    d1 = distancia_cm + FCC_PASO_CM
    factor = 1.0 - 1.0 / float(distancia_cm)
    if peor["pct"] is not None:
        l_peor = [f"Peor caso: posicion '{nombre_ref}', campo {et}",
                  f"   {et} = {v_ref:.4f} {u} = {peor['pct']:.2f} % del limite FCC ({peor['limite']:.4g} {u})",
                  "   En esa posicion: " + " | ".join(f"{k} = {v:.2f} %" for k, v in peor["pcts"].items())]
    else:
        l_peor = [f"Peor caso: posicion '{nombre_ref}', campo {et} = {v_ref:.4f} {u}",
                  "   (sin limite FCC aplicable a esta frecuencia: se usa el mayor H)"]
    beep(2)
    cuadro("FCC -- VALIDACION DE LA CAIDA 1/d",
           l_peor + ["",
                     f"Se mide en esa posicion a {d1:g} cm y a {distancia_cm + FCC_PASO_CM * FCC_MIN_PASOS_EXTRA:g} cm (siempre).",
                     f"La de {d1:g} cm se comprueba respecto a {distancia_cm:g} cm.",
                     f"Limite a {d1:g} cm: {et} <= {fcc_limite_caida(v_ref, distancia_cm):.4f} {u} "
                     f"({factor:.2f} x {v_ref:.4f}).",
                     "Si la de 22 cm no cumple, cada medida (+2 cm) se compara con el paso anterior,",
                     "y asi hasta que se cumpla."])
    enter(f"Presiona Continuar para pasar a las medidas adicionales del peor caso "
          f"('{nombre_ref}', {d1:g} cm)")

    filas, resumen = [], []
    cumple = cumple_1 = False
    v_prev = v_ref          # valor del paso anterior (al principio, la medida a la distancia base)
    for n in range(1, FCC_MAX_PASOS_EXTRA + 1):
        d = distancia_cm + FCC_PASO_CM * n
        d_prev = d - FCC_PASO_CM
        nombre = f"{nombre_ref}_{d:g}cm"
        while True:
            # procesar_posicion pide Continuar antes de medir, igual que el resto de medidas
            _, prom, _, _ = procesar_posicion(nombre, carpeta_raiz, ["FCC"], d, frecuencia,
                                               ruta_excel, technology, wpt_client, battery)
            if prom:
                break
            if accion_si_falla(nombre) == "ABORTAR":
                return "ABORTADA", filas

        valor  = prom.get(peor["clave"])
        limite = fcc_limite_caida(v_prev, distancia_cm)
        cumple = valor is not None and valor <= limite
        if n == 1:
            cumple_1 = cumple
        filas.append({
            "posicion": nombre, "regiones": "FCC", "distancia_cm": d,
            "frecuencia_khz": frecuencia, "freq_mhz": prom.get("freq_mhz"),
            "h_prom_A_m": prom.get("h_prom"), "e_prom_V_m": prom.get("e_prom"),
        })
        txt = f"{valor:.4f}" if valor is not None else "sin dato"
        resumen.append(f"{d:g} cm: {et} {txt} {u} (limite <= {limite:.4f} = {factor:.2f} x {v_prev:.4f} "
                       f"a {d_prev:g} cm)  " + ("CUMPLE" if cumple else "NO CUMPLE"))
        msg(f"FCC 1/d: {resumen[-1]}", "OK" if cumple else "AVISO")

        if (n >= FCC_MIN_PASOS_EXTRA and (cumple_1 or cumple)) or n >= FCC_MAX_PASOS_EXTRA:
            break
        if valor is not None:
            v_prev = valor      # la siguiente medida se compara con esta
        d_sig = d + FCC_PASO_CM
        if cumple:
            sig = [f"{d:g} cm cumple la caida 1/d.",
                   f"Falta la medida a {d_sig:g} cm (se hace siempre); despues se termina."]
        else:
            sig = [f"{d:g} cm NO cumple la caida 1/d.",
                   f"Se mide {d_sig:g} cm y se compara con la medida de {d:g} cm: "
                   f"{et} <= {fcc_limite_caida(v_prev, distancia_cm):.4f} {u}."]
        cuadro(f"FCC -- SIGUIENTE MEDIDA: {d_sig:g} cm en '{nombre_ref}'", resumen[-1:] + [""] + sig)

    if cumple_1 or cumple:
        extra = ([f"({distancia_cm + FCC_MIN_PASOS_EXTRA * FCC_PASO_CM:g} cm es la medida adicional "
                  "obligatoria: no tiene que cumplir.)"] if cumple_1 and not cumple else [])
        cuadro("FCC -- CAIDA 1/d CORRECTA",
               [f"Posicion de referencia: '{nombre_ref}' ({et} = {v_ref:.4f} {u} a {distancia_cm:g} cm)", ""]
               + resumen + extra + ["", "Todo correcto: ya puedes dejar de hacer mediciones."])
        guardar_validacion_region(carpeta_raiz, "FCC", "Caida_1d", {
            "estado": "OK", "posicion": nombre_ref, "distancia_base_cm": distancia_cm,
            "resultados": resumen, "medidas": filas})
        return "OK", filas

    beep(3)
    cuadro("FCC -- CAIDA 1/d NO CUMPLIDA",
           resumen + ["", f"Se alcanzo el tope de {FCC_MAX_PASOS_EXTRA} medidas adicionales sin cumplir 1/d.",
                      "Revisa la medida y el montaje antes de continuar."])
    guardar_validacion_region(carpeta_raiz, "FCC", "Caida_1d", {
        "estado": "NO_CUMPLE", "posicion": nombre_ref, "distancia_base_cm": distancia_cm,
        "resultados": resumen, "medidas": filas})
    return "NO_CUMPLE", filas


# ═══════════════════════════════════════════════════════════════
# PARTICULARIDAD FCC: VALIDACIÓN A 0 cm (ESTIMATED vs MEASURED)
# ═══════════════════════════════════════════════════════════════
# Se aplica cuando FCC está seleccionada y las medidas son a 0 cm (distancia escrita = 0), ya sean
# puntuales o durante un tiempo. Se hace sobre el PEOR CASO (la posicion con mayor campo H entre
# las medidas a 0 cm):
#   - A 2 cm: "Estimated" = sonda a 2 cm de la PUNTA del sensor con Tip Max;
#             "Measured"  = sonda a 2 cm de la RAYA NEGRA con Probe Center.
#   - A 4 cm: lo mismo.
#   - La diferencia entre Estimated y Measured (campo H) debe ser < 30 % a 2 cm y a 4 cm.
#     Diferencia = |Estimated - Measured| / Measured * 100.
FCC_CERO_CM_MAX            = 0.1            # distancia <= esto se considera "0 cm"
FCC_DISTANCIAS_EST_MEAS_CM = (2.0, 4.0)
FCC_DIF_MAX_PCT            = 30.0


def fcc_aplica_validacion_cero(regiones, distancia_cm):
    return "FCC" in regiones and distancia_cm is not None and float(distancia_cm) < FCC_CERO_CM_MAX


def diferencia_estimada_medida_pct(h_estimated, h_measured):
    """|Estimated - Measured| / Measured * 100, o None si no se puede calcular."""
    try:
        est, med = float(h_estimated), float(h_measured)
        if not (math.isfinite(est) and math.isfinite(med)) or med == 0:
            return None
        return abs(est - med) / abs(med) * 100.0
    except (TypeError, ValueError):
        return None


def peor_posicion_h(resultados, distancia_cm, region="FCC"):
    """Fila (dict) de la posicion con mayor H entre las medidas a esa distancia, o None."""
    cand = [r for r in resultados
            if r.get("posicion") != NOMBRE_RUIDO
            and r.get("distancia_cm") is not None
            and abs(float(r["distancia_cm"]) - float(distancia_cm)) < 1e-6
            and region in str(r.get("regiones", "")).split("+")
            and r.get("h_prom_A_m") is not None]
    return max(cand, key=lambda r: float(r["h_prom_A_m"])) if cand else None


def validar_estimado_medido_fcc(resultados, regiones, distancia_cm, carpeta_raiz, frecuencia,
                                ruta_excel, technology, wpt_client, battery, accion_si_falla=None):
    """Devuelve (estado, filas_resumen). estado: "NA", "SIN_DATOS", "OK", "NO_CUMPLE", "ABORTADA"."""
    if not fcc_aplica_validacion_cero(regiones, distancia_cm):
        return "NA", []
    if len(regiones) > 1:
        carpeta_raiz = os.path.join(carpeta_raiz, "FCC")
        if not preparar_region_medida("FCC"):
            return "ABORTADA", []
    accion_si_falla = accion_si_falla or _accion_fallo_consola
    peor_fila = peor_posicion_h(resultados, distancia_cm)
    if peor_fila is None:
        msg("FCC 0 cm: no hay valores de H validos para elegir la peor posicion.", "AVISO")
        return "SIN_DATOS", []
    peor, h_peor = peor_fila["posicion"], float(peor_fila["h_prom_A_m"])
    d_txt = " y ".join(f"{d:g} cm" for d in FCC_DISTANCIAS_EST_MEAS_CM)

    linea = f"PEOR POSICION FCC: '{peor}'  (H = {h_peor:.4f} A/m a {distancia_cm:g} cm)"
    msg(linea, "OK")
    cuadro("FCC -- VALIDACION A 0 cm: ESTIMATED vs MEASURED",
           [linea, "",
            f"En esa posicion se hacen medidas a {d_txt}:",
            "  Estimated: sonda a esa distancia de la PUNTA del sensor, modo Tip Max.",
            "  Measured:  sonda a esa distancia de la RAYA NEGRA, modo Probe Center.",
            f"La diferencia entre Estimated y Measured (campo H) debe ser < {FCC_DIF_MAX_PCT:g} %."])
    enter(f"{linea}. A continuacion se hacen las medidas Estimated y Measured a {d_txt} en esa posicion "
          f"(4 medidas). La diferencia entre Estimated y Measured debe ser menor del {FCC_DIF_MAX_PCT:g} %. "
          "Presiona Continuar")

    filas, lineas_res, todas_ok = [], [], True
    for d in FCC_DISTANCIAS_EST_MEAS_CM:
        h_por_tipo = {}
        for tipo, modo, instruccion in (
                ("Estimated", ("Tip Max", "tip-max"),
                 f"Coloca la sonda a {d:g} cm de la PUNTA del sensor"),
                ("Measured", ("Probe Center", "probe-center"),
                 f"Coloca la sonda a {d:g} cm de la RAYA NEGRA de la sonda")):
            nombre = f"{peor}_{d:g}cm_{tipo}"
            while True:
                _, prom, _, _ = procesar_posicion(
                    nombre, carpeta_raiz, ["FCC"], d, frecuencia, ruta_excel, technology, wpt_client,
                    battery, modo_forzado=modo, texto_previo=f"{tipo} a {d:g} cm. {instruccion}")
                if prom:
                    break
                if accion_si_falla(nombre) == "ABORTAR":
                    return "ABORTADA", filas
            h_por_tipo[tipo] = prom.get("h_prom")
            filas.append({
                "posicion": nombre, "regiones": "FCC", "distancia_cm": d,
                "frecuencia_khz": frecuencia, "freq_mhz": prom.get("freq_mhz"),
                "h_prom_A_m": prom.get("h_prom"), "e_prom_V_m": prom.get("e_prom"),
            })
        dif = diferencia_estimada_medida_pct(h_por_tipo.get("Estimated"), h_por_tipo.get("Measured"))
        valida = dif is not None and dif < FCC_DIF_MAX_PCT
        todas_ok = todas_ok and valida
        if dif is None:
            txt = f"{d:g} cm: no se pudo calcular la diferencia (sin datos)  NO VALIDA"
        else:
            txt = (f"{d:g} cm: Estimated H = {float(h_por_tipo['Estimated']):.4f} A/m | "
                   f"Measured H = {float(h_por_tipo['Measured']):.4f} A/m | diferencia = {dif:.1f} % "
                   f"({'<' if valida else '>='} {FCC_DIF_MAX_PCT:g} %)  " + ("VALIDA" if valida else "NO VALIDA"))
        lineas_res.append(txt)
        msg(f"FCC 0 cm: {txt}", "OK" if valida else "AVISO")

    resultado = "VALIDACION CORRECTA" if todas_ok else "VALIDACION NO CORRECTA"
    cuadro("FCC -- ESTIMATED vs MEASURED", [f"Posicion '{peor}'", ""] + lineas_res + ["", resultado])
    enter(f"FCC '{peor}': " + " || ".join(lineas_res) + f"  -->  {resultado}. Presiona Continuar")
    guardar_validacion_region(carpeta_raiz, "FCC", "Estimated_Measured", {
        "posicion": peor, "estado": "OK" if todas_ok else "NO_CUMPLE",
        "resultados": lineas_res, "medidas": filas})
    return ("OK" if todas_ok else "NO_CUMPLE"), filas


# ═══════════════════════════════════════════════════════════════
# MEDIDA DE RUIDO AMBIENTE (obligatoria antes de medir posiciones)
# ═══════════════════════════════════════════════════════════════
# Medida real (misma duracion/ventana que el RMS de cada region) sin pedir posicion
# ni distancia. Se guarda como una posicion mas, con el nombre "Ruido": carpeta
# <raiz>/Ruido (captura + ZIP) y una fila en el Excel de cada region. La sesion NO
# pasa a las posiciones hasta que esta medida se complete (o se aborte la sesion).

NOMBRE_RUIDO = "Ruido"
RUIDO_API_LOCATION = None   # None: se mide en el punto que este seleccionado en MAGpy3


def medir_ruido_ambiente(carpeta_raiz, regiones, frecuencia_khz, ruta_excel,
                         technology, wpt_client, battery):
    """Devuelve (estado, filas_resumen). estado: "OK" o "ABORTADA".
    La duracion la elige el usuario; el punto de referencia es el que este seleccionado en MAGpy3."""
    carpeta = os.path.join(carpeta_raiz, NOMBRE_RUIDO)
    os.makedirs(carpeta, exist_ok=True)

    sep("MEDIDA DE RUIDO AMBIENTE")
    beep(2)
    cuadro("MEDIDA DE RUIDO AMBIENTE",
           ["Antes de comenzar la medicion hay que hacer una medida de ruido ambiente.",
            "No se pasara a las posiciones hasta completarla.",
            "",
            "Para medir el ruido ambiente, el punto de referencia de la sonda",
            "tiene que ser PROBE CENTER (seleccionalo en MAGpy3)."])
    minutos    = pedir_valor("Duracion de la medida de ruido ambiente (minutos)", 0.1, 240.0)
    duracion_s = max(1, int(round(minutos * 60)))
    etiqueta   = f"{minutos:g} min {NOMBRE_RUIDO}"
    enter("Para medir el ruido ambiente, el punto de referencia de la sonda tiene que ser "
          "PROBE CENTER (seleccionalo en MAGpy3). " + AVISO_TECLADO + " Presiona Continuar para INICIAR la medida de RUIDO AMBIENTE")

    colector = ColectorDatos(api_location=RUIDO_API_LOCATION)
    if not iniciar_medida_con_reintentos(f"{NOMBRE_RUIDO} - RMS", colector=colector):
        colector.detener()
        return "ABORTADA", []

    barra_progreso(duracion_s, etiqueta)
    fecha_fin = datetime.now()
    parar_medida()
    time.sleep(1)
    colector.detener()
    time.sleep(0.5)

    capturar_pantalla(carpeta, etiqueta)
    guardar_datos_zip(carpeta, etiqueta, colector, RUIDO_API_LOCATION)

    prom = promediar_medidas(colector.filas_measurement, duracion_s * 1000,
                             ts_inicio_ms=colector.ts_inicio_ms)
    msg(f"Ruido -- H: {prom.get('h_prom')} A/m | E: {prom.get('e_prom')} V/m", "OK")

    beep(3)
    msg(f"Posicion '{NOMBRE_RUIDO}' completada. Ya se puede empezar a medir posiciones.", "OK")
    return "OK", [{
        "posicion": NOMBRE_RUIDO, "regiones": "+".join(regiones), "distancia_cm": None,
        "frecuencia_khz": frecuencia_khz, "freq_mhz": prom.get("freq_mhz"),
        "h_prom_A_m": prom.get("h_prom"), "e_prom_V_m": prom.get("e_prom"),
    }]


# ═══════════════════════════════════════════════════════════════
# ISED: CASO "EL USUARIO TOCA EL EQUIPO"
# ═══════════════════════════════════════════════════════════════
#  Las medidas a 0 cm pueden ser PUNTUALES o DURANTE UN PERIODO DE TIEMPO:
#
#  PUNTUAL:
#    1. N posiciones en RMS (6 min) a la distancia indicada (la del formulario).
#    2. Se pregunta en cuales se toca; cambio a Peak y pico (2 min) a 0 cm con Tip Max
#       SOLO en esas posiciones (hay que reposicionar la sonda).
#    3. Peor posicion (mayor H de pico): a 3 cm en RMS y Peak y validacion E/H (igual que abajo).
#
#  DURANTE UN PERIODO DE TIEMPO:
#    1. Cada posicion a 0 cm: RMS (6 min) y a continuacion Peak (2 min), igual que sin contacto.
#    2. Peor posicion = mayor campo H (se tiene en cuenta el pico).
#    3. Esa posicion a 3 cm en RMS (6 min) y Peak (2 min). Con el pico,
#       E/H < 37,7 -> valida.

EH_LIMITE_OHM          = 37.7
DIST_PICO_CONTACTO_CM  = 0.0    # medida de pico con el equipo tocado (Tip Max)
DIST_COMPROBACION_CM   = 3.0    # medida en la peor posicion


def preguntar_opcion(texto, opciones):
    """Pregunta de opcion unica por consola. Devuelve una de 'opciones' tal cual."""
    while True:
        r = input(f"  {texto} ({'/'.join(opciones)}): ").strip().lower()
        for o in opciones:
            if r == o.lower():
                return o
        por_inicial = [o for o in opciones if r and r == o[0].lower()]
        if len(por_inicial) == 1:      # la inicial solo vale si no hay ambiguedad
            return por_inicial[0]
        print("  X Responde con una de las opciones indicadas.")


def comprobar_eh(e_prom, h_prom):
    """Devuelve (E/H en ohm o None, valida True/False/None). Valida si E/H < 37,7."""
    try:
        if e_prom is None or h_prom is None or float(h_prom) == 0:
            return None, None
        ratio = float(e_prom) / float(h_prom)
    except (TypeError, ValueError):
        return None, None
    return ratio, ratio < EH_LIMITE_OHM


def _fila_resumen(nombre, regiones, distancia_cm, frecuencia_khz, prom):
    return {
        "posicion": nombre, "regiones": "+".join(regiones), "distancia_cm": distancia_cm,
        "frecuencia_khz": frecuencia_khz, "freq_mhz": prom.get("freq_mhz"),
        "h_prom_A_m": prom.get("h_prom"), "e_prom_V_m": prom.get("e_prom"),
    }


def medir_peak_posicion(nombre_posicion, carpeta_raiz, distancia_cm, frecuencia_khz,
                        ruta_excel, technology, wpt_client, battery):
    """Medida de pico (ISED, 2 min) en una posicion ya medida en RMS. Se guarda en la misma
    carpeta de la posicion y en la tabla Peak del Excel de ISED. Devuelve prom_peak o None."""
    carpeta = os.path.join(carpeta_raiz, nombre_posicion.replace(" ", "_").replace("/", "-"))
    os.makedirs(carpeta, exist_ok=True)
    modo_magpy, api_location = modo_por_distancia(distancia_cm)
    plan = calcular_plan_medida(["ISED"])
    duracion_s = plan["duracion_peak_s"]
    ms_ventana = plan["ventanas"]["ISED"]["Peak"]
    etiqueta   = f"{plan['duracion_peak_nominal_s']//60} min Peak"

    sep(f"PICO: {nombre_posicion}")
    cuadro(f"ACCION REQUERIDA -- PICO en {nombre_posicion}",
           [f"Coloca el dispositivo en la posicion: {nombre_posicion}",
            f"REPOSICIONA la sonda a {distancia_cm:g} cm",
            f"Selecciona en MAGpy3: {modo_magpy} (location '{api_location}')",
            f"Duracion Peak: {plan['duracion_peak_nominal_s']//60} min"])
    enter(f"Reposiciona la sonda a {distancia_cm:g} cm en '{nombre_posicion}' y selecciona {modo_magpy} "
          "en MAGpy3. " + AVISO_TECLADO + " Presiona Continuar para INICIAR la medida de PICO")

    click_clear_gui()
    time.sleep(2)
    colector = ColectorDatos(api_location=api_location)
    if not iniciar_medida_con_reintentos(f"{nombre_posicion} - Peak", colector=colector):
        colector.detener()
        return None
    barra_progreso(duracion_s, f"[ISED] {nombre_posicion} - {etiqueta}")
    fecha_fin = datetime.now()
    parar_medida()
    time.sleep(1)
    colector.detener()
    time.sleep(0.5)
    capturar_pantalla(carpeta, etiqueta)
    guardar_datos_zip(carpeta, etiqueta, colector, api_location)

    # La API siempre devuelve RMS: el pico reportable es RMS x sqrt(2) (igual que en procesar_posicion)
    prom_rms = promediar_medidas(colector.filas_measurement, ms_ventana,
                                 ts_inicio_ms=colector.ts_inicio_ms)
    if prom_rms.get("multi_frecuencia"):
        msg(f"[ISED] Peak '{nombre_posicion}': se detectaron varias frecuencias en la ventana; "
            "se guardan igualmente los valores calculados por MAGpy.", "AVISO")
    prom = calcular_peak_desde_rms(prom_rms, ignorar_multifrecuencia=True)
    if not promedio_completo(prom, es_peak=True):
        msg(f"PEAK '{nombre_posicion}' sin E/H validos: {prom}. Repetir o abortar; ZIP conservado.", "ERROR")
        return None
    msg(f"[ISED] Peak ({nombre_posicion}, {distancia_cm:g} cm) -- "
        f"H: {prom.get('h_prom')} A/m | E: {prom.get('e_prom')} V/m", "OK")
    actualizar_excel(ruta_excel, "ISED", nombre_posicion, {"Peak": distancia_cm},
                     {"Peak": prom}, technology, wpt_client, battery,
                     {"Peak": fecha_fin}, frecuencia_khz, avisar_sin_datos=False)
    return prom


def _medir_posiciones_con_reintento(nombres_a_medir, carpeta_raiz, regiones, distancia_cm,
                                    frecuencia_khz, ruta_excel, technology, wpt_client, battery,
                                    accion_si_falla, pedir_nombre=None, **kw_procesar):
    """Mide cada posicion con procesar_posicion repitiendo si falla.
    nombres_a_medir: lista de nombres, o un entero N si se pasa pedir_nombre(i, N), que pregunta
    el nombre de cada posicion justo antes de medirla (None = abortar).
    Devuelve (estado, lista de (nombre, prom_rms, prom_peak))."""
    medidas = []
    usados = set()
    n_total = nombres_a_medir if isinstance(nombres_a_medir, int) else len(nombres_a_medir)
    for i in range(1, n_total + 1):
        if pedir_nombre is not None:
            nombre = pedir_nombre_posicion_unico(pedir_nombre, i, n_total, usados)
            if nombre is None:
                return "ABORTADA", medidas
        else:
            nombre = nombres_a_medir[i - 1]
        while True:
            _, prom_rms, prom_peak, _ = procesar_posicion(
                nombre, carpeta_raiz, regiones, distancia_cm, frecuencia_khz, ruta_excel,
                technology, wpt_client, battery, **kw_procesar)
            if promedio_completo(prom_rms) and (not kw_procesar.get("peak_fisico") or promedio_completo(prom_peak, es_peak=True)):
                medidas.append((nombre, prom_rms, prom_peak))
                break
            if accion_si_falla(nombre) == "ABORTAR":
                return "ABORTADA", medidas
    return "OK", medidas


def medidas_con_contacto(regiones, distancia_cm, frecuencia_khz, carpeta_raiz, ruta_excel,
                         technology, wpt_client, battery, pedir_nombre, n_posiciones,
                         periodo, accion_si_falla=None):
    """Flujo ISED cuando el usuario toca el equipo (ver cabecera de la seccion).
    periodo: True = contacto durante un periodo de tiempo (medidas a 0 cm RMS+Peak y 3 cm);
             False = contacto puntual. Ya viene decidido desde la configuracion.
    pedir_nombre(i, total) -> nombre o None (None = abortar).
    accion_si_falla(nombre) -> "REPETIR" | "ABORTAR".
    Devuelve (estado, resultados, resultados_peak, n_posiciones). estado: "OK" o "ABORTADA"."""
    accion_si_falla = accion_si_falla or _accion_fallo_consola
    resultados, resultados_peak = [], []
    args = (frecuencia_khz, ruta_excel, technology, wpt_client, battery)
    n = int(n_posiciones)
    if len(regiones) > 1 and not periodo:
        return _medidas_puntuales_regionales(regiones, distancia_cm, frecuencia_khz,
            carpeta_raiz, ruta_excel, technology, wpt_client, battery,
            pedir_nombre, n, accion_si_falla)

    # ───────────────────────── DURANTE UN PERIODO DE TIEMPO ─────────────────────────
    if periodo:
        dist0 = DIST_PICO_CONTACTO_CM
        cuadro("CONTACTO DURANTE UN PERIODO DE TIEMPO: ORDEN DE LAS MEDIDAS",
               [f"1) Cada posicion se mide a {dist0:g} cm: primero RMS y luego PEAK (como sin contacto).",
                "2) Se elige la peor posicion (mayor campo H, teniendo en cuenta el pico).",
                f"3) Esa posicion se mide a {DIST_COMPROBACION_CM:g} cm en RMS y PEAK y se valida E/H."])
        enter(f"Contacto durante un periodo: cada posicion se mide a {dist0:g} cm en RMS y despues en "
              f"PEAK; al final se mide la peor a {DIST_COMPROBACION_CM:g} cm. Presiona Continuar")
        estado, medidas = _medir_posiciones_con_reintento(
            n, carpeta_raiz, regiones, dist0, *args, accion_si_falla,
            pedir_nombre=pedir_nombre, peak_fisico=True)
        for nombre, prom_rms, prom_peak in medidas:
            resultados.extend(filas_resumen_regionales(nombre, regiones, dist0, frecuencia_khz, prom_rms))
            if prom_peak:
                resultados_peak.extend(filas_resumen_regionales(nombre, ["ISED"], dist0, frecuencia_khz, prom_peak))
        if estado == "ABORTADA":
            return "ABORTADA", resultados, resultados_peak, n

        if len(medidas) != n:
            msg(f"Solo se completaron {len(medidas)} de {n} posiciones. No se pasa a 3 cm.", "ERROR")
            return "ABORTADA", resultados, resultados_peak, n
        msg(f"Completadas las {n} posiciones en RMS y PEAK. Ahora se selecciona la peor.", "OK")

        # Peor posicion: mayor H teniendo en cuenta el valor de pico (si no hay pico, el RMS)
        def _h(m):
            _, rms, pico = m
            h = (pico or {}).get("h_prom")
            return h if h is not None else rms.get("h_prom")
        validas = [m for m in medidas if _h(m) is not None]
        if not validas:
            msg("No hay ningun valor de H valido: no se puede elegir la peor posicion.", "AVISO")
            return "ABORTADA", resultados, resultados_peak, n
        peor_m = max(validas, key=_h)
        peor, h_peor = peor_m[0], _h(peor_m)
        return _medida_peor_posicion(peor, h_peor, dist0, regiones, carpeta_raiz, args,
                                     accion_si_falla, resultados, resultados_peak, n)

    # ─────────────────────────────────── PUNTUAL ───────────────────────────────────
    cuadro("CONTACTO PUNTUAL: ORDEN DE LAS MEDIDAS",
           [f"1) Primero se miden todas las posiciones en RMS a {distancia_cm:g} cm.",
            "2) Despues se cambia a modo PEAK.",
            "3) Se te preguntara en que posiciones se toca el equipo: solo en esas",
            f"   se mide el pico a {DIST_PICO_CONTACTO_CM:g} cm (hay que reposicionar la sonda).",
            f"4) La peor posicion (mayor H de pico) se mide a {DIST_COMPROBACION_CM:g} cm en RMS y PEAK y se valida E/H."])
    enter("Contacto puntual: primero se miden todas las posiciones en RMS; despues se cambia a modo "
          "PEAK y solo se mide a 0 cm en las posiciones que se toquen (se preguntara cuales). "
          f"Al final, la peor posicion se mide a {DIST_COMPROBACION_CM:g} cm en RMS y PEAK. "
          "Presiona Continuar")
    estado, medidas = _medir_posiciones_con_reintento(
        n, carpeta_raiz, regiones, distancia_cm, *args, accion_si_falla,
        pedir_nombre=pedir_nombre, solo_rms=True)
    nombres = [m[0] for m in medidas]
    for nombre, prom_rms, _ in medidas:
        resultados.extend(filas_resumen_regionales(nombre, regiones, distancia_cm, frecuencia_khz, prom_rms))
    if estado == "ABORTADA":
        return "ABORTADA", resultados, resultados_peak, n

    # Posiciones que se tocan
    n_tocadas = pedir_cantidad_contacto(n)
    if n_tocadas < n:
        restantes, elegidas = list(nombres), []
        for k in range(1, n_tocadas + 1):
            elegida = preguntar_opcion(f"Posicion tocada {k} de {n_tocadas}", restantes)
            elegidas.append(elegida)
            restantes.remove(elegida)
        nombres = [x for x in nombres if x in elegidas]

    cuadro("CAMBIAR A MODO PEAK",
           ["Pon Peak/RMS = Peak en MAGpy3 --> Configure --> Settings",
            f"Ahora se mide el PICO de las posiciones que se tocan a {DIST_PICO_CONTACTO_CM:g} cm con Tip Max.",
            "Hay que cambiar la posicion de la sonda en cada medida."])
    enter("Cambia el modo de RMS a Peak en MAGpy3. En cada posicion tocada tendras que "
          "REPOSICIONAR la sonda a 0 cm. Presiona Continuar")
    picos = {}
    for nombre in nombres:
        while True:
            prom = medir_peak_posicion(nombre, carpeta_raiz, DIST_PICO_CONTACTO_CM, *args)
            if prom:
                picos[nombre] = prom
                resultados_peak.extend(filas_resumen_regionales(nombre, ["ISED"], DIST_PICO_CONTACTO_CM,
                                                     frecuencia_khz, prom))
                break
            if accion_si_falla(f"{nombre} (pico)") == "ABORTAR":
                return "ABORTADA", resultados, resultados_peak, n
    cuadro("RESTABLECER MODO", ["Vuelve a poner Peak/RMS = RMS en MAGpy3 --> Configure settings"])
    enter("Presiona Continuar cuando hayas vuelto a RMS")

    # Medidas a 0 cm: peor posicion (mayor H de pico) a 3 cm en RMS y Peak + validacion E/H
    con_h = {k: v.get("h_prom") for k, v in picos.items() if v.get("h_prom") is not None}
    if not con_h:
        msg("No hay ningun valor de H de pico valido: no se puede elegir la peor posicion.", "AVISO")
        return "ABORTADA", resultados, resultados_peak, n
    peor = max(con_h, key=con_h.get)
    return _medida_peor_posicion(peor, con_h[peor], DIST_PICO_CONTACTO_CM, regiones, carpeta_raiz, args,
                                 accion_si_falla, resultados, resultados_peak, n, n_msg=len(picos))


def _medida_peor_posicion(peor, h_peor, dist_origen_cm, regiones, carpeta_raiz, args,
                          accion_si_falla, resultados, resultados_peak, n, n_msg=None):
    """Contacto (puntual o periodo): peor posicion a 3 cm en RMS y Peak + validacion E/H."""
    if len(regiones) > 1:
        carpeta_raiz = os.path.join(carpeta_raiz, "ISED")
        if not preparar_region_medida("ISED"):
            return "ABORTADA", resultados, resultados_peak, n
    frecuencia_khz = args[0]
    linea_peor = f"PEOR POSICION: '{peor}'  (H = {h_peor:.4f} A/m a {dist_origen_cm:g} cm)"
    msg(linea_peor, "OK")
    cuadro("PEOR POSICION (campo H)",
           [linea_peor, "",
            f"Ahora hay que medir '{peor}' a {DIST_COMPROBACION_CM:g} cm en RMS (6 min) y Peak (2 min)."])
    enter(f"Se han completado las {n_msg if n_msg is not None else n} posiciones seleccionadas. "
          f"A continuación se realizará una medida adicional a {DIST_COMPROBACION_CM:g} cm "
          f"en modo RMS y después en modo PEAK, sobre la peor posición detectada: '{peor}' "
          f"(H = {h_peor:.4f} A/m). Después se realizará la validación E/H. "
          "Reposiciona la sonda, comprueba que MAGPy está en RMS y pulsa Continuar.")
    nombre3 = f"{peor} {DIST_COMPROBACION_CM:g}cm"
    estado, medidas = _medir_posiciones_con_reintento(
        [nombre3], carpeta_raiz, ["ISED"], DIST_COMPROBACION_CM, *args,
        accion_si_falla, peak_fisico=True, restablecer_modo=False,
        frecuencia_peak_fija=True,
        texto_previo=f"{linea_peor}. Reposiciona la sonda a {DIST_COMPROBACION_CM:g} cm")
    if estado == "ABORTADA":
        return "ABORTADA", resultados, resultados_peak, n
    _, prom_rms, prom_peak = medidas[0]
    resultados.extend(filas_resumen_regionales(nombre3, ["ISED"], DIST_COMPROBACION_CM, frecuencia_khz, prom_rms))
    if prom_peak:
        resultados_peak.extend(filas_resumen_regionales(nombre3, ["ISED"], DIST_COMPROBACION_CM,
                                             frecuencia_khz, prom_peak))

    # E/H con el valor de pico. Si el pico no se pudo calcular se usa el RMS: el cociente es el
    # mismo porque ambos se escalan por sqrt(2).
    base = prom_peak if (prom_peak and prom_peak.get("h_prom") is not None) else prom_rms
    ratio, valida = comprobar_eh(base.get("e_prom"), base.get("h_prom"))
    if ratio is None:
        resultado = "NO SE PUDO CALCULAR E/H (sin datos)"
    elif valida:
        resultado = f"E/H = {ratio:.2f} < {EH_LIMITE_OHM}  -->  MEDIDA VALIDA"
    else:
        resultado = f"E/H = {ratio:.2f} > {EH_LIMITE_OHM}  -->  MEDIDA NO VALIDA"
    guardar_validacion_region(carpeta_raiz, "ISED", "E_H_3cm", {
        "posicion": nombre3, "distancia_cm": DIST_COMPROBACION_CM,
        "e_prom": base.get("e_prom"), "h_prom": base.get("h_prom"),
        "ratio_ohm": ratio, "limite_ohm": EH_LIMITE_OHM,
        "estado": "SIN_DATOS" if ratio is None else ("OK" if valida else "NO_CUMPLE")})
    msg(f"{nombre3}: {resultado}", "OK" if valida else "AVISO")
    cuadro("COMPROBACION E/H", [f"Posicion '{nombre3}'", resultado])
    enter(f"{nombre3}: {resultado}. Presiona Continuar")
    return "OK", resultados, resultados_peak, n


def procesar_posicion(nombre_posicion, carpeta_raiz, regiones,
                      distancia_cm, frecuencia_khz, ruta_excel,
                      technology, wpt_client, battery,
                      solo_rms=False, peak_fisico=False,
                      restablecer_modo=True, texto_previo=None, modo_forzado=None,
                      frecuencia_peak_fija=False, contacto_puntual=False, contacto_fcc=False):
    """solo_rms: no hace la fase Peak (se mide aparte).
    peak_fisico: la fase Peak se mide fisicamente (modo Peak, 2 min) a la misma distancia,
    sin preguntar la distancia Peak ni calcularla desde el RMS."""
    if len(regiones) > 1:
        return _procesar_posicion_regiones(nombre_posicion, carpeta_raiz, regiones,
            distancia_cm, frecuencia_khz, ruta_excel, technology, wpt_client, battery,
            solo_rms, peak_fisico, restablecer_modo, texto_previo, modo_forzado,
            frecuencia_peak_fija, contacto_puntual, contacto_fcc)
    nombre_carpeta   = nombre_posicion.replace(" ", "_").replace("/", "-")
    carpeta_posicion = os.path.join(carpeta_raiz, nombre_carpeta)
    os.makedirs(carpeta_posicion, exist_ok=True)
    msg(f"Carpeta creada: {carpeta_posicion}", "OK")

    modo_magpy, api_location = modo_forzado or modo_por_distancia(distancia_cm)

    plan = calcular_plan_medida(regiones)
    nombres_regiones = ", ".join(CONFIG_REGION[r]["nombre"] for r in regiones)
    fases_desc = []
    for r in regiones:
        fases_desc.append(f"  {r}: " + " + ".join(f["etiqueta"] for f in CONFIG_REGION[r]["fases"]))

    sep(f"POSICION: {nombre_posicion}")
    beep(2)
    cuadro(
        f"ACCION REQUERIDA -- {nombre_posicion}",
        [f"Coloca el dispositivo en la posicion: {nombre_posicion}",
         f"Distancia de medida: {distancia_cm} cm",
         f"Selecciona en MAGpy3: {modo_magpy} (location '{api_location}')",
         f"Frecuencia configurada: {frecuencia_khz} kHz",
         f"Regiones: {nombres_regiones}",
         f"Duracion RMS: {plan['duracion_rms_nominal_s']//60} min"
         + (f"  +  Peak: {plan['duracion_peak_nominal_s']//60} min" if plan["necesita_peak"] else ""),
         "", "Promediados:"] + fases_desc +
        ["", "Asegurate de que:",
         "  * La sonda MAGpy3 esta correctamente posicionada",
         "  * El dispositivo bajo prueba esta activo",
         "  * MAGpy3 muestra senal en tiempo real"]
    )
    enter((f"{texto_previo}. " if texto_previo else "")
          + f"[{regiones[0]}] Posicion {nombre_posicion}: selecciona {modo_magpy} "
          + "en MAGpy3 (Compliance Location). "
          + AVISO_TECLADO + " Presiona Continuar para INICIAR las medidas de esta posicion")

    # ── FASE RMS ─────────────────────────────────────────────────────────────
    colector_rms = ColectorDatos(api_location=api_location)

    if not iniciar_medida_con_reintentos(f"{nombre_posicion} - RMS", colector=colector_rms):
        colector_rms.detener()
        return carpeta_posicion, None, None, distancia_cm

    fase_rms_label = f"{plan['duracion_rms_nominal_s']//60} min RMS"
    barra_progreso(plan["duracion_rms_s"], f"[{regiones[0]}] {nombre_posicion} - {fase_rms_label}")
    fecha_fin_rms = datetime.now()

    parar_medida()
    time.sleep(1)
    colector_rms.detener()
    time.sleep(0.5)

    capturar_pantalla(carpeta_posicion, fase_rms_label)
    guardar_datos_zip(carpeta_posicion, fase_rms_label, colector_rms, api_location)

    # Calcular promedios RMS para cada región con su ventana propia
    promedios_por_region = {}
    for r in regiones:
        ms_ventana_rms = plan["ventanas"][r].get("RMS")
        if ms_ventana_rms:
            prom = promediar_medidas(colector_rms.filas_measurement, ms_ventana_rms,
                                     ts_inicio_ms=colector_rms.ts_inicio_ms)
            promedios_por_region[r] = {"RMS": prom}
            msg(f"[{r}] RMS ({plan['ventanas_nom'][r]['RMS']//60000} min) -- "
                f"H: {prom.get('h_prom')} A/m | E: {prom.get('e_prom')} V/m", "OK")

    # Particularidad FCC: recordar el promedio FCC de esta posicion/distancia (peor caso 1/d)
    prom_fcc = promedios_por_region.get("FCC", {}).get("RMS")
    if prom_fcc:
        _registrar_promedio_fcc(nombre_posicion, distancia_cm, prom_fcc)

    # ── FASE PEAK (solo si alguna región la necesita) ─────────────────────────
    distancia_peak_cm = distancia_cm
    fecha_fin_peak    = fecha_fin_rms   # se sobreescribe si hay fase Peak real
    if plan["necesita_peak"] and not solo_rms:
        regiones_peak = [r for r in regiones
                         if plan["ventanas"][r].get("Peak") is not None]

        if peak_fisico:
            distancia_peak_cm = distancia_cm
        else:
            distancia_peak_cm = pedir_numero(
                "Distancia de medida PEAK (cm) -- igual que RMS si no cambia",
                0.0, 200.0, distancia_cm
            )

        if distancia_peak_cm == distancia_cm and not peak_fisico:
            # Misma distancia: Peak = RMS x sqrt(2), sin medida fisica adicional.
            # Solo valido para senal monofrecuencia sinusoidal con multi-frequency
            # assessment deshabilitado (ver nota de dominio). Si la ventana RMS
            # tiene mas de una frecuencia distinta, no se aplica el factor.
            msg("Distancia PEAK = distancia RMS -> se calcula por RMS x sqrt(2), "
                "sin repetir la medida.", "OK")
            for r in regiones_peak:
                prom_rms_r = promedios_por_region.get(r, {}).get("RMS")
                if not prom_rms_r:
                    continue
                prom_peak_calc = calcular_peak_desde_rms(prom_rms_r)
                promedios_por_region[r]["Peak"] = prom_peak_calc
                if prom_peak_calc.get("multi_frecuencia"):
                    msg(f"[{r}] PEAK no calculado: se detecto mas de una frecuencia "
                        f"en la ventana RMS (multi-frequency). Revisar manualmente.", "AVISO")
                else:
                    msg(f"[{r}] PEAK (calculado, RMSx√2) -- "
                        f"H: {prom_peak_calc.get('h_prom')} A/m | "
                        f"E: {prom_peak_calc.get('e_prom')} V/m", "OK")
            fecha_fin_peak = fecha_fin_rms
        else:
            # Distancia distinta: es una medida fisica distinta, hay que repetirla.
            beep(1)
            if peak_fisico:
                # Misma posicion y distancia que el RMS: solo cambia el modo, NO se reposiciona.
                cuadro("CAMBIAR A MODO PEAK",
                       ["Pon Peak/RMS = Peak en MAGpy3 --> Configure --> Settings",
                        "La sonda se queda en la misma posicion (no hay que reposicionarla)."])
                enter(f"[{regiones[0]}] Cambia de RMS a Peak y selecciona {modo_magpy} "
                      f"(location {api_location}) en MAGpy3. La sonda no se mueve. "
                      + AVISO_TECLADO + " Presiona Continuar")
            else:
                cuadro("CAMBIAR A MODO PEAK",
                       ["Pon Peak/RMS = Peak en MAGpy3 --> Configure --> Settings",
                        f"Coloca la sonda a {distancia_peak_cm} cm (distancia PEAK)"])
                enter(AVISO_TECLADO + " Presiona Continuar cuando hayas cambiado a Peak y reposicionado la sonda")

            click_clear_gui()
            time.sleep(2)
            colector_peak = ColectorDatos(api_location=api_location)

            exito_peak = iniciar_medida_con_reintentos(f"{nombre_posicion} - Peak", colector=colector_peak)
            if not exito_peak:
                colector_peak.detener()
                beep(1)
                cuadro("RESTABLECER MODO",
                       ["Vuelve a poner Peak/RMS = RMS en MAGpy3 --> Configure settings"])
                enter("Presiona Continuar cuando hayas vuelto a RMS")
                return carpeta_posicion, None, None, distancia_peak_cm

            fase_peak_label = f"{plan['duracion_peak_nominal_s']//60} min Peak"
            barra_progreso(plan["duracion_peak_s"], f"[{regiones[0]}] {nombre_posicion} - {fase_peak_label}")
            fecha_fin_peak = datetime.now()

            parar_medida()
            time.sleep(1)
            colector_peak.detener()
            time.sleep(0.5)

            capturar_pantalla(carpeta_posicion, fase_peak_label)
            guardar_datos_zip(carpeta_posicion, fase_peak_label, colector_peak, api_location)

            for r in regiones_peak:
                ms_ventana_peak = plan["ventanas"][r]["Peak"]
                filas_peak = colector_peak.filas_measurement
                # Solo la comprobacion adicional ISED a 3 cm: la frecuencia
                # de identificacion es la configurada en el formulario.
                # Conservar E/H, timestamps y muestras originales intactos.
                if (frecuencia_peak_fija and r == "ISED"
                        and distancia_peak_cm == DIST_COMPROBACION_CM):
                    filas_peak = [dict(fila, frequency=frecuencia_khz * 1000.0)
                                  for fila in filas_peak]
                    msg(f"[ISED] PEAK a {distancia_peak_cm:g} cm: frecuencia configurada "
                        f"{frecuencia_khz:g} kHz para el calculo de esta medida.", "INFO")
                prom_rms_en_posicion_peak = promediar_medidas(
                    filas_peak, ms_ventana_peak,
                    ts_inicio_ms=colector_peak.ts_inicio_ms
                )
                # La API de MAGpy SIEMPRE devuelve RMS puro (confirmado por
                # soporte SPEAG), sin importar si el equipo está en modo
                # Peak/RMS por GUI -- ese toggle es solo de presentación.
                # Por tanto, el valor medido aquí sigue siendo RMS real y
                # hay que aplicar el mismo factor x√2 que en el camino de
                # "misma distancia", para obtener el Peak reportable.
                prom = calcular_peak_desde_rms(prom_rms_en_posicion_peak)
                if r not in promedios_por_region:
                    promedios_por_region[r] = {}
                promedios_por_region[r]["Peak"] = prom
                if prom.get("multi_frecuencia"):
                    msg(f"[{r}] PEAK no calculado: se detecto mas de una frecuencia "
                        f"en la ventana medida en posicion Peak (multi-frequency). "
                        f"Revisar manualmente.", "AVISO")
                else:
                    msg(f"[{r}] Peak (medido RMS en posicion Peak x√2, {plan['ventanas_nom'][r]['Peak']//60000} min, "
                        f"distancia {distancia_peak_cm} cm) -- "
                        f"H: {prom.get('h_prom')} A/m | E: {prom.get('e_prom')} V/m", "OK")

        if restablecer_modo:
            beep(1)
            cuadro("RESTABLECER MODO",
                   ["Vuelve a poner Peak/RMS = RMS en MAGpy3 --> Configure settings"])
            enter("Presiona Continuar cuando hayas vuelto a RMS")

    # Un dict con None no significa que la fase se haya completado.
    for region in regiones:
        tipos_requeridos = ["RMS"]
        if plan["necesita_peak"] and not solo_rms and plan["ventanas"][region].get("Peak") is not None:
            tipos_requeridos.append("Peak")
        for tipo in tipos_requeridos:
            dato = promedios_por_region.get(region, {}).get(tipo)
            if not promedio_completo(dato, es_peak=(tipo == "Peak")):
                msg(f"Posicion '{nombre_posicion}': {region} {tipo} SIN RESULTADO VALIDO "
                    f"(datos ausentes/no finitos o multi-frecuencia: {dato}). "
                    "Los ZIP se conservan. Hay que repetir o abortar; no se da la posicion por completada.", "ERROR")
                return carpeta_posicion, None, None, distancia_peak_cm

    # ── ESCRITURA EN EXCEL ────────────────────────────────────────────────────
    for r in regiones:
        prom_rms  = promedios_por_region.get(r, {}).get("RMS")
        prom_peak = promedios_por_region.get(r, {}).get("Peak")
        if not (prom_rms or prom_peak):
            continue
        # Cada bloque de EXCEL_COL_MAP coge el promedio que le corresponde
        # segun su clave "valor" (ISED: tabla 1 = RMS, tabla 2 = Peak,
        # tabla 3 = en blanco).
        excel_ok = actualizar_excel(
            ruta_excel, r, nombre_posicion,
            {"RMS": distancia_cm,  "Peak": distancia_peak_cm},
            {"RMS": prom_rms,      "Peak": prom_peak},
            technology, wpt_client, battery,
            {"RMS": fecha_fin_rms, "Peak": fecha_fin_peak},
            frecuencia_khz, avisar_sin_datos=not solo_rms
        )
        if excel_ok:
            msg(f"[{r}] Excel actualizado y valores verificados.", "OK")

    beep(3)
    msg(f"Posicion '{nombre_posicion}' completada", "OK")

    # Devolver promedios de la primera región como resumen CSV (RMS y Peak si existe)
    prom_resumen = (promedios_por_region.get(regiones[0], {}).get("RMS")
                    or next(iter(promedios_por_region.values()), {}).get("RMS"))
    # El Peak lo tiene solo la region que lo mide (ISED), no necesariamente la primera de la lista.
    prom_peak_resumen = next((promedios_por_region[r]["Peak"] for r in regiones
                              if promedios_por_region.get(r, {}).get("Peak")), None)
    return carpeta_posicion, prom_resumen, prom_peak_resumen, distancia_peak_cm


# ═══════════════════════════════════════════════════════════════
# RESUMEN CSV AL FINAL
# ═══════════════════════════════════════════════════════════════

def guardar_csv_resumen(resultados, archivo_csv, separar_regiones=True):
    if not resultados:
        return
    df = pd.DataFrame(resultados)
    df.to_csv(archivo_csv, index=False, sep=";", decimal=",")
    msg(f"CSV de resumen guardado: {archivo_csv}", "OK")
    regiones_presentes = sorted({r for fila in resultados
                                  for r in str(fila.get("regiones", "")).split("+") if r})
    if separar_regiones and len(regiones_presentes) > 1:
        raiz, extension = os.path.splitext(archivo_csv)
        for region in regiones_presentes:
            filas_region = [dict(fila, regiones=region) for fila in resultados
                            if region in str(fila.get("regiones", "")).split("+")]
            guardar_csv_resumen(filas_region, raiz + "_" + region + extension,
                                separar_regiones=False)
    sep("RESUMEN FINAL")
    print(df.to_string(index=False))


# ═══════════════════════════════════════════════════════════════
# ENTRADA DE DATOS
# ═══════════════════════════════════════════════════════════════

def pedir_regiones(actual=None):
    """Permite seleccionar una o varias regiones (CE, FCC, ISED) en una sola sesión."""
    print("\n  Regiones disponibles (puedes seleccionar una o varias):")
    for k, v in CONFIG_REGION.items():
        fases_str = " + ".join(f["etiqueta"] for f in v["fases"])
        print(f"    [{k}]  {v['nombre']}  -->  {fases_str}")
    print("\n  Ejemplos de entrada: CE  /  FCC  /  CE FCC  /  CE FCC ISED")
    print("  Comandos: B = atras | R = reiniciar parametros | Q = cancelar")
    while True:
        prompt = _prompt_actual("\n  Regiones a medir: ", actual)
        entrada = input_config(prompt, permitir_vacio=(actual is not None))
        if entrada == "" and actual is not None:
            return actual
        entrada = entrada.upper()
        seleccionadas = [r.strip() for r in entrada.replace(",", " ").split() if r.strip()]
        invalidas = [r for r in seleccionadas if r not in CONFIG_REGION]
        if not seleccionadas:
            print("  X Introduce al menos una region.")
        elif invalidas:
            print(f"  X Opciones no validas: {', '.join(invalidas)}")
        else:
            # Eliminar duplicados manteniendo orden
            vistas = set()
            seleccionadas = [r for r in seleccionadas if not (r in vistas or vistas.add(r))]
            nombres = ", ".join(CONFIG_REGION[r]["nombre"] for r in seleccionadas)
            print(f"  OK Regiones seleccionadas: {nombres}")
            return seleccionadas


def pedir_carpeta(prompt, actual=None):
    while True:
        ruta = input_config(_prompt_actual(f"  {prompt}: ", actual), permitir_vacio=(actual is not None))
        if ruta == "" and actual is not None:
            return actual
        try:
            os.makedirs(ruta, exist_ok=True)
            print(f"  OK Carpeta lista: {ruta}")
            return ruta
        except Exception as e:
            print(f"  X Error: {e}")


def pedir_archivo_excel(actual=None):
    print("\n  Ruta al archivo Excel de resultados (.xlsm o .xlsx)")
    print(r"  Ejemplo: C:\Users\MAGPy\Desktop\FAN37_07_Field_testing.xlsm")
    print("  Deja en blanco para omitir la escritura en Excel")
    ruta = input_config(_prompt_actual("  Archivo Excel: ", actual), permitir_vacio=True)
    if ruta == "" and actual is not None:
        return actual
    if not ruta:
        return None
    if not os.path.isfile(ruta):
        print(f"  ! Archivo no encontrado: {ruta}. Se omitira la escritura en Excel.")
        return None
    return ruta


# Se cambia de pedir_entero a pedir_numero para permitir introducir distancias como 0.5 cm
def pedir_valor(texto, mn=0.0, mx=999.0, actual=None):
    """Pregunta un numero durante la medida (sin opciones de atras/reiniciar/cancelar)."""
    while True:
        v = input(f"  {texto}: ").strip().replace(",", ".")
        if v == "" and actual is not None:
            return actual
        try:
            f = float(v)
        except ValueError:
            print("  X Introduce un numero.")
            continue
        if mn <= f <= mx:
            return f
        print(f"  X Valor entre {mn} y {mx}.")


def pedir_numero(texto, mn=0.0, mx=999.0, actual=None):
    while True:
        valor = input_config(_prompt_actual(f"  {texto}: ", actual), permitir_vacio=(actual is not None))
        if valor == "" and actual is not None:
            return actual
        try:
            v = float(valor)
            if mn <= v <= mx:
                return v
            print(f"  X Valor entre {mn} y {mx}.")
        except ValueError:
            print("  X Introduce un numero valido.")


def pedir_entero(texto, mn=0, mx=999, actual=None):
    while True:
        valor = input_config(_prompt_actual(f"  {texto}: ", actual), permitir_vacio=(actual is not None))
        if valor == "" and actual is not None:
            return actual
        try:
            v = int(valor)
            if mn <= v <= mx:
                return v
            print(f"  X Valor entre {mn} y {mx}.")
        except ValueError:
            print("  X Introduce un numero entero.")


def pedir_frecuencia(actual=None):
    print("\n  Frecuencia de busqueda de pico (kHz). Rango: 3-10000 kHz")
    while True:
        valor = input_config(_prompt_actual("  Frecuencia (kHz): ", actual), permitir_vacio=(actual is not None))
        if valor == "" and actual is not None:
            return actual
        try:
            f = float(valor)
            if 3 <= f <= 10000:
                return f
            print("  X Fuera del rango 3-10000 kHz.")
        except ValueError:
            print("  X Introduce un numero.")


def pedir_texto(prompt, default=None, actual=None):
    valor_actual = actual if actual is not None else None
    v = input_config(_prompt_actual(f"  {prompt}: ", valor_actual), permitir_vacio=True)
    if v == "" and actual is not None:
        return actual
    return v if v else default


def pedir_nombre_posicion(num, total):
    print(f"\n  Posicion {num} de {total}")
    while True:
        _vaciar_teclado()   # descarta ENTER pulsados durante la medida anterior
        nombre = input("  Nombre de esta posicion (ej: Front-Face, Right, 0cm): ").strip()
        if nombre:
            return nombre
        print("  X Escribe el nombre de la posicion.")

def mostrar_config_manual(cfg):
    cuadro(
        "CONFIGURA MANUALMENTE MAGpy3 ANTES DE CONTINUAR",
        ["Ve a MAGpy3 --> Configure settings (rueda dentada) y ajusta:",
         "", "  [Compliance]",
         f"    Standard            -->  {cfg['standard']}",
         f"    Environment         -->  {cfg['environment']}",
         f"    Health effect       -->  {cfg['health_effect']}",
         "", "  [Measurement]",
         f"    Peak/RMS            -->  {cfg['peak_rms_inicial']}",
         "    * Compliance location NO ES NECESARIO, LO GESTIONA LA API AUTOMATICAMENTE",
         "", "Cierra Settings cuando hayas terminado."]
    )
    enter("Presiona Continuar cuando hayas configurado MAGpy3")


def imprimir_resumen_sesion(regiones, carpeta_raiz, ruta_excel, n_posiciones,
                            distancia_cm, frecuencia, technology, wpt_client,
                            battery, archivo_csv, plan, nombres_regiones):
    duracion_total_min = (plan["duracion_rms_nominal_s"] + plan["duracion_peak_nominal_s"]) // 60

    sep("RESUMEN DE LA SESION")
    print(f"""
  Regiones          : {nombres_regiones}
  Posiciones        : {n_posiciones}
  Distancia         : {distancia_cm} cm
  Frecuencia        : {frecuencia} kHz
  Duracion/posicion : {duracion_total_min} min  (RMS: {plan['duracion_rms_nominal_s']//60} min""" +
          (f"  +  Peak: {plan['duracion_peak_nominal_s']//60} min)" if plan["necesita_peak"] else ")") + f"""
  Technology        : {technology}
  WPT Client        : {wpt_client}
  Battery           : {battery}
  Carpeta raiz      : {carpeta_raiz}
  Excel             : {ruta_excel or 'No configurado'}
  CSV salida        : {archivo_csv}

  Promediados por region:""")
    for r in regiones:
        for f in CONFIG_REGION[r]["fases"]:
            print(f"    [{r}]  {f['etiqueta']}  ({f['nominal_s']//60} min)")


def confirmar_configuracion():
    print("\n  Revisa el resumen antes de empezar. ENTER para continuar.")
    while True:
        accion = input("  Opcion: ").strip().upper()
        if accion == "":
            return
        if accion == "B":
            raise VolverAtrasConfiguracion
        if accion == "R":
            raise ReiniciarConfiguracion
        if accion == "Q":
            raise CancelarSesion
        print("  X Pulsa ENTER para continuar.")


def _valores_configuracion_iniciales():
    return {
        "regiones": None,
        "contacto": None,
        "carpeta_raiz": None,
        "ruta_excel": None,
        "n_posiciones": None,
        "distancia_cm": None,
        "frecuencia": None,
        "technology": None,
        "wpt_client": None,
        "battery": None,
    }


def pedir_si_no(texto, actual=None):
    """Pregunta Si/No (S/N) con los comandos B/R/Q de la configuracion. Devuelve True/False."""
    ref = None if actual is None else ("S" if actual else "N")
    while True:
        v = input_config(_prompt_actual(f"  {texto} (S/N): ", ref), permitir_vacio=(actual is not None))
        if v == "" and actual is not None:
            return actual
        v = v.strip().lower()
        if v in ("s", "si", "sí", "y", "yes"):
            return True
        if v in ("n", "no"):
            return False
        print("  X Responde S (si) o N (no).")


def pedir_contacto(regiones, actual=None):
    """Solo ISED. Devuelve "no" | "puntual" | "periodo"."""
    if "ISED" not in regiones:
        return "no"
    toca = pedir_si_no("El usuario va a tocar el equipo",
                       None if actual is None else actual != "no")
    if not toca:
        return "no"
    periodo = pedir_si_no("Va a estar en contacto con el equipo durante un tiempo",
                          None if actual is None else actual == "periodo")
    return "periodo" if periodo else "puntual"


def _pedir_distancia(valores):
    if valores.get("contacto") == "periodo":
        return 0.0
    return pedir_numero("Distancia de medida (cm)", 0.0, 200.0, valores["distancia_cm"])


def pedir_configuracion_sesion():
    """Pide parámetros iniciales con opción de atrás, reinicio o cancelación."""
    valores = _valores_configuracion_iniciales()

    pasos = [
        ("regiones",     lambda: pedir_regiones(valores["regiones"])),
        ("contacto",     lambda: pedir_contacto(valores["regiones"], valores["contacto"])),
        ("carpeta_raiz", lambda: pedir_carpeta("Carpeta donde se guardaran los resultados", valores["carpeta_raiz"])),
        ("ruta_excel",   lambda: pedir_archivo_excel(valores["ruta_excel"])),
        ("n_posiciones", lambda: pedir_entero("Numero de posiciones a medir", 1, 50, valores["n_posiciones"])),
        ("distancia_cm", lambda: _pedir_distancia(valores)),
        ("frecuencia",   lambda: pedir_frecuencia(valores["frecuencia"])),
        ("technology",   lambda: pedir_texto("Technology (ej: NFC, WPT, BT)", "N/A", valores["technology"])),
        ("wpt_client",   lambda: pedir_texto("WPT Client (N/A si no es WPT)", "N/A", valores["wpt_client"])),
        ("battery",      lambda: pedir_texto("Battery level (N/A si no aplica)", "N/A", valores["battery"])),
    ]

    indice = 0
    primera_pantalla = True

    while True:
        try:
            if primera_pantalla:
                sep("CONFIGURACION DE LA SESION")
                primera_pantalla = False

            if indice < len(pasos):
                if pasos[indice][0] == "technology":
                    print("\n  Datos para el Excel (deja en blanco para N/A):")
                clave, funcion_paso = pasos[indice]
                valores[clave] = funcion_paso()
                indice += 1
                continue

            ts_sesion   = datetime.now().strftime("%Y%m%d_%H%M%S")
            archivo_csv      = os.path.join(valores["carpeta_raiz"], f"promedios_{ts_sesion}.csv")
            archivo_csv_peak = os.path.join(valores["carpeta_raiz"], f"peak_{ts_sesion}.csv")
            plan = calcular_plan_medida(valores["regiones"])
            nombres_regiones = ", ".join(CONFIG_REGION[r]["nombre"] for r in valores["regiones"])

            imprimir_resumen_sesion(
                valores["regiones"], valores["carpeta_raiz"], valores["ruta_excel"], valores["n_posiciones"],
                valores["distancia_cm"], valores["frecuencia"], valores["technology"], valores["wpt_client"],
                valores["battery"], archivo_csv, plan, nombres_regiones
            )
            confirmar_configuracion()

            return {
                "regiones": valores["regiones"],
                "contacto": valores["contacto"],
                "carpeta_raiz": valores["carpeta_raiz"],
                "ruta_excel": valores["ruta_excel"],
                "n_posiciones": valores["n_posiciones"],
                "distancia_cm": valores["distancia_cm"],
                "frecuencia": valores["frecuencia"],
                "technology": valores["technology"],
                "wpt_client": valores["wpt_client"],
                "battery": valores["battery"],
                "archivo_csv": archivo_csv,
                "archivo_csv_peak": archivo_csv_peak,
                "plan": plan,
                "nombres_regiones": nombres_regiones,
            }

        except VolverAtrasConfiguracion:
            if indice <= 0:
                msg("Ya estas en el primer parametro; no hay paso anterior.", "AVISO")
                indice = 0
            else:
                indice -= 1
                msg("Volviendo al parametro anterior.", "AVISO")
            continue
        except ReiniciarConfiguracion:
            valores = _valores_configuracion_iniciales()
            indice = 0
            primera_pantalla = True
            msg("Reiniciando seleccion de parametros.", "AVISO")
            continue
        except CancelarSesion:
            msg("Sesion cancelada antes de iniciar las medidas.", "ERROR")
            sys.exit(0)


# ═══════════════════════════════════════════════════════════════
# PROGRAMA PRINCIPAL
# ═══════════════════════════════════════════════════════════════

def main():
    sep("AUTOMATIZACION DE MEDIDAS MAGpy3 + PROMEDIADO + EXCEL")

    if DEBUG_FAST:
        beep(3)
        cuadro("!!! MODO DEPURACION RAPIDA ACTIVO (MAGPY_DEBUG_FAST=1) !!!",
               [f"Se muestran los tiempos normales, pero en realidad: 6 min = {DURACION_6MIN} s, "
                f"2 min = {DURACION_2MIN} s, FCC 30 min = {DURACION_30MIN} s",
                "",
                "LOS VALORES RESULTANTES NO SON VALIDOS PARA COMPLIANCE.",
                "Usar solo para probar el flujo del script (Excel, CSV, hilos).",
                "",
                "Para desactivar: quita la variable de entorno MAGPY_DEBUG_FAST",
                "y vuelve a ejecutar el script."])
        enter("Presiona Continuar para seguir en modo depuracion")

    if not verificar_conexion():
        msg("Abre MAGpy3, verifica que el backend esta activo.", "ERROR")
        sys.exit(1)

    config = pedir_configuracion_sesion()
    regiones         = config["regiones"]
    carpeta_raiz     = config["carpeta_raiz"]
    ruta_excel       = config["ruta_excel"]
    n_posiciones     = config["n_posiciones"]
    distancia_cm     = config["distancia_cm"]
    frecuencia       = config["frecuencia"]
    technology       = config["technology"]
    wpt_client       = config["wpt_client"]
    battery          = config["battery"]
    archivo_csv      = config["archivo_csv"]
    archivo_csv_peak = config["archivo_csv_peak"]
    plan             = config["plan"]
    nombres_regiones = config["nombres_regiones"]

    if not validar_configuracion_magpy(regiones[0]):
        print("\n  X Corrige la configuracion en MAGpy3 y vuelve a ejecutar el script.")
        sys.exit(1)

    sep("CONFIGURANDO ADQUISICION VIA API")
    configurar_adquisicion(frecuencia)
    time.sleep(1)

    sep("INICIO DE MEDIDAS")
    reiniciar_historial_fcc()
    t_inicio  = datetime.now()
    resultados      = []
    resultados_peak = []

    # Medida de ruido ambiente OBLIGATORIA antes de cualquier posicion
    estado_ruido, filas_ruido = medir_ruido_ambiente(
        carpeta_raiz, regiones, frecuencia, ruta_excel, technology, wpt_client, battery)
    if estado_ruido == "ABORTADA":
        msg("Sesion abortada: no se completo la medida de ruido ambiente.", "ERROR")
        sys.exit(1)
    resultados.extend(filas_ruido)

    # ISED: el usuario toca o no el equipo (cambia como se mide el pico)
    contacto = config.get("contacto", "no")   # "no" | "puntual" | "periodo" (se pregunta al configurar)
    toca = "ISED" in regiones and contacto != "no"

    if toca:
        estado_c, res_c, res_peak_c, n_posiciones = medidas_con_contacto(
            regiones, distancia_cm, frecuencia, carpeta_raiz, ruta_excel,
            technology, wpt_client, battery, pedir_nombre_posicion,
            n_posiciones, periodo=(contacto == "periodo"))
        resultados.extend(res_c)
        resultados_peak.extend(res_peak_c)
        if estado_c == "ABORTADA":
            msg("Sesion abortada durante las medidas con contacto.", "ERROR")
            guardar_csv_resumen(resultados, archivo_csv)
            if resultados_peak:
                guardar_csv_resumen(resultados_peak, archivo_csv_peak)
            sys.exit(1)
    else:
        for i in range(1, n_posiciones + 1):
            nombre_pos = pedir_nombre_posicion(i, n_posiciones)
            while True:
                carpeta_pos, promedios, promedios_peak, distancia_peak_usada = procesar_posicion(
                    nombre_pos, carpeta_raiz, regiones,
                    distancia_cm, frecuencia, ruta_excel,
                    technology, wpt_client, battery,
                    peak_fisico=("ISED" in regiones)
                )
                if promedios:
                    resultados.extend(filas_resumen_regionales(nombre_pos, regiones, distancia_cm, frecuencia, promedios))
                    if promedios_peak:
                        resultados_peak.extend(filas_resumen_regionales(nombre_pos, regiones, distancia_peak_usada, frecuencia, promedios_peak))
                    break

                beep(2)
                cuadro(
                    "POSICION NO COMPLETADA",
                    [f"La posicion '{nombre_pos}' no se ha completado.",
                     "No se pasara a la siguiente posicion automaticamente.",
                     "",
                     "ENTER  --> repetir la misma posicion",
                     "A      --> abortar la sesion"]
                )
                accion = input("  Opcion: ").strip().upper()
                if accion == "A":
                    msg("Sesion abortada. No se continuara con la siguiente posicion.", "ERROR")
                    guardar_csv_resumen(resultados, archivo_csv)
                    if resultados_peak:
                        guardar_csv_resumen(resultados_peak, archivo_csv_peak)
                    sys.exit(1)

    distancia_fcc = distancia_base_fcc(regiones, distancia_cm, contacto)
    # Particularidad FCC: caida 1/d sobre el peor caso (solo si FCC y distancia >= 20 cm)
    estado_f0, filas_f0 = validar_estimado_medido_fcc(
        resultados, regiones, distancia_fcc, carpeta_raiz, frecuencia, ruta_excel,
        technology, wpt_client, battery)
    resultados.extend(filas_f0)
    if estado_f0 == "ABORTADA":
        msg("Sesion abortada durante la validacion FCC a 0 cm.", "ERROR")
        guardar_csv_resumen(resultados, archivo_csv)
        if resultados_peak:
            guardar_csv_resumen(resultados_peak, archivo_csv_peak)
        sys.exit(1)

    estado_fcc, filas_fcc = validar_caida_fcc(
        regiones, distancia_fcc, carpeta_raiz, frecuencia, ruta_excel,
        technology, wpt_client, battery)
    resultados.extend(filas_fcc)
    if estado_fcc == "ABORTADA":
        msg("Sesion abortada durante la validacion FCC 1/d.", "ERROR")
        guardar_csv_resumen(resultados, archivo_csv)
        if resultados_peak:
            guardar_csv_resumen(resultados_peak, archivo_csv_peak)
        sys.exit(1)

    guardar_csv_resumen(resultados, archivo_csv)
    if resultados_peak:
        guardar_csv_resumen(resultados_peak, archivo_csv_peak)

    t_fin = datetime.now()
    dur   = t_fin - t_inicio
    h, m  = int(dur.total_seconds()//3600), int((dur.total_seconds()%3600)//60)

    beep(5)
    cuadro("SESION COMPLETADA",
           [f"Posiciones medidas : {n_posiciones}",
            f"Regiones           : {nombres_regiones}",
            f"Frecuencia         : {frecuencia} kHz",
            f"Hora inicio        : {t_inicio.strftime('%H:%M:%S')}",
            f"Hora fin           : {t_fin.strftime('%H:%M:%S')}",
            f"Duracion total     : {h}h {m}min",
            "",
            "Archivos generados:",
            f"  Carpeta raiz  -->  {carpeta_raiz}",
            f"  CSV resumen   -->  {archivo_csv}"]
           + ([f"  CSV Peak      -->  {archivo_csv_peak}"] if resultados_peak else [])
           + [f"  Excel         -->  {ruta_excel or 'No configurado'}"])

    return


if __name__ == "__main__":
    main()