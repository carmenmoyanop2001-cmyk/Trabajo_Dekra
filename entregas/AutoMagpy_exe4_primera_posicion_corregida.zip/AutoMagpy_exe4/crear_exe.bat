@echo off
setlocal
cd /d "%~dp0"
py -m venv .venv
if errorlevel 1 goto error
.venv\Scripts\python.exe -m pip install --upgrade pyinstaller customtkinter pyautogui pandas numpy openpyxl msoffcrypto-tool requests pillow
if errorlevel 1 goto error
.venv\Scripts\python.exe -m PyInstaller --clean --noconfirm gui_magpy3_exe4.spec
if errorlevel 1 goto error
copy /y automatizacion_magpy3_exe4.py dist\automatizacion_magpy3_exe4.py
if errorlevel 1 goto error
if exist AutoMagpy.ico copy /y AutoMagpy.ico dist\AutoMagpy.ico
echo Listo. Prueba dist\gui_magpy3_exe4.exe. Conserva toda la carpeta dist.
pause
exit /b 0
:error
echo ERROR. Revisa el mensaje anterior. No se ha completado la compilacion.
pause
exit /b 1
