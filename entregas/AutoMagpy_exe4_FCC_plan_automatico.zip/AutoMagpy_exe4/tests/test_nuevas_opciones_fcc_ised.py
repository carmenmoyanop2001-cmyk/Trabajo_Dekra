"""Regresiones del diagrama FCC y aclaraciones del usuario, 17/11/2026."""
import ast,math,unittest
from types import SimpleNamespace
import openpyxl
import test_multirregion as r
import test_fcc

class DiagramaFccTests(unittest.TestCase):
 def test_limites_y_contacto_independiente(self):
  ns={};r.config(ns);r.load({'fcc_aplica_validacion_cero'},ns)
  for d,cerca,lejos in [(0,True,False),(1.85,True,False),(1.850001,False,False),(19.999,False,False),(20,False,True),(22,False,True)]:
   for f in (99.999,100,125):
    for contacto in ('no','puntual','periodo'):
     with self.subTest(d=d,f=f,contacto=contacto):
      plan=ns['plan_fcc'](d,f)
      self.assertEqual(plan['estimated_measured'],cerca);self.assertEqual(plan['caida_1d'],lejos)
      self.assertEqual(ns['fcc_aplica_validacion_cero'](['FCC'],d,contacto),cerca)
      self.assertEqual(plan['modos_2y4'],['RMS','Peak'] if f<100 else ['RMS'])
      self.assertEqual(plan['peak_min'],2 if f<100 else 0)
 def test_rms_compartido_y_peak_fcc_siempre_dos_minutos(self):
  ns={};r.config(ns);r.load({'calcular_plan_medida'},ns)
  for f in (50,100,125):
   p=ns['calcular_plan_medida'](['ISED','FCC'],20,'puntual',f)
   base=[x for x in p['secuencia'] if x.get('principal')]
   self.assertEqual(len(base),1);self.assertEqual(base[0]['cortes'],{'ISED':360,'FCC':1800})
   self.assertEqual(base[0]['modo'],'RMS')
   fcc_peak=[x for x in p['secuencia'] if x['region']=='FCC' and x['modo']=='Peak']
   self.assertEqual([x['nominal_s'] for x in fcc_peak],[120] if f<100 else [])
 def test_fcc_50khz_rms_y_peak_en_filas_excel_distintas(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   capturas=[];mensajes=[]
   ns.update(capturar_pantalla=lambda *a:capturas.append(a),enter=mensajes.append)
   result=ns['procesar_posicion']('P1',fixture.tmp.name,regiones,0,50,str(fixture.path),'','','')
   self.assertEqual(result[1]['_por_region']['FCC']['modo_adquisicion'],'RMS')
   self.assertEqual(result[2]['_por_region']['FCC']['modo_adquisicion'],'Peak')
   wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
   self.assertEqual([wb['FCC Results'].cell(i,5).value for i in (9,10)],['P1','P1 [PEAK]'])
   self.assertEqual(wb['FCC Results'].cell(9,17).value,4.6)
   self.assertEqual(wb['FCC Results'].cell(10,17).value,round(2*math.sqrt(2),4))
   self.assertEqual(len(capturas),1);self.assertIn('pico_0cm_P1',capturas[0][1])
   for m in mensajes:self.assertIn('Cierra teclado',m)
   return result
  _,_,_,dur,refs,_=case.ejecutar_real(['FCC'],ejecutar=ejecutar)
  self.assertEqual(dur,[1800,120]);self.assertEqual(refs,['tip-max','probe-center'])
 def test_fcc_e_ised_50khz_comparten_rms_pero_no_picos(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   result=ns['procesar_posicion']('P1',fixture.tmp.name,regiones,20,50,str(fixture.path),'RFID','','',peak_fisico=True)
   wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
   self.assertEqual(wb['ISED Results'].cell(9,17).value,1)
   self.assertEqual(wb['FCC Results'].cell(9,17).value,4.6)
   self.assertEqual(wb['ISED Results'].cell(9,42).value,round(2*math.sqrt(2),4))
   self.assertEqual(wb['FCC Results'].cell(10,17).value,round(3*math.sqrt(2),4))
   return result
  _,_,_,dur,_,_=case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
  self.assertEqual(dur,[1800,120,120])
 def test_estimado_medido_50khz_ocho_adquisiciones_en_todos_contactos(self):
  for contacto in ('no','puntual','periodo'):
   with self.subTest(contacto=contacto):
    case=r.MultirregionTests();self.addCleanup(case.doCleanups)
    def ejecutar(ns,fixture,regiones):
     r.load({'validar_estimado_medido_fcc','fcc_aplica_validacion_cero','peor_posicion_h',
      'diferencia_estimada_medida_pct','guardar_validacion_region'},ns)
     ns.update(FCC_DISTANCIAS_EST_MEAS_CM=(2.,4.),FCC_DIF_MAX_PCT=30.,NOMBRE_RUIDO='Ruido',_accion_fallo_consola=lambda *a:'ABORTAR')
     estado,filas=ns['validar_estimado_medido_fcc']([dict(posicion='A',regiones='FCC',distancia_cm=1,h_prom_A_m=1)],
      ['FCC'],1,fixture.tmp.name,50,str(fixture.path),'','','',contacto=contacto)
     self.assertEqual(len(filas),8);self.assertEqual([f['modo_adquisicion'] for f in filas],['RMS']*4+['Peak']*4)
     self.assertEqual([f['location'] for f in filas],['tip-max','probe-center']*4)
     wb=openpyxl.load_workbook(fixture.path);self.addCleanup(wb.close)
     nombres=[wb['FCC Results'].cell(i,5).value for i in range(9,17)]
     self.assertEqual(len(set(nombres)),8);self.assertTrue(all(nombres))
     for i in range(9,17):
      self.assertIsNotNone(wb['FCC Results'].cell(i,17).value)
      self.assertIsNotNone(wb['FCC Results'].cell(i,8).value)
     return None,None,None,None
    _,_,_,dur,refs,_=case.ejecutar_real(['FCC'],ejecutar=ejecutar)
    self.assertEqual(dur,[1800]*4+[120]*4);self.assertEqual(refs,['tip-max','probe-center']*4)
 def test_fcc_100khz_solo_cuatro_rms_estimated_measured(self):
  ns=test_fcc.cargar({},estmeas={(2.,'Estimated'):1,(2.,'Measured'):1,(4.,'Estimated'):1,(4.,'Measured'):1})
  estado,filas=ns['validar_estimado_medido_fcc']([dict(posicion='A',regiones='FCC',distancia_cm=0,h_prom_A_m=1)],
    ['FCC'],0,'c',100,None,'','','',contacto='puntual')
  self.assertEqual(estado,'OK');self.assertEqual(len(filas),4)
  self.assertTrue(all(f['modo_adquisicion']=='RMS' for f in filas))
 def test_historial_no_mezcla_rms_y_peak(self):
  ns=test_fcc.cargar({});ns['reiniciar_historial_fcc']()
  for pos,modo,h in [('A','RMS',100),('A','Peak',1),('B','RMS',1),('B','Peak',10)]:
   ns['_registrar_promedio_fcc'](pos,20,dict(h_prom=h,e_prom=h,freq_mhz=.05,modo_adquisicion=modo))
  self.assertEqual(ns['fcc_peor_caso'](20,.05,modo='RMS')['posicion'],'A')
  self.assertEqual(ns['fcc_peor_caso'](20,.05,modo='Peak')['posicion'],'B')
 def test_1d_desde_20_peak_dos_min_o_rms_treinta(self):
  for freq,duracion in [(50,120),(100,1800)]:
   with self.subTest(freq=freq):
    case=r.MultirregionTests();self.addCleanup(case.doCleanups)
    def ejecutar(ns,fixture,regiones):
     r.load({'validar_caida_fcc','fcc_peor_caso','fcc_limite_mpe','fcc_limite_caida','_registrar_promedio_fcc'},ns)
     ns.update(FCC_DISTANCIA_MIN_VALIDACION_CM=20,FCC_PASO_CM=2.,FCC_MIN_PASOS_EXTRA=2,FCC_MAX_PASOS_EXTRA=8,
      FCC_CAMPOS_VALIDACION=(('h_prom','H','A/m'),('e_prom','E','V/m')),_HISTORIAL_FCC={},_accion_fallo_consola=lambda *a:'ABORTAR',
      guardar_validacion_region=lambda *a:None)
     modo='Peak' if freq<100 else 'RMS'
     ns['_registrar_promedio_fcc']('Base',20,dict(h_prom=100,e_prom=100,freq_mhz=freq/1000,modo_adquisicion=modo))
     estado,filas=ns['validar_caida_fcc'](['FCC'],20,fixture.tmp.name,freq,str(fixture.path),'','','',contacto='puntual')
     self.assertEqual(estado,'OK');self.assertEqual([f['distancia_cm'] for f in filas],[22,24])
     return None,None,None,None
    _,_,_,dur,_,_=case.ejecutar_real(['FCC'],ejecutar=ejecutar)
    self.assertEqual(dur,[duracion,duracion])
 def test_puntual_todos_rms_antes_picos_y_peor_ised_independiente(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   r.load({'medidas_con_contacto','_medidas_puntuales_regionales','promedio_completo',
      'filas_resumen_regionales','_fila_resumen','_medida_peor_posicion','_medir_posiciones_con_reintento',
      'comprobar_eh','guardar_validacion_region','guardar_json_atomico'},ns)
   ns.update(pedir_numero=lambda *a:2,_accion_fallo_consola=lambda *a:'ABORTAR',EH_LIMITE_OHM=37.7)
   estado,filas,picos,n=ns['medidas_con_contacto'](regiones,20,50,fixture.tmp.name,str(fixture.path),
      'RFID','','',lambda i,n:f'P{i}',2,False)
   self.assertEqual(estado,'OK');self.assertEqual(len(picos),5)
   self.assertEqual([f['posicion'] for f in filas if f['regiones']=='FCC'],['P1','P2'])
   self.assertEqual([f['posicion'] for f in picos if f['distancia_cm']==3],['P2 3cm'])
   return None,None,None,None
  _,_,_,dur,_,_=case.ejecutar_real(['ISED','FCC'],ejecutar=ejecutar)
  self.assertEqual(dur,[1800,1800,120,120,120,120,360,120])
 def test_mensajes_reproducen_diagrama(self):
  ns={};r.load(set(),ns)
  for d in (0,1.85,2,19.9,20):
   for f in (50,100):
    texto=' '.join(ns['opciones_fcc'](d,f))
    self.assertIn('RMS principal de 30 min',texto)
    if f<100:self.assertIn('2 min',texto)
    if d<=1.85:
     self.assertIn('Estimated = Tip Max',texto);self.assertIn('Measured = Probe Center',texto)
    if d>=20:self.assertIn('>=20 cm',texto);self.assertIn('1/d',texto)
