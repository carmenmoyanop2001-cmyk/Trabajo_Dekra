import ast,unittest
from types import SimpleNamespace
import test_multirregion as r

class NotaDinamicaTests(unittest.TestCase):
 def nota(self,distancia,frecuencia,contacto='puntual'):
  ns={};r.load({'distancia_base_fcc'},ns)
  gui=ast.parse((r.BASE/'gui_magpy3_exe4.py').read_text())
  cls=next(n for n in gui.body if isinstance(n,ast.ClassDef) and n.name=='AppMagpy3')
  f=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_actualizar_info_fcc')
  ctx={'core':SimpleNamespace(**ns)}
  exec(compile(ast.Module(body=[f],type_ignores=[]),'gui','exec'),ctx)
  fcc=[];ised=[]
  var=lambda valor:SimpleNamespace(get=lambda:valor)
  obj=SimpleNamespace(var_distancia=var(distancia),var_frecuencia=var(frecuencia),var_toca=var('Sí'),
    vars_regiones={'FCC':var(True),'ISED':var(True)},_contacto_actual=lambda:contacto,
    lbl_info_fcc=SimpleNamespace(configure=lambda **kw:fcc.append(kw['text'])),
    lbl_info_ised=SimpleNamespace(configure=lambda **kw:ised.append(kw['text'])))
  ctx['_actualizar_info_fcc'](obj)
  return fcc[-1],ised[-1]
 def test_nota_segunda_seleccion_no_conserva_rama_anterior(self):
  cerca,_=self.nota('0','50')
  self.assertIn('Has elegido 0 cm y 50 kHz',cerca)
  self.assertIn('se activan Estimated/Measured',cerca)
  self.assertIn('RMS 30 min y PEAK 2 min',cerca)
  lejos,_=self.nota('20','100')
  self.assertIn('se activa la caida 1/d',lejos)
  self.assertIn('solo RMS, sin PEAK adicional',lejos)
  self.assertNotIn('se activan Estimated/Measured',lejos)
  self.assertIn('no tienes que elegir cada fase',lejos)
 def test_distancia_intermedia_sin_comprobaciones_adicionales(self):
  texto,_=self.nota('5','125')
  self.assertIn('sin comprobaciones adicionales',texto)
  self.assertNotIn('se activa la caida',texto)
 def test_valores_incompletos_o_invalidos_no_inventan_un_plan(self):
  for d,f in [('', '50'),('20',''),('nan','50'),('inf','50'),('20','nan'),('-1','50'),('20','10001')]:
   with self.subTest(d=d,f=f):
    texto,_=self.nota(d,f)
    self.assertIn('Introduce una distancia',texto)
    self.assertNotIn('Has elegido',texto)
 def test_ised_describe_contacto_elegido(self):
  _,texto=self.nota('20','50','puntual')
  self.assertIn('Si/No',texto);self.assertIn('20 cm',texto);self.assertIn('PEAK a 0 cm',texto)

class InstruccionesAntesMedidaTests(unittest.TestCase):
 def test_cada_estimated_measured_explica_que_hacer_en_ambos_modos(self):
  case=r.MultirregionTests();self.addCleanup(case.doCleanups)
  def ejecutar(ns,fixture,regiones):
   r.load({'validar_estimado_medido_fcc','fcc_aplica_validacion_cero','peor_posicion_h',
     'diferencia_estimada_medida_pct'},ns)
   notas=[]
   ns.update(FCC_DISTANCIAS_EST_MEAS_CM=(2.,4.),FCC_DIF_MAX_PCT=30.,NOMBRE_RUIDO='Ruido',
    _accion_fallo_consola=lambda *a:'ABORTAR',enter=notas.append,guardar_validacion_region=lambda *a:None)
   ns['validar_estimado_medido_fcc']([dict(posicion='A',regiones='FCC',distancia_cm=0,h_prom_A_m=1)],
    ['FCC'],0,fixture.tmp.name,50,str(fixture.path),'','','',contacto='puntual')
   acciones=[n for n in notas if 'SIGUIENTE MEDIDA:' in n]
   self.assertEqual(len(acciones),8)
   self.assertEqual(sum('RMS, 30 min' in n for n in acciones),4)
   self.assertEqual(sum('Peak, 2 min' in n for n in acciones),4)
   self.assertEqual(sum('PUNTA' in n and 'Tip Max' in n for n in acciones),4)
   self.assertEqual(sum('RAYA NEGRA' in n and 'Probe Center' in n for n in acciones),4)
   self.assertTrue(all('Cierra teclado' in n for n in acciones))
   return None,None,None,None
  case.ejecutar_real(['FCC'],ejecutar=ejecutar)
