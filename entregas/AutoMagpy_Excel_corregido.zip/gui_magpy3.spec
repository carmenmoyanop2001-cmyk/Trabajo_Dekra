# -*- mode: python ; coding: utf-8 -*-
# Spec para generar gui_magpy3.exe (un solo .exe).
#
# IMPORTANTE: automatizacion_magpy3.py NO va dentro del .exe: se carga suelto desde la
# carpeta del .exe. Como PyInstaller no ve sus imports, aqui se declaran todas las
# librerias que usa (pyautogui, pandas, openpyxl, msoffcrypto, ...).
from pathlib import Path
from PyInstaller.utils.hooks import collect_all

datas = [('gui_magpy3.py', '.'), ('config_store.py', '.')]
binaries = []
hiddenimports = [
    'PIL', 'PIL.ImageGrab', 'PIL.Image', 'PIL.PngImagePlugin',
    'requests', 'requests.adapters', 'requests.auth', 'urllib3',
    'pyautogui', 'pandas', 'numpy', 'openpyxl', 'msoffcrypto',
    'tkinter', 'tkinter.ttk', 'tkinter.filedialog', 'tkinter.messagebox',
    'getpass', 'zipfile', 'csv', 'msvcrt',
]
# Librerias con ficheros de datos propios (temas, plantillas, cifrado...)
for paquete in ('customtkinter', 'msoffcrypto', 'openpyxl', 'pyautogui', 'pandas'):
    d, b, h = collect_all(paquete)
    datas += d
    binaries += b
    hiddenimports += h

a = Analysis(
    ['gui_magpy3.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='gui_magpy3',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['AutoMagpy.ico'] if Path('AutoMagpy.ico').is_file() else None,
)
