"""Reintenta un resultado JSON pendiente sin repetir la adquisicion."""
import argparse
import json
from datetime import datetime
from pathlib import Path
import automatizacion_magpy3 as core


def reimportar(archivo, ruta_excel=None):
    archivo = Path(archivo)
    registro = json.loads(archivo.read_text(encoding='utf-8'))
    if registro.get('estado') == 'GUARDADO_Y_VERIFICADO':
        print('Este resultado ya figura como guardado y verificado. No se duplica.')
        return True
    argumentos = dict(registro['argumentos'])
    argumentos['fechas_fin'] = {
        tipo: datetime.fromisoformat(valor) if isinstance(valor, str) and valor else valor
        for tipo, valor in argumentos.get('fechas_fin', {}).items()
    }
    destino = registro.get('destino') or {}
    if ruta_excel:
        argumentos['ruta_excel'] = str(Path(ruta_excel).resolve())
        destino = {}  # El otro libro puede tener filas diferentes.
    ok = core.actualizar_excel(**argumentos, destino_excel=destino)
    if ok:
        registro['estado'] = 'GUARDADO_Y_VERIFICADO'
        core.guardar_json_atomico(archivo, registro)
        print('Valores guardados y verificados. No se ha realizado ninguna medida nueva.')
    else:
        print('El resultado sigue pendiente. Conserva este JSON y los ZIP de la medida.')
    return bool(ok)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('resultado_json', help='JSON de AutoMagpy_resultados')
    parser.add_argument('--excel', help='Ruta del Excel si se ha movido o se usa una copia')
    args = parser.parse_args()
    raise SystemExit(0 if reimportar(args.resultado_json, args.excel) else 1)
