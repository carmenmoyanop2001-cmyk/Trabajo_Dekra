import ast, pathlib, unittest, math
BASE = pathlib.Path(__file__).resolve().parents[1]
SRC = (BASE / 'automatizacion_magpy3_exe4.py').read_text(encoding='utf-8')
TREE = ast.parse(SRC)
WANT_F = {'reiniciar_historial_fcc', '_registrar_promedio_fcc', 'fcc_limite_mpe', 'fcc_peor_caso',
          'fcc_limite_caida', 'validar_caida_fcc'}
WANT_F |= {'fcc_aplica_validacion_cero', 'diferencia_estimada_medida_pct', 'peor_posicion_h',
           'validar_estimado_medido_fcc', 'modo_por_distancia'}
WANT_V = {'FCC_DISTANCIA_MIN_VALIDACION_CM', 'FCC_PASO_CM', 'FCC_MAX_PASOS_EXTRA', 'FCC_MIN_PASOS_EXTRA',
          'FCC_CERO_CM_MAX', 'FCC_DISTANCIAS_EST_MEAS_CM', 'FCC_DIF_MAX_PCT', 'NOMBRE_RUIDO',
          'UMBRAL_TIP_MAX_CM', 'UMBRAL_PROBE_CENTER_CM',
          'FCC_CAMPOS_VALIDACION', '_HISTORIAL_FCC'}

def cargar(valores_por_distancia, estmeas=None):
    ns = {'math': math, 'msg': lambda *a, **k: None, 'beep': lambda *a: None,
          'cuadro': lambda *a, **k: None, 'enter': lambda *a, **k: None,
          '_accion_fallo_consola': lambda n: 'ABORTAR', 'medidas': []}
    for n in TREE.body:
        if isinstance(n, ast.FunctionDef) and n.name in WANT_F:
            exec(compile(ast.Module([n], []), 'x', 'exec'), ns)
        elif isinstance(n, ast.Assign) and any(getattr(t, 'id', None) in WANT_V for t in n.targets):
            exec(compile(ast.Module([n], []), 'x', 'exec'), ns)
    def procesar(nombre, carpeta, regiones, d, freq, excel, tech, wpt, bat, modo_forzado=None, texto_previo=None):
        ns['medidas'].append((d, modo_forzado[0] if modo_forzado else None) if estmeas else d)
        h = estmeas[(d, nombre.rsplit('_', 1)[1])] if estmeas else valores_por_distancia[d]
        return carpeta, {'h_prom': h, 'e_prom': 1.0, 'freq_mhz': 0.1}, None, d
    ns['procesar_posicion'] = procesar
    return ns

class TestFCC(unittest.TestCase):
    def correr(self, vals):
        ns = cargar(vals)
        ns['reiniciar_historial_fcc']()
        ns['_registrar_promedio_fcc']('P1', 20.0, {'h_prom': 1.0, 'e_prom': 1.0, 'freq_mhz': 0.1})
        r = ns['validar_caida_fcc'](['FCC'], 20.0, 'c', 100.0, None, 't', 'w', 'b')
        return r, ns['medidas']

    def test_cumple_en_22_mide_24_y_termina(self):
        (est, filas), med = self.correr({22.0: 0.94, 24.0: 0.99})   # 24 no tiene que cumplir
        self.assertEqual(est, 'OK'); self.assertEqual(med, [22.0, 24.0])

    def test_limite_exacto_cumple(self):
        (est, _), med = self.correr({22.0: 0.95, 24.0: 0.5})
        self.assertEqual((est, med), ('OK', [22.0, 24.0]))

    def test_no_cumple_22_cumple_24_contra_el_anterior(self):
        # 22: 0.97 (> 0.95, no cumple). 24 se compara con 22: limite 0.97*0.95 = 0.9215
        (est, _), med = self.correr({22.0: 0.97, 24.0: 0.92})
        self.assertEqual((est, med), ('OK', [22.0, 24.0]))

    def test_24_cumpliria_contra_referencia_pero_no_contra_anterior(self):
        # 24: 0.93 <= 0.95 pero > 0.97*0.95 = 0.9215 -> no cumple, hay que seguir hasta 26
        (est, _), med = self.correr({22.0: 0.97, 24.0: 0.93, 26.0: 0.88})
        self.assertEqual((est, med), ('OK', [22.0, 24.0, 26.0]))

    def test_nunca_cumple_llega_al_tope(self):
        vals = {20.0 + 2 * k: 1.0 for k in range(1, 9)}
        (est, filas), med = self.correr(vals)
        self.assertEqual(est, 'NO_CUMPLE'); self.assertEqual(len(med), 8)

    def test_no_aplica_menos_de_20(self):
        ns = cargar({}); ns['reiniciar_historial_fcc']()
        self.assertEqual(ns['validar_caida_fcc'](['FCC'], 10.0, 'c', 100.0, None, 't', 'w', 'b')[0], 'NA')

class TestFCC0cm(unittest.TestCase):
    def filas(self):
        return [{'posicion': 'Ruido', 'regiones': 'FCC', 'distancia_cm': None, 'h_prom_A_m': 9.0},
                {'posicion': 'A', 'regiones': 'FCC', 'distancia_cm': 0.0, 'h_prom_A_m': 0.2},
                {'posicion': 'B', 'regiones': 'FCC', 'distancia_cm': 0.0, 'h_prom_A_m': 0.5},
                {'posicion': 'C', 'regiones': 'FCC+ISED', 'distancia_cm': 0.0, 'h_prom_A_m': 0.3},
                {'posicion': 'B 3cm', 'regiones': 'ISED', 'distancia_cm': 3.0, 'h_prom_A_m': 5.0}]

    def correr(self, valores, regiones=('FCC',), dist=0.0):
        ns = cargar({}, estmeas=valores)
        return ns['validar_estimado_medido_fcc'](self.filas(), list(regiones), dist, 'c', 100.0, None, 't', 'w', 'b'), ns['medidas']

    def test_peor_posicion_y_cuatro_medidas_con_su_modo(self):
        v = {(2.0, 'Estimated'): 1.0, (2.0, 'Measured'): 1.1, (4.0, 'Estimated'): 0.5, (4.0, 'Measured'): 0.55}
        (est, filas), med = self.correr(v)
        self.assertEqual(est, 'OK'); self.assertEqual(len(filas), 4)
        self.assertEqual(med, [(2.0, 'Tip Max'), (2.0, 'Probe Center'), (4.0, 'Tip Max'), (4.0, 'Probe Center')])
        self.assertTrue(all(f['posicion'].startswith('B_') for f in filas))   # B = mayor H, sin Ruido ni 3 cm

    def test_diferencia_30_o_mas_no_valida(self):
        v = {(2.0, 'Estimated'): 1.0, (2.0, 'Measured'): 1.5, (4.0, 'Estimated'): 0.5, (4.0, 'Measured'): 0.5}
        (est, _), _ = self.correr(v)      # |1-1.5|/1.5 = 33.3 %
        self.assertEqual(est, 'NO_CUMPLE')

    def test_limite_exacto_30_no_valida(self):
        ns = cargar({})
        self.assertAlmostEqual(ns['diferencia_estimada_medida_pct'](0.7, 1.0), 30.0)
        self.assertIsNone(ns['diferencia_estimada_medida_pct'](1.0, 0))
        self.assertIsNone(ns['diferencia_estimada_medida_pct'](None, 1.0))

    def test_no_aplica_si_no_es_0cm_o_sin_fcc(self):
        self.assertEqual(self.correr({}, dist=20.0)[0][0], 'NA')
        self.assertEqual(self.correr({}, regiones=('CE',))[0][0], 'NA')

    def test_modo_por_distancia(self):
        ns = cargar({})
        f = ns['modo_por_distancia']
        self.assertEqual(f(0.0), ('Tip Max', 'tip-max'))
        self.assertEqual(f(0.7), ('Tip Max', 'tip-max'))
        self.assertEqual(f(1.0), ('Sensor Max', 'sensor-max'))
        self.assertEqual(f(1.85), ('Sensor Max', 'sensor-max'))
        self.assertEqual(f(3.0), ('Probe Center', 'probe-center'))
        self.assertEqual(f(20.0), ('Probe Center', 'probe-center'))

if __name__ == '__main__': unittest.main()
