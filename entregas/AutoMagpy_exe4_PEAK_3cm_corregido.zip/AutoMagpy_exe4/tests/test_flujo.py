import ast, unittest
from pathlib import Path
base=Path(__file__).resolve().parents[1]
def load_functions(path, names, ns):
 tree=ast.parse(path.read_text())
 nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns)
class Flow(unittest.TestCase):
 def run_flow(self,fail=False):
  calls=[]; prompts=[]; validations=[]; attempts={}
  def process(name,*args,**kw):
   calls.append((name,args[2],kw.get('peak_fisico')))
   attempts[name]=attempts.get(name,0)+1
   if fail and name=='P2' and attempts[name]==1: return None,{'h_prom':2,'e_prom':10},None,None
   h={'P1':1,'P2':9,'P3':3,'P4':4}.get(name,5)
   return None,{'h_prom':h,'e_prom':10},{'h_prom':h*2,'e_prom':20},None
  ns=dict(math=__import__("math"),DIST_PICO_CONTACTO_CM=0.,DIST_COMPROBACION_CM=3.,EH_LIMITE_OHM=377,
   _accion_fallo_consola=lambda n:'REPETIR',cuadro=lambda *a:None,msg=lambda *a:None,
   enter=prompts.append,procesar_posicion=process,
   _fila_resumen=lambda name,*a:{'posicion':name},
   comprobar_eh=lambda e,h:(validations.append(len(calls)) or (e/h,True)))
  load_functions(base/'automatizacion_magpy3_exe4.py',{'promedio_completo','_medir_posiciones_con_reintento','medidas_con_contacto','_medida_peor_posicion'},ns)
  state,r,p,n=ns['medidas_con_contacto'](['ISED'],0,100,'out',None,'','','',lambda i,n:f'P{i}',4,True)
  self.assertEqual(state,'OK'); self.assertEqual(n,4)
  self.assertEqual([x['posicion'] for x in r],['P1','P2','P3','P4','P2 3cm'])
  self.assertEqual(calls[-1],('P2 3cm',3.,True))
  self.assertTrue(any('4 posiciones seleccionadas' in s and 'PEAK' in s for s in prompts))
  self.assertEqual(validations,[len(calls)])
 def test_four_positions_then_worst_then_validation(self): self.run_flow()
 def test_missing_peak_retries_same_position(self): self.run_flow(True)
 def test_keyboard_before_acquisition(self):
  events=[]
  ns=dict(MAX_REINTENTOS_INICIO_MEDIDA=8,enter=lambda t:events.append(('prompt',t)),
          iniciar_medida=lambda **kw:events.append(('start',None)) or True,msg=lambda *a:None)
  load_functions(base/'automatizacion_magpy3_exe4.py',{'iniciar_medida_con_reintentos'},ns)
  self.assertTrue(ns['iniciar_medida_con_reintentos']('P1 RMS'))
  self.assertEqual([e[0] for e in events],['prompt','start'])
  self.assertIn('teclado',events[0][1])
 def test_collector_starts_after_acknowledgement_and_acquisition(self):
  from types import SimpleNamespace
  events=[]
  ns=dict(MAX_REINTENTOS_INICIO_MEDIDA=8,enter=lambda t:events.append('confirmar'),
          iniciar_medida=lambda **kw:events.append('adquisicion') or True,msg=lambda *a:None)
  load_functions(base/'automatizacion_magpy3_exe4.py',{'iniciar_medida_con_reintentos'},ns)
  collector=SimpleNamespace(iniciar=lambda:events.append('colector'))
  self.assertTrue(ns['iniciar_medida_con_reintentos']('P1 PEAK',colector=collector))
  self.assertEqual(events,['confirmar','adquisicion','colector'])
 def test_double_confirmation_ignored(self):
  import queue
  from types import SimpleNamespace
  tree=ast.parse((base/'gui_magpy3_exe4.py').read_text())
  cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='AppMagpy3')
  method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_on_confirmar_nombre_posicion')
  q=queue.Queue();ns={'respuesta_q':q,'_cerrar_teclado_tactil_windows':lambda:None}
  exec(compile(ast.Module(body=[method],type_ignores=[]),'gui','exec'),ns)
  app=SimpleNamespace(esperando_nombre_posicion=True,var_nombre_pos=SimpleNamespace(get=lambda:'P1'),frame_nombre_pos=SimpleNamespace(pack_forget=lambda:None))
  ns[method.name](app);ns[method.name](app)
  self.assertEqual(q.qsize(),1)
for p in base.rglob('*.py'): ast.parse(p.read_text())
if __name__ == "__main__": unittest.main()
